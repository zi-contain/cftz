## 1. 总结

- **漏洞类型**: XSS (CWE-79)
- **标记位置**: public/index.php:68
- **漏洞描述**: 平台的 'site_name' 设置在存储时未进行任何 HTML/JS 净化（public/api/admin/index.php:587 仅应用了 trim()），并且在公共首页通过 json_encode(..., JSON_UNESCAPED_SLASHES) 渲染进内联的 <script type="application/ld+json"> 块中（public/index.php:68-76）。JSON_UNESCAPED_SLASHES 恰恰会禁用唯一能中和结束标签的转义，因此诸如 </script><img src=x onerror=alert(document.domain)> 这样的载荷（52 个字符，未超过 Brand::normalize 强制的 60 字符上限）会终止该 script 元素，并为每一个未认证访问者注入可执行的标记/JS。唯一的写入者是超级管理员，但该汇聚点是公共页面，读取路径上未应用任何上下文相关的转义，且首页未下发任何 Content-Security-Policy，因此该告警为真实漏洞（TP），属于存储型/特权来源的 XSS。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的净化函数

**证据**: `app/Core/Brand.php:61-65`

```
public static function normalize(string $value): string { $value = trim(preg_replace('/[\x00-\x1F\x7F]/', '', $value) ?: ''); return function_exists('mb_substr') ? mb_substr($value, 0, 60) : substr($value, 0, 60); }
```

normalize() 仅剥离 C0 控制字符（0x00-0x1F）和 DEL（0x7F），随后截断到 60 个字符。'<'、'>'、'/'、'"'、'&' 均未被处理，因此 HTML/JS 逃逸载荷可以完整存活，且 60 字符上限并不会将其移除。这是读取路径上唯一的净化函数。

### 步骤 2: 定位使用该值的输出汇聚点

**证据**: `public/index.php:68-76`

```
<script type="application/ld+json"><?= json_encode([ '@context' => 'https://schema.org', '@type' => 'WebApplication', 'name' => $shareTitle, ... ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
```

$shareTitle 由 $brandName 赋值（public/index.php:42，在第 5 行由 Brand::name() 设置）。该值落入内联 JSON-LD <script> 块内部。PHP 的 json_encode() 默认会将 '/' 转义为 '\/'，这正是阻止 '</script>' 关闭该元素的原因；JSON_UNESCAPED_SLASHES 移除了该保护，于是 '</script>' 被原样输出，HTML 解析器会提前结束该 script 元素。json_encode() 默认不转义 '<' 或 '>'，因此在逃逸点之后注入的标签会被当作真实的 HTML 解析。

### 步骤 3: 将值回溯到数据库及其写入者

**证据**: `app/Core/Brand.php:25-36`

```
$statement = $pdo->prepare("SELECT setting_value FROM cc_platform_settings WHERE setting_key = 'site_name' LIMIT 1"); $statement->execute(); $value = self::decode($statement->fetchColumn()); if (is_scalar($value) && trim((string) $value) !== '') { $name = self::normalize((string) $value); }
```

Brand::name() 读取 cc_platform_settings.site_name，对其进行 json_decode（Brand::decode，第 73-80 行）并执行 normalize()。存储的值即为到达汇聚点的值。接下来：找出谁写入该行，以及写入时是否进行了任何转义。

### 步骤 4: 检查写入路径的净化与访问控制

**证据**: `public/api/admin/index.php:581-603`

```
if ($path === '/settings/system' && $method === 'POST') { if (!PlatformAuth::isSuperAdmin()) { respond(-1, '仅超级管理员可修改系统设置', null, 403); } $data = input(); $fields = [ 'site_name' => trim((string) ($data['site_name'] ?? '')), ... ]; foreach ($fields as $key => $value) { savePlatformSetting($pdo, $key, $value); }
```

写入路径仅应用了 trim()（第 587 行）——没有 htmlspecialchars，没有标签剥离，也没有 Brand::normalize。savePlatformSetting（第 162-170 行）使用 JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES 进行 json_encode 并存储，因此原始的 '</script>...' 字符串得以持久化。写入者被限制为 super_admin（PlatformAuth::isSuperAdmin，app/Security/PlatformAuth.php:70-72）；全仓库搜索未发现平台 'site_name' 的其他写入者（无数据库种子、无安装程序、无环境变量来源）。

### 步骤 5: 检查公共首页上的框架级防护

**证据**: `public/index.php:23-29`

```
header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store, ...'); header('X-Content-Type-Options: nosniff'); header('X-Frame-Options: DENY'); header('Referrer-Policy: strict-origin-when-cross-origin');
```

首页以 text/html 提供（因此 JSON 的非 HTML 豁免不适用）且未设置 Content-Security-Policy。虽然 app/Security/BackendSecurity.php:10 处存在一个能阻止内联脚本与事件处理程序的 CSP，但该方法仅被 public/health.php:6 和 public/install.php:13 调用，而 app/Core/App.php:61 仅提供 JSON API——两者都不在首页路径上。没有任何输出编码、CSP 或净化函数能够中和该汇聚点。

### 分析过程

- 问题 1: 用户可控数据是否到达 HTML/JS 输出汇聚点？-> 是。site_name 设置（通过 POST /api/admin/settings/system 写入，public/api/admin/index.php:587）在 app/Core/Brand.php:26-31 被读取，并在 public/index.php:68-76 被输出到内联 JSON-LD <script> 中。
- 问题 2: 模板引擎是否自动转义且未被绕过？-> 否。public/index.php 是原生 PHP，没有模板引擎；唯一的编码是 json_encode()，而其对标签闭合的保护被 JSON_UNESCAPED_SLASHES 显式禁用（public/index.php:76）。
- 问题 3: 该路径上是否存在显式的、上下文相关的编码/净化？-> 否。Brand::normalize（app/Core/Brand.php:61-65）仅移除控制字符；写入路径仅使用 trim()（public/api/admin/index.php:587）。两者都不编码 '<'、'>'、'/'。在斜杠未被转义的情况下，用于 JSON 的 json_encode 在 <script> 元素内部并不充分。
- 问题 4: 响应 Content-Type 是否为非 HTML？-> 否。public/index.php:23 发送 'Content-Type: text/html; charset=utf-8'。
- 问题 5: 该代码是否属于测试/演示/不可达？-> 否。这是真实的公共首页，一旦 storage/install.lock 存在（public/index.php:16-20），每一个未认证访问者都能访问。
- 结论: 所有检查均落至最终节点 -> 真实漏洞（TP）。记录的注意事项：唯一的写入者是超级管理员（PlatformAuth.php:70-72），因此这是特权来源的存储型 XSS，而非从低权限账户提升，这限制了严重程度，但并未消除缺失编码的缺陷。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/index.php:76 使用 JSON_UNESCAPED_SLASHES 将该设置输出到内联脚本中，该标志禁用了 json_encode 对 '/' 的默认转义，从而使 '</script>' 能够关闭该元素。
- public/index.php:42 与 :5 表明输入到该汇聚点的值是 Brand::name()，即原始存储的设置。
- app/Core/Brand.php:61-65 证明 normalize() 仅剥离控制字符并在 60 字符处截断，使 '<'、'>'、'/' 保持完整；52 字符的载荷 </script><img src=x onerror=alert(document.domain)> 恰好在上限之内。
- public/api/admin/index.php:587 仅用 trim() 存储 site_name，且 public/api/admin/index.php:139/169 使用 JSON_UNESCAPED_SLASHES 持久化它，因此写入时同样没有进行任何 HTML 净化。
- public/index.php:23-29 设置 text/html 且没有 Content-Security-Policy；唯一的 CSP（app/Security/BackendSecurity.php:10）并未在首页路径上加载。

## 4. 验证思路与复现步骤

- **前置条件**: storage/install.lock 存在以便首页渲染（public/index.php:16）；请求指向平台主机（DomainGuard，public/index.php:20）；测试者已通过 super_admin 认证，从而使 site_name 写入能够通过 public/api/admin/index.php:582 处的 isSuperAdmin 门禁。首页不存在 CSP，因此内联脚本与事件处理程序不会被阻止。

**复现步骤：**

1. 以 super_admin 登录平台管理 API，获取管理员令牌。
2. 向 /api/admin/settings/system 发送 POST 请求，body 字段 site_name 设为 </script><img src=x onerror=alert(document.domain)>（52 个字符，在 60 字符的 normalize 限制之内）。
3. 通过 GET /api/admin/settings/system 确认该设置已存储，或直接加载公共首页。
4. 在浏览器中加载公共首页 '/' 并查看页面源代码。

**测试样例：**

```
POST /api/admin/settings/system  body: {"site_name":"</script><img src=x onerror=alert(document.domain)>"}  then GET /
```

- **预期现象**: 首页源代码显示 JSON-LD 块以字面量 "</script>" 结束，其后跟着注入的 <img src=x onerror=alert(document.domain)> 标签，浏览器在加载时触发 alert(document.domain)。安全行为应显示斜杠被转义为 "<\/script>"（或输出采用 HTML 实体编码），且不含可执行标签。

## 5. 修复建议

在将该值嵌入内联脚本之前，按 JavaScript/JSON 上下文对其进行编码：使用 json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) 构建 JSON-LD，并移除 JSON_UNESCAPED_SLASHES（JSON_HEX_TAG 会将 '<' 和 '>' 转义为 \u003C/\u003E，这是内联脚本嵌入的权威修复）。或者将 JSON-LD 作为外部 application/ld+json 资源提供，从而无需内联打开 script 元素。纵深防御：在写入点 public/api/admin/index.php:587 和/或 Brand::normalize()（app/Core/Brand.php:61-65）中拒绝或剥离 site_name 中具有 HTML 意义的字符（'<'、'>'、'&'、'"'、'/'），并为公共首页添加 Content-Security-Policy（如 app/Security/BackendSecurity.php:10 已有用法），这样即使未来某个输出汇聚点出现回归，注入的内联脚本也无法执行。
