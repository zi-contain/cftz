## 1. 总结

- **漏洞类型**：misconfigured_rate_limiting (CWE-348)
- **标记位置**：public/api/widget/index.php:242
- **漏洞描述**：widget API 的 getClientIp()（public/api/widget/index.php:242-263）会先返回从客户端提供的请求头 CF-Connecting-IP、X-Forwarded-For、X-Real-IP 中取到的第一个语法有效 IP，之后才查看 REMOTE_ADDR，且不检查连接对端是否可信。该值被传入 IP 速率限制器 checkIpRateLimit（第 989、1106、2138 行）和 IP 封禁检查 checkVisitorBlocked（第 1127、1373、1576、1750 行），甚至还被持久化到 cc_visitors.ip_address（第 574/602/617 行），而封禁查询会读回该字段（第 419 行）。由于请求可以携带任意且不断轮换的转发请求头，攻击者能够绕过 IP 限流计数器，并使基于 IP 的访客封禁失效（告警中标记为 CWE-307；准确根因是使用了可信度较低的来源）。正确实现的 App\Security\ClientIp 类确实存在，并会验证对端（app/Security/ClientIp.php:23-47, 67-92），但 widget API 并未使用它。

## 2. 分析逻辑

### 步骤 1：阅读被标记的辅助函数

**证据**：`public/api/widget/index.php:242-263`

```
$headers = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR']; foreach ($headers as $header) { $value = (string) ($_SERVER[$header] ?? ''); if ($value !== '') { $ips = explode(',', $value); $ip = trim($ips[0]); if (filter_var($ip, FILTER_VALIDATE_IP)) { return $ip; } } } return '0.0.0.0';
```

已确认：客户端可控的转发请求头会被优先采用，REMOTE_ADDR 仅作为最后回退项，且未检查对端是否为可信代理。X-Forwarded-For 最左侧（攻击者可控）的元素会在首次语法校验通过时被返回。

### 步骤 2：与发现中引用的正确 ClientIp 实现进行比较

**证据**：`app/Security/ClientIp.php:25-47`

```
$remote = (string) ($_SERVER['REMOTE_ADDR'] ?? ''); if (!self::isTrustedProxy($remote)) { return self::normalize($remote); } $forwarded = (string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''); ... for ($i = count($chain) - 1; $i >= 0; $i--) { $candidate = self::normalize($chain[$i]); if ($candidate !== '' && !self::isTrustedProxy($candidate)) return $candidate; }
```

该发现的对比是准确的：仅当 REMOTE_ADDR 位于 TRUSTED_PROXIES 列表中时（isTrustedProxy，第 67-92 行），ClientIp 才会采用 X-Forwarded-For，并从右到左遍历链、跳过可信跳。widget 辅助函数完全没有做这些。

### 步骤 3：确认 ClientIp 在其他位置的使用（对应发现中“其他位置使用”的说法）

**证据**：`app/Security/RateLimiter.php:114`

```
$raw = ClientIp::get() . '|' . $extra;
```

ClientIp::get() 是共享 RateLimiter 以及管理员/商户登录限流所用标识符的来源（public/api/merchant/index.php:90,1022,1895；app/Domain/Ops/AlertService.php:28）。widget API 是绕过它的异类。

### 步骤 4：追踪 getClientIp() 进入 widget 入口点及其调用方

**证据**：`public/api/widget/index.php:899`

```
$clientIp = getClientIp();
```

这个可伪造的值会在每个 widget 请求中计算一次，并流向第 989 行（/init）、1106 行（/messages）、2138 行（/offline-message）的 checkIpRateLimit($pdo,$clientIp)，以及第 1127 行（/messages）、1373 行（/send）、1576 行（/upload）、1750 行（group routes）的 checkVisitorBlocked($pdo,$visitorId,$clientIp)。

### 步骤 5：阅读 IP 封禁检查

**证据**：`public/api/widget/index.php:416-426`

```
if (isset($columns['ip_address'])) { $stmt = $pdo->prepare('SELECT id, ' . $reasonSelect . ' FROM cc_visitors WHERE ip_address = :ip AND status = :status LIMIT 1'); $stmt->execute(['ip' => $ip, 'status' => 'blocked']); $blocked = $stmt->fetch(); if ($blocked) { respond(-1, '您的IP已被限制访问：'..., null, 403); } }
```

IP 封禁直接对可伪造 IP 做等值匹配。提供一个不同的 X-Forwarded-For 会使查询返回空结果，因此按 IP 被封禁的访客不会被阻止。

### 步骤 6：确认应用自身将可伪造的 IP 存储到封禁列中

**证据**：`public/api/widget/index.php:572-617 (also :2156)`

```
UPDATE cc_visitors SET last_seen_at = UTC_TIMESTAMP(), ip_address = :ip WHERE id = :id  ... 'ip' => $ip (from $clientIp)
```

cc_visitors.ip_address 会在每次 /init 和 /messages 时由 getClientIp() 写入。该列存在，并专门为 IP 封禁查询建立索引：database/013_widget_features.sql:6（ADD COLUMN ip_address VARCHAR(45)）和 :28-29（ADD KEY idx_visitor_ip）。因此，封禁列表完全以攻击者可影响的数据为键。

### 步骤 7：阅读 IP 速率限制器

**证据**：`public/api/widget/index.php:268-289`

```
SELECT COUNT(*) FROM cc_audit_logs WHERE actor_type = 'visitor' AND INET6_NTOA(ip) = :ip AND created_at >= UTC_TIMESTAMP() - INTERVAL 1 SECOND ... if ((int) $stmt->fetchColumn() > 3) { respond(-1, '请求过于频繁，请稍后再试', null, 429); }
```

该计数器以同一个可伪造 IP 为键；轮换请求头会让每个请求看起来都是不同的首次请求。（注意：对整个代码树执行 grep 可见，所有 cc_audit_logs 的 INSERT 都使用 actor_type 'platform'/'merchant'/'agent'/'tenant'——没有任何一处写入 'visitor'——因此这个特定的限流还因另一个独立原因而失效。这并不改变 IP 派生值受攻击者控制这一事实；它使缺失的以 IP 为键的控制成为真实漏洞，而非误报。）

### 步骤 8：检查生效的框架/代理保护

**证据**：`app/Core/bootstrap.php:1-37, deploy/nginx/aimu-customer-cloud.conf:5-6,39-52`

```
bootstrap only sets error handling, loads Env and calls LicenseGate::enforce(); nginx limit_req zones exist only for aimu_admin_login and /s/ customer pages - there is no limit_req on /api/widget.
```

在 PHP 运行前，既没有应用层也没有 nginx 层会清理/覆盖这些转发请求头，也没有针对 widget API 的 nginx 速率限制。部署文档（aimu-customer-cloud.conf:206-211）仅*建议*配置源站防火墙以及 CDN 的 set_real_ip_from，而即便遵循该指引，也不会剥离 getClientIp() 读取的原始 HTTP_X_FORWARDED_FOR/HTTP_CF_CONNECTING_IP 值。代码中没有任何缓解措施。

### 分析过程

- Q1：安全相关值是否来自攻击者可控输入？-> 是：getClientIp() 返回最左侧的、由客户端提供的转发 IP（public/api/widget/index.php:245-261），而 REMOTE_ADDR 仅作为最后手段（步骤 1）。
- Q2：该值是否实际用于安全控制？-> 是：它被用作 IP 速率限制器（第 989/1106/2138 行）和 IP 封禁查询（第 1127/1373/1576/1750 行，封禁查询位于 416-426 行）的键——见步骤 4/5/6。
- Q3：该路径上是否存在有效防护？-> 否。辅助函数中没有信任检查，此处未使用 ClientIp，bootstrap 未添加任何检查，且 nginx 既未清理请求头，也未对 /api/widget 限速（步骤 2/8）。
- Q4：该控制在实际中是否可绕过？-> 对 IP 封禁而言为是：轮换 X-Forwarded-For 会使第 419 行的等值匹配落空，因此被封禁的 IP 会被放行；对限流而言，以 IP 为键的计数器也会因同样的轮换而被绕过。
- Q5：这是生产环境中可访问的代码（而非测试/死代码）吗？-> 是：public/api/widget/index.php 是公共 HTTP 入口点；无需调用方，因为 Web 服务器会直接调用它。

## 3. 结论

**真实漏洞 (TP)**

**关键证据：**

- public/api/widget/index.php:242-263 - getClientIp() 在 REMOTE_ADDR 之前采用 CF-Connecting-IP/X-Forwarded-For/X-Real-IP，且不执行可信代理检查。
- public/api/widget/index.php:419 - IP 封禁查询 'WHERE ip_address = :ip AND status = :status' 以可伪造值为键。
- public/api/widget/index.php:574,602,617 - 应用将 getClientIp() 持久化到 cc_visitors.ip_address，而这正是封禁检查读取的列。
- public/api/widget/index.php:989,1106,2138 - checkIpRateLimit 的限流以可伪造 IP 为键，用于 /init、/messages 和 /offline-message。
- app/Security/ClientIp.php:27-47,67-92 - 正确的模式（对端信任检查）已存在于代码库中，但 widget API 未使用。
- database/013_widget_features.sql:6,28-29 - ip_address 列和 idx_visitor_ip 索引正是为 IP 封禁查询而存在，确认该控制实际生效。

## 4. 验证思路与复现步骤

- **前置条件**：widget API 可未经认证访问（public/api/widget/index.php，除许可证门禁外无其他认证），且服务器不会在 PHP 之前覆盖转发请求头（应用内或文档化的 nginx 层均无剥离；CF-Connecting-IP 会最先被检查，因此任何未由会清理请求头的代理（例如 Cloudflare）前置的部署都可被伪造）。对于封禁绕过路径，必须存在一条 status='blocked' 且 ip_address 已知的 cc_visitors 记录，并且攻击者必须持有有效的 visitor_token（可从 /init 获取，该接口无需认证）。

**复现步骤：**

1. 从已被封禁的访客 IP 发起请求，通过 POST /api/widget/init 获取 visitor_token（anonymous_id/token 不绑定到 IP）。
2. 调用一个受 token 保护的端点，例如 POST /api/widget/send，不携带 X-Forwarded-For 请求头；观察来自 checkVisitorBlocked（第 424 行）的 HTTP 403 '您的IP已被限制访问'。
3. 重复同一调用，并添加请求头 'X-Forwarded-For: 203.0.113.77'（一个有效但无关的 IP）；getClientIp() 会返回它，第 419 行的封禁查询找不到匹配的已封禁行，请求以 HTTP 200 继续。
4. 对于限流，连续发送多个 POST /api/widget/init 请求，每个请求使用不同的 X-Forwarded-For 值，确认没有任何请求被 checkIpRateLimit 以 HTTP 429 响应。

**测试样例：**

```
POST /api/widget/send HTTP/1.1
Host: <origin>
X-Visitor-Token: <valid token>
X-Forwarded-For: 203.0.113.77
Content-Type: application/json

{"conversation_id":1,"type":"text","body":"hello"}
```

- **预期现象**：当提供伪造的 X-Forwarded-For 时，来自 cc_visitors.ip_address 中已存在且 status='blocked' 的 IP 的请求会返回 200（消息被接受），而不带该请求头的同一请求返回 403——即 IP 封禁不再匹配。等价地，在一串 /init 调用中轮换 X-Forwarded-For 会避开预期的 429 IP 限流响应。

## 5. 修复建议

将 widget/index.php 中临时的请求头遍历替换为经过验证的辅助函数：在所有计算 $clientIp 的位置（第 899 行）以及 getClientIp() 内部使用 App\Security\ClientIp::get()（app/Security/ClientIp.php:23），或者删除 getClientIp() 并直接调用 ClientIp::get()。仅当 REMOTE_ADDR 位于 TRUSTED_PROXIES 列表中时，ClientIp 才会采用转发请求头，并从可信边缘向内遍历链，因此派生出的地址无法被客户端伪造。确保 TRUSTED_PROXIES 填入 CDN/负载均衡器的源地址范围（SECURITY.md:151-159），使信任检查拥有正确的允许列表；否则 ClientIp 会安全回退到 REMOTE_ADDR。此外，考虑记录以会话/token 身份而非仅 IP 为键的速率限制/限流计数器，并注意 checkIpRateLimit 当前统计的是 actor_type='visitor' 的 cc_audit_logs 行，而没有任何代码路径会写入这种行，因此 /init 和 /offline-message 的限流应重新实现（例如通过 RateLimiter）才能真正生效。
