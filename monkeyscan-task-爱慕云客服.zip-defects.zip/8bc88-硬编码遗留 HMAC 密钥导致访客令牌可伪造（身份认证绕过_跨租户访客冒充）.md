## 1. 总结

- **漏洞类型**：hardcoded_credentials (CWE-798)
- **标记位置**：public/api/widget/index.php:727
- **漏洞描述**：verifyVisitorToken() 会无条件接受一种访客令牌：该令牌使用硬编码字面量密钥 'widget_secret_v1' 对攻击者选定的 payload 计算 HMAC-SHA256 签名而生成；同时，它也会接受使用 ChatCollaborationService::visitorTokenSecret() 中真实密钥生成的签名。该字面量已被提交到版本控制（public/api/widget/index.php 受 git 跟踪），因此任何未经身份验证的攻击者都能为任意 visitor_id/site_id 和 exp 伪造有效令牌，并调用 /messages、/typing、/read、/send、/upload 等访客端点。这样一来，用于管控 widget API 的令牌便可被绕过，符合 CWE-798 硬编码凭据模式。

## 2. 分析逻辑

### 步骤 1: 读取被标记的验证器

**证据**: `public/api/widget/index.php:719-736`

```
function verifyVisitorToken(string $token): ?array {
    ...
    $expected = hash_hmac('sha256', $payload, ChatCollaborationService::visitorTokenSecret());
    $legacyExpected = hash_hmac('sha256', $payload, 'widget_secret_v1');
    if (!hash_equals($expected, $sig) && !hash_equals($legacyExpected, $sig)) {
        return null;
    }
    $data = json_decode(base64_decode($payload), true);
    if (!is_array($data) || ($data['exp'] ?? 0) < time()) { return null; }
    return $data;
}
```

只要签名等于使用真实密钥计算的 hash_hmac，或等于使用字面量 'widget_secret_v1' 计算的 hash_hmac，该签名就会被接受。遗留分支是无条件的——没有环境变量保护、功能开关或配置门禁。payload 完全由攻击者控制，且仅校验 'exp'（可为任意未来时间值）。

### 步骤 2: 确认密钥字面量是已提交的源代码

**证据**: `.gitignore:1（唯一条目是 verify_requirements/） ; git ls-files public/api/widget/index.php`

```
git ls-files --error-unmatch public/api/widget/index.php  ->  public/api/widget/index.php (tracked)
```

public/api/widget/index.php 受 git 跟踪，因此字符串 'widget_secret_v1' 是公开的。它并非占位符（例如 'changeme'/'TODO'），而是 hash_hmac 调用中实际使用的 HMAC 签名密钥。

### 步骤 3: 检查真实密钥派生是否存在任何条件保护

**证据**: `app/Domain/Chat/ChatCollaborationService.php:131-139`

```
public static function visitorTokenSecret(): string {
    $secret = trim((string) Env::get('WIDGET_TOKEN_SECRET', ''));
    if (strlen($secret) >= 32) { return $secret; }
    $appKey = trim((string) Env::get('APP_KEY', ''));
    return $appKey !== '' ? hash('sha256', $appKey . '|widget-token') : hash('sha256', 'aimu-widget-install-required');
}
```

真实密钥虽从环境变量加载，但这与当前发现无关：遗留字面量分支完全绕过了已配置的密钥。即使正确配置了 WIDGET_TOKEN_SECRET，也无法关闭 'widget_secret_v1' 路径。回退值 hash('sha256','aimu-widget-install-required') 同样是公开的默认值。

### 步骤 4: 追踪令牌来源以及从 HTTP 的可达性

**证据**: `public/api/widget/index.php:994,1005 ; public/api/widget/index.php:1119,1124,1130-1138 ; public/api/widget/index.php:1240,1243`

```
$visitorToken = trim((string) ($data['visitor_token'] ?? '')); ... $tokenData = verifyVisitorToken($visitorToken);
// /messages: $visitorId = (int) ($tokenData['visitor_id'] ?? 0);
// SELECT id, tenant_id, site_id, status FROM cc_conversations WHERE id = :id AND visitor_id = :visitor_id
```

令牌直接从请求体或 X-Visitor-Token 头读取，并在 9 个处理程序中传给 verifyVisitorToken（/init、/messages、/typing、/read、/send、/group/send、/upload 等）。提取出的 visitor_id 仅用于校验会话所有权（visitor_id = :visitor_id）；来自令牌的 site_id 在 /messages 处理程序中未重新校验，因此伪造的令牌可以跨越租户/站点边界。

### 步骤 5: 排除测试/演示上下文

**证据**: `public/api/widget/index.php:719（生产路由分发器）`

```
if ($path === '/messages' && $method === 'GET') { ... }  // public API entry point
```

这是 public/ 下的生产 widget API 分发器，并非测试/规格/演示代码。该代码会处理真实请求；不存在移除遗留分支的构建时或运行时条件。

### 分析过程

- Q1：被标记的值是真实密钥（而非占位符/测试/示例）吗？-> 是。'widget_secret_v1' 在 public/api/widget/index.php:727 的 hash_hmac 中用作实际的 HMAC-SHA256 签名密钥，而不是占位符令牌。
- Q2：该密钥是从环境变量/密钥管理器加载的吗？-> 否。它是源代码中的字符串字面量；基于环境变量的 ChatCollaborationService::visitorTokenSecret() 是并行分支，而非替代项（ChatCollaborationService.php:131-139，widget/index.php:726-727）。
- Q3：该文件不在版本控制中吗？-> 否。git ls-files 确认 public/api/widget/index.php 受跟踪；.gitignore 仅列出 verify_requirements/。
- Q4：该值是否使用保存在仓库外部的密钥进行加密或哈希？-> 否。该字面量本身就是明文 HMAC 密钥；没有任何外部密钥保护它。
- Q5：该代码仅用于测试/演示/文档吗？-> 否。它是 public/api/widget/index.php 中的生产 widget API 端点分发器。
- 结论 -> 真实漏洞（TP）：已提交的生产源代码中存在硬编码加密密钥，且直接用于认证安全敏感请求。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:727 计算 hash_hmac('sha256', $payload, 'widget_secret_v1')，且第 728 行无条件接受该签名。
- public/api/widget/index.php 受 git 跟踪（.gitignore 仅包含 verify_requirements/），因此签名密钥是公开的。
- public/api/widget/index.php:719-735 仅校验由两部分组成的令牌结构以及未来的 'exp'；payload（visitor_id/site_id）完全由攻击者选择。
- public/api/widget/index.php:1119-1138 使用此验证器对 /messages 进行访问控制，并仅依据 visitor_id = :visitor_id 进行授权，因而可冒充任意访客。
- app/Domain/Chat/ChatCollaborationService.php:131-139 展示了真实密钥路径，但并未移除遗留字面量分支。

## 4. 验证思路与复现步骤

- **前置条件**：widget API（public/api/widget/index.php）已部署并可通过 HTTP 访问。调用时无需身份验证。攻击者知道或能够猜测目标 visitor_id（顺序整数）以及 site_id/public id。无论是否配置 WIDGET_TOKEN_SECRET，遗留分支始终处于活动状态。

**复现步骤：**

1. 构造形如 {"visitor_id": <victim_id>, "site_id": <target_site_id>, "exp": <now + large>} 的 payload JSON。
2. 对 JSON 进行 Base64 编码，得到 $payload。
3. 使用公开已知的字面量密钥计算 $sig = HMAC-SHA256($payload, 'widget_secret_v1')。
4. 将令牌构造成 $payload . '.' . $sig。
5. 向 /messages?conversation_id=<victim_conversation_id> 发送请求，并携带请求头 'X-Visitor-Token: <token>'（或请求体中的 visitor_token），然后观察响应。

**测试样例：**

```
GET /api/widget/.../messages?conversation_id=<victim_conv_id>&after_id=0 HTTP/1.1\nX-Visitor-Token: <base64({"visitor_id":<victim_id>,"site_id":<site_id>,"exp":9999999999})>.<hmac_sha256(payload,'widget_secret_v1')>
```

- **预期现象**：伪造的令牌会被接受（不会返回 401 'visitor token invalid/expired'）；该端点会返回受害者会话的私密消息，并且 /typing 或 /read 等操作会在攻击者并不拥有的会话上成功。使用错误密钥签名的请求会返回 401，从而可确认遗留分支为接受路径。

## 5. 修复建议

删除 verifyVisitorToken 中的遗留分支（public/api/widget/index.php:727-728），使签名仅与 ChatCollaborationService::visitorTokenSecret() 比较。绝不要将签名密钥保留为源代码字面量。如果确实需要向后兼容，请执行有期限的轮换：重新签发令牌，在明确的截止时间后拒绝遗留密钥，并将其完全移除。此外，让 visitorTokenSecret()（app/Domain/Chat/ChatCollaborationService.php:131-139）采用故障关闭（fail closed）策略：当 WIDGET_TOKEN_SECRET 和 APP_KEY 均未设置时抛出异常，而不是回退到公开常量 hash('sha256','aimu-widget-install-required')；将令牌绑定到 site/tenant，并在每个处理程序中校验 site_id；同时缩短 1 年的令牌有效期。
