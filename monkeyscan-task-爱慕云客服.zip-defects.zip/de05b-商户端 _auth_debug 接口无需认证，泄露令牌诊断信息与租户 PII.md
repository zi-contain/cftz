## 1. 总结

- **漏洞类型**：missing_authentication (CWE-306)
- **标记位置**：public/api/merchant/index.php:975
- **漏洞描述**：商户 API 在第 975 行注册了 POST /auth/debug，该位置明显早于 requireMerchant() 认证门禁首次被调用的第 1887 行。该处理程序将攻击者提供的 token 直接传入 TenantAuth::debugToken()，既未进行认证，也未施加速率限制。debugToken() 会返回一个 token 有效性判定器（signature_valid、expired）；更严重的是，它会根据 token 载荷中未经验证的 `uid` 执行数据库查询（TenantAuth.php:509-526），并返回账户的手机号、tenant_id 和 tenant_name。由于在该查询之前从未强制执行签名校验，攻击者构造的未签名 token 可泄露任意用户 id 的 PII（个人身份信息）。

## 2. 分析逻辑

### 步骤 1：定位被标记的路由并确认其先于认证门禁

**证据**：`public/api/merchant/index.php:975`

```
if ($path === '/auth/debug' && $method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $token = (string) ($input['token'] ?? '');
    $clientType = (string) ($_SERVER['HTTP_X_CLIENT_TYPE'] ?? '');
    $debug = \App\Security\TenantAuth::debugToken($token);
    $debug['client_type_header'] = $clientType;
    $debug['client_header_is_app'] = $clientType === 'app';
    respond(200, 'ok', $debug);
}
```

/auth/debug 路由在第 975 行声明。Grep 显示 requireMerchant() 首次在第 1887 行被调用（`$user = requireMerchant();`），因此该处理程序会在任何认证之前运行。该处理程序直接对请求提供的 `token` 调用 debugToken()，并将完整结果对象返回给客户端。它没有调用 rateLimit()。

### 步骤 2：验证认证门禁位于该路由之后且此路径上不存在认证

**证据**：`public/api/merchant/index.php:1887`

```
$user = requireMerchant();
$pdo = Database::connection();
$tenantId = (int) $user['tenant_id'];
```

requireMerchant() 是商户认证门禁（定义于第 173 行；它会执行 TenantAuth::authenticateByToken/check，并在失败时响应 401）。它在第 1887 行才首次被调用；对 `requireMerchant` 的 grep 返回的调用点位于 1887、7990、8013、8047、8110，全部在 /auth/debug 处理程序之后。此前不存在全局认证：bootstrap.php 仅加载 env/autoload，DomainGuard::requirePlatformHost()（第 75 行）是主机名检查，LicenseGate::enforce() 是许可证检查——它们均不认证调用方。

### 步骤 3：追踪攻击者提供的 token 进入 debugToken 的过程

**证据**：`app/Security/TenantAuth.php:461`

```
public static function debugToken(string $token): array
{
    $result = [
        'token_present' => $token !== '',
        'token_length' => strlen($token),
        'token_format_valid' => false,
        'signature_valid' => false,
        ...
    ];
```

debugToken() 是公共静态方法，自身没有任何授权检查。它将 token 解析为 payloadB64 + signature，计算预期签名，并报告 signature_valid、expired、user_id、issued_at、expires_at——即一个在认证前即可使用的 token 有效性判定器。

### 步骤 4：确认 PII 泄露不要求有效签名

**证据**：`app/Security/TenantAuth.php:509`

```
if (!empty($payload['uid'])) {
    try {
        $stmt = Database::connection()->prepare(
            'SELECT u.id, u.tenant_id, u.status, u.phone, u.display_name,
                    t.status AS tenant_status, t.name AS tenant_name, t.deleted_at AS tenant_deleted
             FROM cc_tenant_users u
             LEFT JOIN cc_tenants t ON t.id = u.tenant_id
             WHERE u.id = :id LIMIT 1'
        );
        $stmt->execute(['id' => (int) $payload['uid']]);
        ...
        $result['user_phone'] = $user['phone'] ?? '';
        $result['tenant_id'] = $user['tenant_id'] ?? null;
        $result['tenant_name'] = $user['tenant_name'] ?? '';
```

第 509 行的数据库查询仅以 `!empty($payload['uid'])` 为条件，而从不以 `$result['signature_valid']` 为条件。第 488-489 行的签名检查之后没有提前返回。攻击者可构造一个 token：载荷为 base64url('{"uid":N}')，后接任意非空签名（第 481 行的计数检查仅要求两部分均非空），从而获取该 user id 对应的 user_phone、tenant_id、tenant_name、tenant_status 和 auth_would_pass。由于 user id 连续，这是一条未经认证的 PII 枚举路径——比扫描器所称的“仅在 token 有效时”更严重。

### 步骤 5：确认网络可达性以及不存在速率限制/拦截

**证据**：`deploy/nginx/aimu-customer-cloud.conf:49`

```
location /api/merchant/ {
    rewrite ^/api/merchant/(.*)$ /api/merchant/index.php?route=$1&$args last;
}
```

Nginx 将 POST /api/merchant/auth/debug 映射到 index.php?route=/auth/debug；routePath()（index.php:147-171）将其解析为 '/auth/debug'。没有 nginx location 会拒绝此路径（deny 规则覆盖 app/、storage/、.env、*.lock|log|sql|md|txt、install/build——但不包括 /auth/debug）。CORS 块（第 14-69 行）仅拒绝携带不允许的 Origin 头的请求；不带 Origin 的服务器到服务器请求会跳过它。应用内的 rateLimit()（index.php:931-955）从未被 /auth/debug 处理程序调用。前端通过 authDebugApi（public/merchant-app/assets/index-wl2mZM6M.js:45）调用此路由，确认它是一个在线端点。

### 分析过程

- Q1：被标记的端点是否需要认证？ -> 否。/auth/debug 处理程序位于 public/api/merchant/index.php:975，先于第 1887 行的 requireMerchant() 执行，且不受任何更早的认证检查覆盖（bootstrap.php:4-36、DomainGuard.php:10-37 和 LicenseGate 均不进行认证）。
- Q2：该端点是否向调用方暴露敏感数据？ -> 是。它返回 debugToken() 的完整结果（public/api/merchant/index.php:982），其中包含 signature_valid/expired（有效性判定器），并且通过 TenantAuth.php:509-526 处未受保护、以 uid 为键的查询，返回 user_phone、tenant_id 和 tenant_name。
- Q3：敏感数据是否以有效 token 为前提？ -> 否。TenantAuth.php:509 处的数据库查询仅检查 `!empty($payload['uid'])`；TenantAuth.php:488-489 处的签名检查从未阻止它，因此未签名的伪造 token 会泄露 PII。
- Q4：该路由在生产环境中是否可达且未限流？ -> 是。Nginx 会重写它（deploy/nginx/aimu-customer-cloud.conf:49-51），没有 deny 规则匹配它，CORS 仅在存在 Origin 头时适用，并且该处理程序从未调用 rateLimit()（index.php:931-955）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/merchant/index.php:975 - POST /auth/debug 处理程序在无认证的情况下调用 TenantAuth::debugToken($token)，并返回完整结果。
- public/api/merchant/index.php:1887 - requireMerchant() 认证门禁直到第 1887 行才首次到达，比 /auth/debug 路由晚了 900 多行。
- app/Security/TenantAuth.php:509 - 以攻击者控制的 $payload['uid'] 为键的数据库查询仅由 !empty(uid) 守护，而非由签名有效性守护。
- app/Security/TenantAuth.php:522-525 - 响应从查询到的用户设置 user_phone、tenant_id、tenant_name、tenant_status。
- public/api/merchant/index.php:931 - rateLimit() 存在，但未被 /auth/debug 处理程序调用。
- deploy/nginx/aimu-customer-cloud.conf:49 - nginx 暴露了 /api/merchant/*，包括 /auth/debug，且没有 deny 规则。

## 4. 验证思路与复现步骤

- **前置条件**：系统已安装（存在 storage/install.lock，这是 index.php:957 所要求的），因此该路由处于启用状态。无需认证、会话或 token。请求必须发送到已配置的平台主机（DomainGuard::requirePlatformHost），且该主机对外公开。不应发送 Origin 头，以便跳过 CORS 允许列表块。

**复现步骤：**

1. 构造一个未签名 token：对 JSON {"uid":1} 进行 base64url 编码得到载荷部分，追加字面量 '.'，然后追加任意非空字符串作为签名（例如 payload + '.x'）。
2. 将其 POST 到商户 API 调试路由，例如使用 JSON 请求体 {"token":"<crafted>"} 向 POST /api/merchant/auth/debug 发送请求，并且不带 Authorization/token 头，也不带 Origin 头。
3. 读取响应体中 result 下的 JSON 内容：即使 signature_valid 为 false，user_found、user_phone、tenant_id、tenant_name 和 auth_would_pass 也会被填充。
4. 递增 uid 值并重复请求，以枚举其他商户的联系数据。

**测试样例：**

```
curl -s -X POST 'https://<platform-host>/api/merchant/auth/debug' -H 'Content-Type: application/json' --data '{"token":"'"$(printf '{"uid":1}' | base64 | tr '+/' '-_' | tr -d '=')"'.invalidsig"}'
```

- **预期现象**：HTTP 200，code 为 200，且 result 对象中 signature_valid=false，但 user_found=true，并且 user_phone / tenant_id / tenant_name 包含目标账户的真实值。安全的实现应要求认证（401），或拒绝为未通过验证的签名返回 PII。

## 5. 修复建议

将 /auth/debug 处理程序置于认证之后——将其移动到 requireMerchant() 之下（或显式调用 requireMerchant()），并限制为仅操作员可用，和/或将其从生产环境中编译移除（例如仅在设置 APP_DEBUG 风格环境标志时注册）。在 TenantAuth::debugToken() 中，仅在 `hash_equals` 确认 signature_valid 之后，才执行租户/用户查询并返回 PII（在第 489 行失败时提前返回），同时从诊断载荷中移除原始 phone/tenant_name。对任何未受认证保护的认证端点应用 rateLimit()，并在生产环境中为 /api/merchant/auth/debug 添加 nginx deny 规则。
