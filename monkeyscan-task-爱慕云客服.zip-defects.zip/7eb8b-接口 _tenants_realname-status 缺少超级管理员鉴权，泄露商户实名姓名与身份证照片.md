## 1. 总结

- **漏洞类型**：broken_function_level_authorization（CWE-862）
- **标记位置**：public/api/admin/index.php:1565
- **漏洞描述**：管理端 API 路由 /tenants/realname-status 仅受全局 requireAdmin() 调用（身份认证）保护，该调用只验证平台会话是否存在、X-Token 请求头是否与会话中的 admin_api_token 匹配，但不执行任何角色检查。针对任意可枚举的 tenant_id，该处理程序都会返回租户的明文法定姓名（realname_name）、脱敏身份证号以及身份证正反面图片 URL；而同级的 /tenants/detail 处理程序则通过 PlatformAuth::isSuperAdmin() 有意将相同的实名字段限定为仅超级管理员可访问。由于 cc_platform_users.role 枚举还包含五个非超级管理员角色（admin、finance、risk、support、auditor），且这些角色均可通过 requireAdmin()，因此该路由绕过了预期的仅限超级管理员控制，可导致 PII 被大规模泄露。

## 2. 分析逻辑

### 步骤 1: 读取被标记的处理程序

**证据**: `public/api/admin/index.php:1565`

```
if ($path === '/tenants/realname-status' && $method === 'GET') {
    $tenantId = (int) ($_GET['tenant_id'] ?? 0);
    if ($tenantId <= 0) { respond(422, '缺少商户 ID'); }
    $stmt = $pdo->prepare('SELECT realname_status, realname_name, realname_idcard_masked, realname_verified_at, realname_front_image, realname_back_image FROM cc_tenants WHERE id = :id AND deleted_at IS NULL');
    $stmt->execute(['id' => $tenantId]);
    $row = $stmt->fetch();
    if (!$row) { respond(404, '商户不存在'); }
    respond(200, 'success', [ 'realname_name' => $row['realname_name'] ?? null, 'realname_idcard_masked' => ..., 'realname_images' => ['front_image' => $row['realname_front_image'] ?? null, 'back_image' => $row['realname_back_image'] ?? null] ]);
}
```

该处理程序接收客户端提供的 tenant_id，按主键查询 cc_tenants，未做租户范围限制，并返回未脱敏的 realname_name、realname_idcard_masked 以及两张身份证图片 URL。该代码块内没有 PlatformAuth::isSuperAdmin() 或任何角色检查。下一步：检查该 API 依赖的认证辅助函数。

### 步骤 2: 检查 requireAdmin() —— 仅身份认证

**证据**: `public/api/admin/index.php:83`

```
function requireAdmin(): array {
    if (!PlatformAuth::check()) { respond(912, '登录身份已失效', null, 401); }
    $token = (string) ($_SERVER['HTTP_TOKEN'] ?? '');
    $sessionToken = (string) ($_SESSION['admin_api_token'] ?? '');
    if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) { respond(912, '登录身份已失效', null, 401); }
    return PlatformAuth::user() ?? [];
}
```

requireAdmin() 仅强制要求 (a) 存在平台会话，以及 (b) X-Token 请求头等于会话中的 admin_api_token。它会返回用户，但不执行角色/权限校验——这是身份认证，而非授权。

### 步骤 3: 定位相对于请求分发的全局认证调用点

**证据**: `public/api/admin/index.php:386`

```
$user = requireAdmin();
$pdo = Database::connection();

// ... route handlers follow, each a separate if ($path === ...)
```

登录/验证码/许可证相关分组之后的所有路由，包括第 1565 行的 /tenants/realname-status，都在单次 requireAdmin() 调用下运行。此调用与各处理程序之间不存在路由级或全局角色门禁；角色检查需在各处理程序中逐一执行（例如第 1008、1280、1527、3343 行）。

### 步骤 4: 与同样限制该 PII 的同级 /tenants/detail 处理程序进行对比

**证据**: `public/api/admin/index.php:1228`

```
$realnameEvidence = null;
if (PlatformAuth::isSuperAdmin()) {
    $evidenceStmt = $pdo->prepare('SELECT t.realname_status, t.realname_name_masked, t.realname_idcard_masked, t.realname_phone_masked, t.realname_cipher, t.realname_front_image, t.realname_back_image ... FROM cc_tenants t ...');
    ...
}
```

同级的 /tenants/detail 路由仅在 PlatformAuth::isSuperAdmin() 为 true 时才返回相同的实名相关列（包括 realname_front_image / realname_back_image）。这正是 /tenants/realname-status 静默绕过的预期控制——属于“有效防护”缺口，而不只是缺少检查。

### 步骤 5: 确认 isSuperAdmin() != check() 并枚举角色

**证据**: `app/Security/PlatformAuth.php:70`

```
public static function isSuperAdmin(): bool { return (self::user()['role'] ?? '') === 'super_admin'; }
```

isSuperAdmin() 仅在角色为 'super_admin' 时为 true。PlatformAuth::attempt()（第 26 行）会为任意 status='active' 的 cc_platform_users 行建立登录，无论其角色为何。结合 schema 枚举可知，五个非超级管理员角色均可获得有效会话。

### 步骤 6: 从 schema 枚举平台用户角色

**证据**: `database/schema.sql:13`

```
role ENUM('super_admin','admin','finance','risk','support','auditor') NOT NULL,
```

cc_platform_users 共有六个角色，其中仅一个（'super_admin'）具有特权。文件内第 1427 行和第 1699 行的用法（['super_admin','risk'] 和 ['super_admin','risk','auditor']）确认，'risk' 和 'auditor' 是真实存在且可分配的低权限角色，它们能够通过身份认证并穿过 requireAdmin()。

### 步骤 7: 确认暴露字段为未脱敏 PII

**证据**: `database/025_realname_encrypted_fields.sql:21`

```
-- 1. realname_name（存量兼容，新数据不再写入）
... ADD COLUMN realname_name VARCHAR(120) NULL COMMENT '实名姓名（存量明文，已弃用）'
-- 3. realname_name_masked（脱敏姓名） ... ADD COLUMN realname_name_masked VARCHAR(64) NULL
```

realname_name 被记录为明文法定姓名（存量明文 = legacy plaintext），与 realname_name_masked 不同。被标记的查询选择的是 realname_name（原始值），而 /tenants/detail 选择的是 realname_name_masked，这确认 realname-status 路由泄露了未脱敏值。

### 步骤 8: 检查是否存在路由级或网关级控制

**证据**: `deploy/nginx/aimu-customer-cloud.conf:44`

```
location /api/admin/ {
    rewrite ^/api/admin/(.*)$ /api/admin/index.php?route=$1&$args last;
}
```

反向代理配置仅将 /api/admin/* 重写到 index.php；它没有为管理端路由应用基于角色的访问控制、basic auth 或 allow/deny。因此没有可依赖的 API 网关强制措施。

### 分析过程

- Q1：该端点是否执行特权/管理操作？-> 是。它是一个管理端 API 处理程序（public/api/admin/index.php:1565），返回租户的明文法定姓名、脱敏身份证号和身份证图片 URL；同级的 /tenants/detail（第 1228 行）将相同字段视为仅超级管理员可访问。
- Q2：是否配置了路由级角色授权（中间件、安全配置）？-> 否。唯一的路由级防护是第 386 行的 requireAdmin()，它仅检查会话 + X-Token（第 83-94 行），而不检查角色。nginx 不执行角色强制（deploy/nginx/aimu-customer-cloud.conf:44）。
- Q3：是否存在方法级角色授权（注解、装饰器）？-> 否。第 1565-1593 行的处理程序块中没有 isSuperAdmin()/角色检查，而同级的第 1008、1228、1280、1527 行则存在此类检查。
- Q4：是否存在执行授权的 API 网关/代理？-> 否。该代理仅将路径重写到 index.php（deploy/nginx/aimu-customer-cloud.conf:38-46）。
- Q5：该代码是否处于测试/演示/生成/仅内部环境，或不可达？-> 否。它是 public/api/admin/index.php 中的生产 HTTP 处理程序，可通过 GET /api/admin/tenants/realname-status 访问。
- Q6：交叉检查控制缺口 -> /tenants/detail（第 1228 行）中的相同 PII 由 PlatformAuth::isSuperAdmin() 限制，而 cc_platform_users.role 包含 5 个可通过 requireAdmin() 的非超级管理员角色（schema.sql:13）；因此该路由绕过了预期控制。
- 结论：真实漏洞（TP）—— 功能级授权失效，允许较低权限的平台角色读取租户 PII。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/admin/index.php:1565-1593 处理 GET /tenants/realname-status，返回 realname_name（未脱敏）、realname_idcard_masked、realname_front_image 和 realname_back_image，且没有任何角色检查。
- public/api/admin/index.php:83-94 requireAdmin() 仅校验会话存在与 X-Token 是否相等——没有角色/权限检查。
- public/api/admin/index.php:386 将 requireAdmin()（仅身份认证）应用于所有后续路由；角色门禁按处理程序选择性启用，而此处缺失。
- public/api/admin/index.php:1228 展示了预期控制：/tenants/detail 仅在 PlatformAuth::isSuperAdmin() 为 true 时暴露相同的实名/身份证字段。
- app/Security/PlatformAuth.php:70-73 isSuperAdmin() 仅在角色为 'super_admin' 时为 true；attempt()（第 26 行）允许任意角色的活跃平台用户通过。
- database/schema.sql:13 cc_platform_users.role ENUM 包含 admin、finance、risk、support、auditor——这五个非超级管理员角色均能通过身份认证并到达该路由。
- database/025_realname_encrypted_fields.sql:21-43 将 realname_name 记录为遗留明文，与脱敏列不同，确认该 PII 未脱敏。

## 4. 验证思路与复现步骤

- **前置条件**：平台已安装（存在 storage/install.lock）。存在一个平台账号，其角色为任意非超级管理员角色（例如 'risk'、'auditor'、'admin'、'finance'、'support'），且 status='active'。攻击者可通过 POST /api/admin/login 登录，获取会话及返回的 token；目标租户必须存在且未被软删除。

**复现步骤：**

1. 以低权限平台账号登录：使用 JSON {"username":"<risk_or_auditor_user>","password":"<password>"} 向 POST /api/admin/login 发起请求。捕获 'result.token' 值和会话 cookie。
2. 携带会话 cookie，将 X-Token 请求头设为捕获的 token，发送读取请求：GET /api/admin/tenants/realname-status?tenant_id=1（也可尝试 /api/admin/index.php?route=tenants/realname-status&tenant_id=1）。
3. 使用 tenant_id=2,3,4... 重复操作以枚举各租户；该端点不执行租户范围限制，因此任何有效 id 都会返回对应商户的身份数据。
4. 使用同一低权限会话，与 GET /api/admin/tenants/detail?tenant_id=1 对比，可观察到由于 isSuperAdmin() 为 false，其 realname_evidence 字段为 null。

**测试样例：**

```
GET /api/admin/tenants/realname-status?tenant_id=1 HTTP/1.1
Host: <platform-host>
X-Token: <token_from_low_privilege_login>
Cookie: <platform_session_cookie>
```

- **预期现象**：响应为 HTTP 200，code 为 200；对于低权限角色，result 包含非 null 的 realname_name（明文法定姓名）、realname_idcard_masked 以及 realname_images.front_image / back_image；而同一会话从 /tenants/detail 收到 realname_evidence=null。正确的实现应对该路由上的非超级管理员角色返回 403。

## 5. 修复建议

在 /tenants/realname-status 处理块（public/api/admin/index.php:1565）顶部添加显式角色检查，仿照同级控制，例如在查询前加入 `if (!PlatformAuth::isSuperAdmin()) { respond(403, '仅超级管理员可查看实名信息'); }`。或者，将敏感字段置于 isSuperAdmin() 门禁之后，仅向非超级管理员角色返回 realname_status（不返回 realname_name / 图片 URL），正如 /tenants/detail 在第 1228 行所做的那样。在必须显示该值的地方，应返回脱敏后的 realname_name_masked 列，而不是遗留明文 realname_name，并且绝不要向非超级管理员角色暴露 realname_front_image / realname_back_image。
