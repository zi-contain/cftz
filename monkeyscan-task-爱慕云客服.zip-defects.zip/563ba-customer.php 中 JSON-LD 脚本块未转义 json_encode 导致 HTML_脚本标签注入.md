## 1. 总结

- **漏洞类型**：XSS (CWE-79)
- **标记位置**：public/customer.php:415
- **漏洞描述**：public/customer.php:415-422 处的 JSON-LD 块将 json_encode() 输出直接回显到内联 <script> 元素中，未按 HTML 上下文进行转义。由于传入了 JSON_UNESCAPED_SLASHES，'</script>' 中的 '/' 会原样输出（json_encode 从不对 '<' 或 '>' 进行转义），因此包含 '</script>' 的值会提前终止脚本数据状态，并向公开访客页面注入任意标记。$shareTitle 和 $shareDescription 来自租户品牌设置，这些设置仅经长度检查（未做净化）后存储，因此商户可以存储该标记；页面 CSP 阻止内联 <script> 执行，但无法阻止基于 HTML/style 的注入。

## 2. 分析逻辑

### 步骤 1：读取 customer.php 中被标记的汇聚点

**证据**：`public/customer.php:415`

```
<script type="application/ld+json"><?= json_encode([ ... 'name' => $shareTitle, 'description' => $shareDescription, ... ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
```

原始 PHP 短回显将 json_encode() 输出到内联 <script> 元素中。没有 htmlspecialchars()/ce() 包装，也没有 JSON_HEX_TAG/JSON_HEX_AMP/JSON_HEX_APOS/JSON_HEX_QUOT 标志。json_encode() 不会转义 '<' 和 '>'；JSON_UNESCAPED_SLASHES 还会使 '/' 保持字面量，因此包含 '</script>' 的存储值会被逐字节写回并闭合 script 元素。

### 步骤 2：确认受污染的操作数，并确认它们未经编码到达汇聚点

**证据**：`public/customer.php:363`

```
$shareTitle = trim((string) ($site['page_title'] ?? '')) ?: trim((string) ($site['customer_service_name'] ?? '在线客服'));
$shareDescription = trim((string) ($site['welcome_message'] ?? '')) ?: '在线客服入口，欢迎咨询';
$shareDescription = mb_substr(preg_replace('/\s+/u', ' ', $shareDescription) ?? $shareDescription, 0, 180);
```

仅对 $shareDescription 应用了 trim()、空白折叠和 mb_substr(...,180)；$shareTitle 仅经过 trim()。二者都不会剥离或 HTML 编码 '<'、'>' 或 '/'。随后这两个值被直接传入第 415 行的 json_encode() 汇聚点。诸如 '</script><meta http-equiv="refresh" content="0;url=https://evil.example">' 这样的载荷完全能够容纳在 180 字符的限制内。

### 步骤 3：将值回溯到其来源（存储的品牌设置）

**证据**：`public/customer.php:76`

```
SELECT s.id, s.tenant_id, s.public_id, ... b.customer_service_name, b.page_title, b.welcome_message, ... FROM cc_sites s INNER JOIN cc_tenants t ... INNER JOIN cc_tenant_brand_settings b ON b.tenant_id = s.tenant_id WHERE s.customer_slug = :slug AND s.customer_link_enabled = 1 ...
```

$site['page_title']、$site['customer_service_name'] 和 $site['welcome_message'] 是从所请求公开 slug 对应的租户品牌设置行中读取的。这些是按租户存储的值，而非服务器常量。

### 步骤 4：确认这些值可由租户写入且未经净化

**证据**：`public/api/merchant/index.php:2372`

```
$pageTitle = trim((string) ($data['page_title'] ?? ''));
$welcome = trim((string) ($data['welcome_message'] ?? ''));
...
if ($pageTitle === '' || mb_strlen($pageTitle) > 120) { respond(-1, '页面标题不能为空且不能超过120个字符'); }
if ($welcome === '' || mb_strlen($welcome) > 500) { respond(-1, '欢迎语不能为空且不能超过500个字符'); }
```

商户 '/brand/save' 处理器在 UPDATE cc_tenant_brand_settings（第 2434-2452 行）之前，仅校验非空和长度（120/120/500 字符）。没有 HTML 净化、编码或字符黑名单，因此商户（拥有 $canManage 的已认证租户用户）可以持久化包含 '</script>' 的字符串，之后该字符串会在公开页面上渲染。

### 步骤 5：检查是否存在任何输出编码 / 自动转义层

**证据**：`public/customer.php:21`

```
function ce($value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
```

该文件定义了 ce()/htmlspecialchars，并将其用于其他分享值（第 398-414 行：<title>、meta og:title/description 等），证明作者知道转义要求，但 415-422 处的 JSON-LD 块未使用它。bootstrap.php（app/Core/bootstrap.php:1-38）未安装输出缓冲/自动转义中间件，因此没有其他机制消除该汇聚点。

### 步骤 6：评估 CSP 作为缓解措施

**证据**：`public/customer.php:16`

```
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'nonce-" . $scriptNonce . "'; form-action 'self'; frame-ancestors *; base-uri 'none'");
```

基于每请求 nonce 的 script-src 阻止注入的内联 <script> 执行，因此通过该路径并非完整的任意 JS XSS。然而 CSP 是运行时限制，不是输出编码：汇聚点处的 script 标签逃逸确实存在，且注入的标记仍会产生 HTML 注入（例如 <meta http-equiv=refresh> 开放重定向/钓鱼、内联 <style> 篡改、注入标记/iframe），因为 style-src 允许 'unsafe-inline'，且没有 CSP 指令管控 meta refresh。nonce 每请求随机且从不暴露给注入者，因此 CSP 只能作为纵深防御依赖，而非唯一控制措施。

### 分析过程

- Q1：用户可控数据是否到达 HTML/JS 输出汇聚点？→ 是。租户存储的 page_title/customer_service_name/welcome_message（public/customer.php:76-95，在 public/api/merchant/index.php:2372-2452 处写入）在 public/customer.php:415 处被原样输出到内联 <script> 中。
- Q2：模板引擎是否自动转义，且未被绕过？→ 无引擎。customer.php 是普通 PHP；汇聚点使用原始 <?= ?> 短回显（public/customer.php:415）。代码库自有的转义助手 ce()（public/customer.php:21）应用于相邻标签，但在此处被有意/意外跳过。
- Q3：数据路径上是否存在显式输出编码/净化（HTML/JS 上下文）？→ 否。public/customer.php:422 处的 json_encode(..., JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) 不会进行 HTML 转义，且 UNESCAPED_SLASHES 标志移除了唯一可能削弱 '</script>' 的附带 '/' 转义。没有 JSON_HEX_TAG/HEX_AMP/HEX_APOS/HEX_QUOT。
- Q4：响应 Content-Type 是否为非 HTML？→ 否。该页面是普通的 text/html 文档（public/customer.php 渲染完整的 <!doctype html> 页面）；资产设置了 nosniff，但这不改变此响应的 HTML 性质。
- Q5：代码是测试/演示/生成的，还是确实不可达？→ 否。public/customer.php 是生产环境的公开访客页面（/s/<slug> 客户入口），且每次成功渲染时都会无条件输出 JSON-LD 块。
- 结论：用户输入到达未转义的 HTML/JS 汇聚点，且没有上下文适配的编码 → 真实漏洞（TP）（HTML/script 标签注入；脚本执行进一步受 nonce CSP 限制）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/customer.php:415-422 将 json_encode() 输出原样发送到 <script type="application/ld+json"> 中，并带有 JSON_UNESCAPED_SLASHES，因此 '</script>' 未被消除。
- public/customer.php:363-365 将来自租户品牌设置的 $shareTitle/$shareDescription 送入该汇聚点，仅经过 trim/空白折叠/长度限制。
- public/api/merchant/index.php:2372-2452 存储 page_title/customer_service_name/welcome_message 时仅校验长度，未做 HTML 净化，使这些值可被攻击者写入。
- public/customer.php:21 显示 ce()/htmlspecialchars 存在并用于其他分享标签（第 398-414 行），但未用于 JSON-LD 块，确认转义正是在该汇聚点被省略。
- public/customer.php:16 的 nonce CSP 阻止注入的内联 <script> 执行，将此问题限制为 HTML 注入/篡改/开放重定向，而非不受限制的 JS——此处将其视为缓解措施，而非修复。

## 4. 验证思路与复现步骤

- **前置条件**：存在拥有品牌管理权限（$canManage）的租户账户；该租户拥有一个已启用、可通过 /s/<slug> 访问的活跃客户链接站点（public/customer.php:87-97）。查看公开页面无需认证。页面必须未使用 JSON_HEX_* 标志加固（根据 public/customer.php:422，它确实未加固）。

**复现步骤：**

1. 以商户/租户身份，向商户 API 路径 /brand/save 发送 POST 请求，其中 page_title 包含 script 标签逃逸，例如 {"customer_service_name":"support","page_title":"x</script><meta http-equiv=\"refresh\" content=\"0;url=https://evil.example/\"><style>body{background:red}</style>","welcome_message":"hi","primary_color":"#00FFB3"}。
2. 确认该值已持久化（处理器返回成功，并在 public/api/merchant/index.php:2434-2452 写入 cc_tenant_brand_settings）。
3. 在浏览器中访问公开客户页面 /s/<slug>。
4. 查看源代码，检查 public/customer.php:415 附近的 <script type="application/ld+json"> 块。

**测试样例：**

```
page_title = x</script><meta http-equiv="refresh" content="0;url=https://evil.example/"><style>body{background:red}</style>  (sent to POST /brand/save, then GET /s/<slug>)
```

- **预期现象**：渲染后的 HTML 中会包含提前出现的 '</script>'，后跟攻击者的 <meta http-equiv=refresh> 和 <style> 标记，位于页面的 head/body 中（查看源代码时，可在 JSON-LD 元素之外看到），而不是该值仅作为惰性 JSON 字符串出现。正确编码的响应应显示尖括号已被转义（例如 \u003C/script\u003E 或 &lt;），从而保持 JSON-LD 元素完整，且不会渲染任何注入的标记。

## 5. 修复建议

在 public/customer.php:415-422 处按 HTML script 上下文编码 JSON-LD 载荷，例如 json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) 并去掉 JSON_UNESCAPED_SLASHES，使 '<'/'&' 无法开始标签。不要依赖 nonce CSP 作为主要控制措施。可选地，还在 public/api/merchant/index.php:2372-2452 写入时对 page_title、customer_service_name 和 welcome_message 进行 HTML 净化/转义（或仅存储纯文本形式），和/或通过 src 引用单独文件来提供 JSON-LD。
