## 1. 总结

- **漏洞类型**: 认证 (CWE-294)
- **标记位置**: public/api/widget/index.php:706
- **漏洞描述**: 访客认证采用自包含的 HMAC-SHA256 Bearer 令牌，其 payload 携带 visitor_id、site_id 以及 exp = time()+31536000（一年）。该令牌由 generateVisitorToken（public/api/widget/index.php:706-714）生成，而 verifyVisitorToken（第 719-736 行）仅验证签名和 exp 时间戳——没有 jti/nonce，没有服务器端记录，也没有撤销机制；同时，签名后的令牌被嵌入 iframe 查询字符串中（public/customer.php:432）。因此，从 URL/访问日志中捕获的令牌可在长达一年的时间内被重放，以该访客身份读取和发送消息；完全如告警所述，该发现为真实漏洞（低危重放弱点）。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的令牌生成器

**证据**: `public/api/widget/index.php:706-714`

```
function generateVisitorToken(int $visitorId, int $siteId): string { $payload = base64_encode(json_encode(['visitor_id'=>$visitorId,'site_id'=>$siteId,'exp'=>time()+31536000])); return $payload . '.' . hash_hmac('sha256', $payload, ChatCollaborationService::visitorTokenSecret()); }
```

该令牌是一种无状态 Bearer 凭证：base64(JSON{visitor_id, site_id, exp})，带有一年有效期（第 711 行）和 HMAC-SHA256 标签。payload 中没有任何内容绑定到请求、nonce 或服务器端状态，这与告警中“一年有效期”的说法相符。

### 步骤 2: 阅读验证路径

**证据**: `public/api/widget/index.php:719-736`

```
$parts=explode('.',$token); ... $expected=hash_hmac('sha256',$payload,ChatCollaborationService::visitorTokenSecret()); $legacyExpected=hash_hmac('sha256',$payload,'widget_secret_v1'); if(!hash_equals($expected,$sig) && !hash_equals($legacyExpected,$sig)){return null;} ... if(!is_array($data) || ($data['exp']??0)<time()){return null;} return $data;
```

验证仅检查签名 + exp，没有 jti/nonce 检查、没有数据库查询、没有令牌版本检查，也没有消费/失效处理，证实了告警中“无 nonce/jti 且无服务器端撤销”的说法。（第 727 行还接受硬编码的回退密钥 'widget_secret_v1'，这进一步削弱了防伪造能力。）

### 步骤 3: 确认重放令牌在 /init 处授予的权限

**证据**: `public/api/widget/index.php:1004-1030 and 1061-1068`

```
if ($visitorToken !== '') { $tokenData = verifyVisitorToken($visitorToken); if ($tokenData !== null && (int)($tokenData['site_id']??0)===(int)$site['id']) { $restoredVisitorId=(int)($tokenData['visitor_id']??0); ... $restoreStmt->execute(['id'=>$restoredVisitorId]); ... } } ... $token=generateVisitorToken((int)$visitor['id'],(int)$site['id']); ... respond(200,'ok',['visitor_token'=>$token,'visitor_id'=>(int)$visitor['id'],'conversation_id'=>(int)$conversation['id'], ...]);
```

将捕获的令牌提交到 /init 后，会恢复受害者的 visitor_id，返回其活跃的 conversation_id，并生成一个新的、有效期为一年的令牌。因此，通过该端点重放，会把访问其他端点所需的标识符交给攻击者。

### 步骤 4: 确认以受害者访客身份读取和发送

**证据**: `public/api/widget/index.php:1105-1138 and 1348-1373`

```
GET /messages: $visitorToken = trim((string)($_SERVER['HTTP_X_VISITOR_TOKEN'] ?? $_GET['visitor_token'] ?? '')); $tokenData = verifyVisitorToken($visitorToken); ... WHERE id = :id AND visitor_id = :visitor_id LIMIT 1 ...
POST /send: $tokenData = verifyVisitorToken($visitorToken); ... $visitorId=(int)($tokenData['visitor_id']??0); checkVisitorBlocked($pdo,$visitorId,$clientIp);
```

/messages 和 /send 都完全基于该令牌进行授权：/messages 返回该访客的消息历史记录，/send 则以此访客身份发布消息。因此，重放令牌同时授予读取和发送权限，与告警中描述的影响相符。

### 步骤 5: 检查是否存在撤销机制

**证据**: `public/api/widget/index.php:402-427 and database/schema.sql:241`

```
function checkVisitorBlocked(PDO $pdo, int $visitorId, string $ip): void { ... WHERE id = :id AND status = 'blocked' ... WHERE ip_address = :ip AND status = 'blocked' ... }
```

checkVisitorBlocked 仅会拒绝状态为 'blocked' 的访客账号（或 IP），不会使单个令牌失效；对于未被阻止的访客，从不同 IP 使用有效令牌也会被接受。在项目范围内搜索 jti/nonce/revoke/token_version，未发现访客令牌撤销机制或令牌版本列（cc_visitors 仅有 status/ip_address）。不存在撤销机制。

### 步骤 6: 检查令牌是否暴露在 URL 中

**证据**: `public/customer.php:432 and public/widget/chat.js:15 and public/api/widget/index.php:1108`

```
<iframe ... src="/widget/visitor.html?site_public_id=...&visitor_token=<?= rawurlencode($widgetVisitorToken) ?>&..."> ; var token = q.get('visitor_token') || localStorage.getItem(visitorTokenKey) || ''; ; $visitorToken = trim((string)($_SERVER['HTTP_X_VISITOR_TOKEN'] ?? $_GET['visitor_token'] ?? ''));
```

签名后的 HMAC 访客令牌被直接放入 iframe src 查询字符串中（customer.php:432，令牌在 customer.php:369-378 构建），客户端从 URL 查询中读取该令牌（chat.js:15），API 甚至也接受其作为 GET 参数（index.php:1108）。因此，签名后的访客令牌确实会在 URL 中传输，并可能落入访问日志/浏览器历史记录，从而证实了该暴露途径。（customer.php:18 确实设置了 Referrer-Policy: strict-origin-when-cross-origin，这可限制跨源 Referer 泄露，但不能限制日志/URL 泄露。）

### 分析过程

- Q1: 代码是否使用具有长期固定有效期的无状态 Bearer 凭证？-> 是，public/api/widget/index.php:711 处 exp = time()+31536000（一年）。
- Q2: 捕获的令牌能否被重放？-> 是。verifyVisitorToken 仅检查签名和 exp（public/api/widget/index.php:719-736）；没有 nonce/jti、没有请求绑定，也没有服务器端消费。
- Q3: 重放令牌会授予哪些权限？-> 完全冒充该访客：/init 恢复 visitor_id 并返回其会话（index.php:1004-1030/1061-1068），/messages 返回其历史记录（index.php:1119-1138），/send 以该访客身份发布消息（index.php:1365-1373）。
- Q4: 是否存在可限制暴露范围的撤销机制？-> 否。checkVisitorBlocked（index.php:402-427）仅阻止访客账号/IP，且不存在令牌版本/jti/黑名单列或存储（database/schema.sql:241）。
- Q5: 令牌是否以第三方可捕获的方式暴露？-> 是。签名令牌被嵌入 iframe src 查询字符串（public/customer.php:432），并由客户端从 URL 查询中读取（public/widget/chat.js:15）；API 也通过 GET 接受它（index.php:1108）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:711 设置了 exp = time() + 31536000，即一年有效期。
- public/api/widget/index.php:719-736 仅验证 HMAC 签名和 exp——没有 jti、没有 nonce、没有服务器端令牌记录，也没有撤销机制。
- public/api/widget/index.php:1352-1373（/send）和 1105-1138（/messages）完全基于令牌授权读取和发送，使重放可完全冒充身份。
- public/api/widget/index.php:1004-1019 允许重放令牌通过 /init 恢复受害者的 visitor_id 和会话。
- public/customer.php:432 将签名后的访客令牌嵌入 iframe src 查询字符串，public/widget/chat.js:15 从 URL 查询中读取该令牌。
- public/api/widget/index.php:402-427（checkVisitorBlocked）和 database/schema.sql:241 表明不存在按令牌撤销或令牌版本机制。

## 4. 验证思路与复现步骤

- **前置条件**: 攻击者已获取有效的 visitor_token（例如来自服务器访问日志或浏览器历史记录中 /widget/visitor.html?...&visitor_token=... 的条目，或来自任何泄露的 URL）。目标的 /api/widget 端点无需认证即可访问，且 IP 速率限制是唯一的节流措施。

**复现步骤：**

1. 获取已捕获的 visitor token，其形式为 base64(payload).hmac。
2. 向 /api/widget/index.php?route=/init 发送 POST 请求，携带 site_public_id（26 字符的站点 ID）和捕获的 visitor_token，以及任意 anonymous_id 值。
3. 观察响应是否返回受害者访客的 visitor_id 和 conversation_id（而非新建访客），证明仅凭该令牌即可通过认证。
4. 发送 GET /api/widget/index.php?route=/messages&conversation_id=<returned id>，并携带请求头 X-Visitor-Token: <captured token>，读取受害者的消息历史记录。
5. 向 /api/widget/index.php?route=/send 发送 POST 请求，携带 conversation_id 和 body，以及相同的请求头，以受害者访客身份发布消息。

**测试样例：**

```
POST /api/widget/index.php?route=/init  body: {"site_public_id":"<26-char site id>","anonymous_id":"attacker-value","visitor_token":"<captured base64payload>.<hmac>"}
```

- **预期现象**: 尽管 anonymous_id 不同，/init 响应仍会回显受害者的 visitor_id 及其现有 conversation_id，后续 /messages 调用也会返回攻击者从未发送过的消息——即同一令牌可从不同客户端认证该会话，从而确认重放。

## 5. 修复建议

应将访客令牌视为短生命周期、由服务器端控制的会话凭证：(1) 将 generateVisitorToken（public/api/widget/index.php:711）中的有效期从一年缩短为较短时间窗口，并定期刷新；(2) 在签名 payload 中加入每个访客的令牌 epoch/版本列（例如在 cc_visitors 上），并拒绝版本不再匹配的令牌，使访客或运营人员操作可撤销未过期令牌；(3) 为高价值操作添加带服务器端撤销/消费存储的 jti；(4) 停止在 URL 中传输令牌——从 public/customer.php:432 的 iframe src 中移除 visitor_token，优先使用 X-Visitor-Token 请求头，而不是 public/api/widget/index.php:1108 接受的 GET 参数；(5) 在可行的情况下将令牌绑定到上下文（生成时已检查 origin/site；可考虑设备绑定）；以及 (6) 移除 public/api/widget/index.php:727 接受的硬编码遗留验证密钥 'widget_secret_v1'，否则该密钥会允许直接伪造此类令牌。
