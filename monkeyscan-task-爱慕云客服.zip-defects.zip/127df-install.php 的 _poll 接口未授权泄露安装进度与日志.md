## 1. 总结

- **漏洞类型**: information_disclosure (CWE-200)
- **标记位置**: public/install.php:28
- **漏洞描述**: install.php 的 `?poll` 分支会在任何身份验证、会话或一次性令牌检查之前被处理，并向任何未认证的网络客户端返回安装器状态，以及服务器端安装日志（storage/install-task.log）的 6 KB 尾部内容。在安装前窗口内，该日志包含内部步骤数据（数据库表名、迁移文件名、计数），并在失败时包含原始异常 / MySQL 错误文本，其中可能包括数据库用户和主机；而 worker 启动失败时，会注入 storage/install-worker.log 的尾部内容，其中可能包含带绝对文件系统路径的 PHP 堆栈跟踪。项目自身的 bootstrap 将这类数据（绝对路径、SQL、堆栈跟踪）归类为敏感信息，且在回显之前未应用任何脱敏处理。该暴露仅存在于安装前窗口，因此该告警被正确评为 LOW。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的 ?poll 分支

**证据**: `public/install.php:28`

```
if (isset($_GET['poll'])) { header('Content-Type: application/json; charset=utf-8'); if ($installer->isInstalled()) { echo json_encode([... 'log' => '', ...]); exit; } $snapshot = $task->snapshot(6000); echo json_encode($snapshot ?? [...], ...); exit; }
```

第 28 行会分发 poll 分支，这完全早于第 52 行的 isInstalled() 403 防护，且不读取任何会话、CSRF 令牌、安装令牌或用户身份。它返回任务快照，其中包含 6000 字节的日志尾部。接下来确认：其上游各道门禁均不进行身份验证。

### 步骤 2: 确认 poll 之前的门禁不执行身份验证

**证据**: `app/Security/LicenseGate.php:411`

```
if (!is_file(dirname(__DIR__, 2) . '/storage/install.lock')) { ... return in_array($scriptPath, [realpath($root . '/public/index.php') ?: '', realpath($root . '/public/install.php') ?: ''], true); }
```

当 storage/install.lock 不存在时，isExemptRequest() 会对 install.php 返回 true，因此 LicenseGate::enforce()（在 install.php:5 和 bootstrap.php:36 调用）会直接返回，不进行拦截。DomainGuard::requirePlatformHost()（DomainGuard.php:12,23）同样会提前返回，因为安装前 APP_URL 为空，而 BackendSecurity::headers()（BackendSecurity.php:8-17）仅设置响应头。没有任何门禁会对调用方进行身份验证。

### 步骤 3: 确认 6 KB 日志尾部确实被放入 HTTP 响应

**证据**: `app/Core/InstallTask.php:143`

```
$state['status'] = $status; $state['log'] = $this->tailLog($logBytes); return $state;
```

snapshot(6000) 会将 state['log'] 设为 tailLog(6000)（InstallTask.php:238-265 打开 storage/install-task.log，定位到最后 6000 字节并返回原始内容）。install.php:44-48 对该数组执行 json_encode 并回显，因此原始日志尾部会原样返回给未认证的调用方。

### 步骤 4: 追踪实际写入安装日志的内容

**证据**: `app/Core/Installer.php:216`

```
$workerLog = $this->tailFile($this->root . '/storage/install-worker.log', 2000); $task->fail("后台安装进程启动失败... " . ($workerLog !== '' ? "进程输出：\n" . $workerLog : '进程产生任何输出。'));
```

日志中会写入：(a) 通过 InstallTask::progress -> appendLog（InstallTask.php:183）写入的进度消息，其中会指明数据库表和迁移文件（Installer.php:298-311、339、346）；(b) 通过 fail()（Installer.php:238、InstallTask.php:218）写入的原始异常消息，其中包含 MySQL 错误码；对于未包装的 PDOException 路径（例如 ensurePlatformUserSchema/createAdministrator），还包含驱动程序文本，如数据库用户和主机；以及 (c) 在 worker 启动失败时，会写入 install-worker.log 的 2000 字节尾部，其内容是 worker 的 stdout，包括“未捕获异常”加上 $exception->getTraceAsString()（bin/install-worker.php:43-44）生成的绝对文件路径。InstallTask.php:42-45 表明密码被有意排除在状态/日志之外，因此凭据不会被泄露，但内部路径、schema 名称和数据库错误详情会泄露。

### 步骤 5: 检查项目自身对该数据的敏感性分类

**证据**: `app/Core/bootstrap.php:4`

```
/* 安全加固：生产环境绝不能让 PHP 错误直接输出到响应体里。 * 报错信息会泄露绝对路径、SQL 语句、堆栈、内部逻辑，全是情报。 */ ini_set('display_errors', '0'); ... ini_set('log_errors', '1'); ini_set('error_log', dirname(__DIR__, 2) . '/storage/php_errors.log');
```

应用程序明确抑制 PHP 错误输出，因为绝对路径、SQL 语句、堆栈跟踪和内部逻辑均被视为情报。然而，`?poll` 端点从日志文件中重新暴露了同一类信息（安装进度、迁移/表名、异常和 worker 堆栈跟踪文本），从而破坏了 bootstrap 特意对响应体应用的脱敏处理。

### 步骤 6: 验证 Web 服务器对 install.php 的可达性

**证据**: `deploy/nginx/aimu-customer-cloud.conf:61`

```
location = /install.php { try_files $uri =404; include fastcgi_params; fastcgi_param SCRIPT_FILENAME $document_root/install.php; ... fastcgi_pass unix:/run/php/php8.2-fpm.sock; }
```

平台主机上的示例生产 server 块将 /install.php 代理到 PHP，且没有 IP 允许列表或身份验证，因此任何人均可从网络访问 poll 端点。另一个加固文件（deploy/nginx-security.conf:52-62）仅建议在生产环境中拒绝 /install.php 和 /build.php，并指出 install.php“有 isInstalled() 防护，但该文件的存在本身已经泄露了产品身份”——这只是指导，并非强制控制，且在端点处于活动状态的安装前窗口内并不适用。

### 分析过程

- Q1: 敏感信息是否暴露给未授权用户/客户端？ -> 是。`?poll` 分支在无认证/会话/令牌的情况下运行（public/install.php:28-49），并返回状态以及 storage/install-task.log 的 6 KB 尾部（InstallTask.php:143,238-265），其中包含应用自身 bootstrap 认定为敏感的内部路径/堆栈跟踪（bootstrap.php:4-7）。
- Q2: 应用程序是否处于生产模式，并具有可消除该问题的适当错误处理？ -> 否。安装器在 .env/APP_DEBUG 存在之前运行，且 poll 路径会原样回显快照数组，没有通用消息错误处理器或过滤（public/install.php:44-48）。
- Q3: 暴露的是否仅为服务器版本/技术信息？ -> 否。日志包含内部 schema 名称、迁移文件名和 MySQL/PDO 错误文本（Installer.php:298-311,339,346,238），并在 worker 启动失败时包含 install-worker.log 的 2000 字节尾部，其中包含带有绝对路径的 PHP 堆栈跟踪（Installer.php:216-222; bin/install-worker.php:43-44）。
- Q4: 代码是否为测试/演示/生成代码，或确实不可达？ -> 否。install.php 是一个实时 HTTP 入口点，示例生产 nginx 块将其公开代理（deploy/nginx/aimu-customer-cloud.conf:61-72）；在安装前窗口内，任何未认证客户端均可访问。凭据按设计被排除（InstallTask.php:42-45），因此其严重性为 LOW 而非 HIGH。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/install.php:28 在 public/install.php:52 的 isInstalled() 403 防护之前分发 `?poll` 分支，并且不读取任何会话/CSRF/安装令牌。
- public/install.php:44 调用 $task->snapshot(6000) 并将其回显，而 InstallTask.php:143 设置 state['log'] = tailLog(6000)，在 HTTP 响应中返回原始 6 KB 安装日志尾部。
- app/Security/LicenseGate.php:411-419 在 storage/install.lock 不存在时将 install.php 豁免于许可证强制执行，因此没有任何门禁会对请求进行身份验证；DomainGuard.php:23 同样在安装前提前返回。
- app/Core/Installer.php:298-311,339,346 将内部表/迁移名称写入日志，并且 app/Core/Installer.php:216-222 注入 worker 日志的 2000 字节尾部，其中未捕获异常的堆栈跟踪（bin/install-worker.php:43-44）包含绝对文件系统路径。
- app/Core/bootstrap.php:4-7 指出绝对路径、SQL 语句和堆栈跟踪属于敏感信息，不应进入响应体，但 `?poll` 端点仍从日志中重新暴露它们。

## 4. 验证思路与复现步骤

- **前置条件**: 目标尚未安装（storage/install.lock 不存在，因此 install.php 会在 403 防护之前被访问，并且 LicenseGate 的安装前豁免适用）；平台主机网络可达。只要安装已启动或此前尝试失败，任务状态/日志就会存在；如果报告者只需观察端点行为，那么“暂无安装任务”的空闲响应仍能证明未认证访问。

**复现步骤：**

1. 确认实例处于安装前状态（没有 storage/install.lock），并且 /install.php 在平台主机上提供服务。
2. 向 /install.php?poll=1 发送未认证的 GET 请求，不带 cookie、令牌或会话头。
3. 读取 JSON 响应，并检查 status/percent/step/message/error 字段以及 'log' 字符串。
4. 与完全不携带凭据的请求进行比较，以表明无论身份如何，返回的服务器端日志内容都相同。

**测试样例：**

```
GET /install.php?poll=1 HTTP/1.1
Host: <platform-host>
(no Cookie, no X-CSRF/Authorization header, no _token parameter)
```

- **预期现象**: HTTP 200，Content-Type 为 application/json，响应体类似于 {"status":"running","percent":...,"message":"...","log":"[HH:MM:SS] [步骤 5] 正在执行数据库迁移（1/N）：<migration>.sql ..."}。在未认证响应中收到内部步骤/迁移数据，或者在任务失败时收到原始异常 / MySQL 或堆栈跟踪消息，即可确认存在信息泄露；正确受保护的端点则应返回 401/403 或经过脱敏的空日志。

## 5. 修复建议

让 `?poll` 分支同样经过安装表单已使用的授权。在回显快照之前，要求提供一次性安装令牌（使用 hash_equals 验证 AIMU_INSTALL_TOKEN cookie/文件值，如同 public/install.php:112-119 对 POST 所做的那样），或者仅向渲染安装器的页面签发短期签名会话，否则返回 403。此外，限制写入 storage/install-task.log 的日志，只记录经过脱敏的步骤消息：将完整异常文本和堆栈跟踪仅路由到服务器端 error_log（正如 bootstrap.php 已对响应体所做的那样），而不是 appendLog()，这样 install-worker.log 的失败尾部就永远不会通过 snapshot() 暴露。最后，在安装期间于 Web 服务器层将 /install.php 限制为运维人员的源 IP（deploy/nginx-security.conf:59-62 中已起草该规则），从而完全关闭网络暴露窗口。
