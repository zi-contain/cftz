## 1. 总结

- **漏洞类型**: authentication_bypass (CWE-290)
- **标记位置**: public/api/widget/index.php:362
- **漏洞描述**: checkWidgetDomain() 是 widget /init 端点上唯一强制执行的来源/域名授权控制，其中有两处提前返回可被攻击者控制，从而完全跳过 WidgetGuard::checkDomain()：（1）对 Referer 的原始子串检测（任何路径中包含 '/s/' 或 '/widget/' 的 Referer URL 都会被信任），以及（2）无条件自我授权，因为 widgetFirstPartyHosts() 会把当前请求的 HTTP_HOST 插入受信集合，因此空的 Origin 总能匹配成功。widget 运行时（visitor-dist/visitor.js）直接调用 /init，不依赖严格的 widget-token.php 检查，因此第三方只要复制了商户的 site_public_id，就能从未经授权的站点驱动该商户的聊天。告警中的代码级断言均已在对应行确认。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的函数及其调用方

**证据**: `public/api/widget/index.php:342-378`

```
function checkWidgetDomain(PDO $pdo, string $sitePublicId): void {
    $origin = strtolower(WidgetGuard::detectOrigin());
    if ($origin !== '' && widgetIsFirstPartyOrigin($origin)) { return; }
    if ($origin === '') { $self = ... $_SERVER['HTTP_HOST'] ...; if ($self !== '' && widgetIsFirstPartyOrigin($self)) { return; } }
    $referer = strtolower((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    if ($referer !== '' && (strpos($referer, '/s/') !== false || strpos($referer, '/widget/') !== false)) { return; }
    $check = WidgetGuard::checkDomain($pdo, $sitePublicId, $origin);
    if (!$check['allowed']) { ... respond(-1, '当前来源未获授权', null, 403); }
}
```

在调用第 365 行的 WidgetGuard::checkDomain() 之前，存在三处提前返回：第 346-348 行信任任何第一方 Origin；第 353-358 行在 Origin 为空时信任请求自身的 Host；第 361-364 行信任任何包含 '/s/' 或 '/widget/' 的 Referer。只有经过这三处之后，才会查询真正的允许列表（primary_domain）。

### 步骤 2: 确认调用链以及执行该检查的端点

**证据**: `public/api/widget/index.php:444-453, 988-1000`

```
function resolveSite(...) { checkAntiScrape(); checkWidgetDomain($pdo, $sitePublicId); ... }
// /init handler:
if ($path === '/init' && $method === 'POST') { ... $site = resolveSite($pdo, $sitePublicId); ...
```

checkWidgetDomain() 只能经由 resolveSite() 到达，而 resolveSite() 仅由 /init 路由调用（第 1000 行）。在整个仓库中 grep checkWidgetDomain/resolveSite，未发现其他调用点。/init 接收 site_public_id 和 anonymous_id，并返回 visitor_token/conversation_id；它不需要任何 render token。

### 步骤 3: 检查更严格的加载器侧门禁是否真正保护了 /init

**证据**: `public/widget/widget-token.php:60-64 and public/widget/visitor-dist/visitor.js:80`

```
widget-token.php: $domainCheck = WidgetGuard::checkDomain($pdo, $sitePublicId, $origin); if (!$domainCheck['allowed']) { 403 }
visitor.js: d0="/api/widget/index.php?route="; ... const Oe=await te("/init","POST",{site_public_id:n,anonymous_id:C.value,visitor_token:b.value,...})
```

widget-token.php 确实调用了严格的 checkDomain，但 widget 运行时打包产物从未引用 widget-token.php（出现 0 次），而是仅携带 site_public_id 直接调用 /init。API base 是同源的相对路径。因此，严格门禁可被轻易绕过，checkWidgetDomain() 才是访客会话的有效控制。

### 步骤 4: 验证 Referer 子串提前返回可被攻击者控制

**证据**: `public/api/widget/index.php:361-364`

```
$referer = strtolower((string) ($_SERVER['HTTP_REFERER'] ?? ''));
if ($referer !== '' && (strpos($referer, '/s/') !== false || strpos($referer, '/widget/') !== false)) { return; }
```

原始 Referer 只做子串检测，从未被解析。攻击者可同时控制自己页面的路径（例如 https://evil.example/s/x）以及发出该请求的策略（fetch(url,{referrerPolicy:'unsafe-url'}) 或 <meta name="referrer" content="unsafe-url">）。detectOrigin() 优先使用 HTTP_ORIGIN（WidgetGuard.php:105-123），因此 Origin 仍会解析为 evil.example，但该代码块会在第 365 行 checkDomain 执行之前返回——第 367-377 行的拒绝逻辑永远不会被触达。

### 步骤 5: 验证 HTTP_HOST 自我授权路径

**证据**: `public/api/widget/index.php:309-324 and 331-339`

```
$self = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? ''))); ... if ($self !== '') { $hosts[$self] = true; } return array_keys($hosts);
// widgetIsFirstPartyOrigin:
foreach (widgetFirstPartyHosts() as $host) { if ($origin === $host) return true; if (str_ends_with($origin, '.' . $host)) return true; }
```

当前请求的 HTTP_HOST 被无条件加入受信集合，而 widgetIsFirstPartyOrigin() 执行的是精确相等比较。因此，只要 HTTP_HOST 非空，第 356 行的 widgetIsFirstPartyOrigin($self) 就始终为真，任何没有 Origin/Referer 的请求都会被自动授权。这使得 WidgetGuard::checkDomain() 中的 'origin_missing' 拒绝逻辑（WidgetGuard.php:160-163）在该路径上成为死代码。

### 步骤 6: 检查作为补偿的反爬控制

**证据**: `public/api/widget/index.php:383-397`

```
function checkAntiScrape(): void {
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (preg_match('/curl|requests|scrapy|wget|httpclient|okhttp|python|java|go-http-client/i', $ua)) { ... respond(-1, '请求被拒绝', null, 403); }
}
```

checkAntiScrape() 在 checkWidgetDomain() 之前运行（第 452 行），但它只是一个针对已知工具 UA 子串的拒绝列表。任何非浏览器客户端都能发送正常的浏览器 User-Agent 并通过，因此无法补偿被破坏的来源检查。

### 步骤 7: 检查框架/部署层面的缓解措施以及跨源可读性

**证据**: `public/api/widget/index.php:35, deploy/nginx/aimu-customer-cloud.conf:181, 26`

```
header('Access-Control-Allow-Origin: *');
// nginx: location /api/ { return 404; }  (customer-service domain)
// nginx: add_header Referrer-Policy "strict-origin-when-cross-origin" always;  (platform domain response)
```

widget API 以 ACAO:* 响应（第 35 行），因此跨源 fetch 可以读取 visitor_token 和会话数据。nginx 的 /api/ 404 仅存在于客户服务主机上，而 API 在平台主机上提供；响应级别的 Referrer-Policy 无法管控攻击者自己页面的 referrer 策略。没有任何服务器层强制执行 primary_domain 允许列表，且该代码是 public/api 下的生产代码，而非测试固件。

### 分析过程

- Q1：不受信任的来源能否触达受保护资源？-> 能。/init 是一个可跨源触达的 POST 路由，并以 Access-Control-Allow-Origin: * 响应（public/api/widget/index.php:35, 988）。
- Q2：被标记的提前返回是否位于实际授权路径上？-> 是。它在 index.php:361-364 执行，位于 index.php:365 处唯一的允许列表调用之前。
- Q3：Referer/Origin 是否可被攻击者控制？-> 是。攻击者托管该页面，并设置其路径与 referrer 策略（fetch referrerPolicy:'unsafe-url'）；根据 WidgetGuard.php:105-123，Origin 由 HTTP_ORIGIN 推导而来。非浏览器客户端还可以完全省略 Origin。
- Q4：是否存在第二道可补偿的控制？-> 否。widget-token.php 的严格 checkDomain 被跳过，因为运行时（visitor-dist/visitor.js）直接调用 /init，且从不使用 widget-token.php；checkAntiScrape（index.php:386）是可绕过的 UA 拒绝列表；checkDomain 自身对空 origin 的拒绝由于 HTTP_HOST 自匹配（index.php:318-322, 353-358）而成为死代码。
- Q5：该代码是否为生产代码且可触达？-> 是。它是 public/api/widget/index.php 下的生产 widget API，且是 /init 的处理器；不是测试/演示/生成代码。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:361-364 只要攻击者提供的 Referer 包含 '/s/' 或 '/widget/' 就会提前返回（受信任），从而跳过 WidgetGuard::checkDomain()。
- public/api/widget/index.php:318-322 无条件把 $_SERVER['HTTP_HOST'] 插入 widgetFirstPartyHosts()，而 index.php:353-358 只要 Origin 为空就提前返回，使允许列表对任何无 Origin 请求失效。
- public/api/widget/index.php:452-453 中 resolveSite() 先调用 checkAntiScrape()（可绕过的 UA 拒绝列表，index.php:386），再调用 checkWidgetDomain()，而后者是 /init 上唯一强制执行的来源控制。
- public/widget/visitor-dist/visitor.js 引用 "/api/widget/index.php?route=" 并直接调用 "/init"，对 widget-token.php 的引用为零，因此加载器侧的严格检查不在该路径上。
- public/api/widget/index.php:35 设置 Access-Control-Allow-Origin: *，使未经授权的跨源页面能够读取 /init 返回的 visitor token 与会话内容。

## 4. 验证思路与复现步骤

- **前置条件**: 攻击者知道某个活跃站点的有效 26 字符 site_public_id，且该站点的 primary_domain 配置为攻击者域名之外的其他域名（这是白名单所要保护的常规情形）。攻击者在自己的域名上控制一个页面，因此可控制其路径，并可通过 fetch(url, {referrerPolicy:'unsafe-url'}) 或 <meta name="referrer" content="unsafe-url"> 强制发送完整 URL 的 Referer。widget API 可在 /api/widget/index.php 触达，并以 Access-Control-Allow-Origin: * 响应。除公开的站点 id 外无需任何认证。

**复现步骤：**

1. 在攻击者自己的来源上托管一个路径包含 '/s/' 的页面（例如 https://evil.example/s/promo）。
2. 从该页面向平台 widget API /api/widget/index.php?route=/init 发送 POST 请求，携带窃取的 site_public_id，并发送 Origin: https://evil.example 以及完整 URL 的 Referer（通过 referrerPolicy:'unsafe-url' 强制）。
3. 可观察到 checkWidgetDomain() 从 Referer 子串分支返回（index.php:361-364），而不是调用 WidgetGuard::checkDomain()，因此 /init 返回 HTTP 200 及 visitor_token 和 conversation_id，而非 403 '当前来源未获授权'。
4. 将返回的 visitor_token 复用于 /send 和 /messages（index.php:1105, 1348），以确认攻击者的站点可以在该商户的会话中读取和发送消息。
5. 对照测试：使用默认 referrer 策略，从不包含 '/s/' 或 '/widget/' 的路径重复同一请求；此时 origin 分支会到达 checkDomain() 并返回 403，证明差异正是子串/自我授权的提前返回。

**测试样例：**

```
POST /api/widget/index.php?route=/init HTTP/1.1
Host: <platform-host>
Origin: https://evil.example
Referer: https://evil.example/s/promo
Content-Type: application/json

{"site_public_id":"<26-char active site id>","anonymous_id":"a_0123456789"}
```

- **预期现象**: 存在漏洞时：即使 evil.example 并非商户配置的 primary_domain，也返回 HTTP 200 且 JSON code 为 200，其中包含 visitor_token 和 conversation_id。安全时：返回 HTTP 403 且 code 为 -1，消息为 '当前来源未获授权'。

## 5. 修复建议

不要把 Referer/Origin 的子串或请求自身的 Host 作为授权依据。在 checkWidgetDomain()（public/api/widget/index.php:342-378）中：（1）删除第 361-364 行的 Referer 子串提前返回，仅将解析并规范化后的来源主机与存储的 cc_sites.primary_domain 允许列表进行精确相等比较（或显式通配模式）来判定；（2）移除 widgetFirstPartyHosts() 中无条件插入 HTTP_HOST 的逻辑（第 318-322 行），第一方主机应仅从受信配置（APP_URL / CUSTOMER_SERVICE_URL）派生；（3）将缺失或空的 Origin 视为不受信任，而不是回退到请求 Host。此外，在 /init 上要求有效的 widget-token render token（WidgetGuard::verifyRenderToken，其已绑定 site_public_id + origin），使该 API 无法在未通过加载器侧严格检查的情况下被驱动，并将 checkAntiScrape() 中的 UA 拒绝列表替换为不依赖客户端提供头部的控制措施。
