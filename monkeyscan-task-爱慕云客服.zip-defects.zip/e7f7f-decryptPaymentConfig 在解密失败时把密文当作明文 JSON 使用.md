## 1. 总结

- **漏洞类型**: insufficiently_protected_credentials (CWE-311)
- **标记位置**: public/api/merchant/index.php:811
- **漏洞描述**: decryptPaymentConfig() 是一个凭据加载函数，其契约是只返回经过认证、经 AEAD 解密的配置，但它的最后几行却无条件地对原始存储值执行 json_decode()，并返回其产生的任意数组。这绕过了 AES-256-GCM 的真实性/机密性控制，与该函数自身文档化的契约以及 SecuritySettings::credentials() 中同类的失败即关闭（fail-closed）读取器相矛盾。所得的配置提供了用于签名出站支付请求的 merchant_id/merchant_key/api_url，因此拥有 cc_provider_configs 写权限（但不持有 APP_KEY）的一方可以明文注入受信任的支付参数。

## 2. 分析逻辑

### 步骤 1: 阅读 decryptPaymentConfig 中被标记的兜底逻辑

**证据**: `public/api/merchant/index.php:783-813`

```
foreach ([['App\\Security\\Crypto','decrypt'],['App\\Core\\Crypto','decrypt'],['App\\Security\\SecretBox','decrypt']] as $callable) { if (is_callable($callable)) { try { $plain = $callable($ciphertext); ... } catch (Throwable $e) { } } }

$decoded = json_decode($ciphertext, true);
return is_array($decoded) ? $decoded : [];
```

在所有真正的解密器都抛出异常或返回非 JSON 之后，第 810-812 行会对*原始密文*执行与 base64 无关的 json_decode()，并将其作为有效配置返回。这里没有完整性校验，没有日志记录，也没有拒绝明文。唯一实际存在的解密器是 App\Security\Crypto（下文已验证）；App\Core\Crypto 与 App\Security\SecretBox 并不存在，因此在常见失败情形下（APP_KEY 错误/轮换，或存在明文行），控制流会直接落入明文路径。

### 步骤 2: 确认实际生效的解密器

**证据**: `app/Security/Crypto.php:25-42`

```
public static function decrypt(string $payload): string { $binary = base64_decode($payload, true); if ($binary === false || strlen($binary) < 29) { throw new RuntimeException('密文格式无效'); } ... if ($plaintext === false) { throw new RuntimeException('敏感数据解密失败'); } return $plaintext; }
```

App\Security\Crypto::decrypt() 是失败即关闭的：任何格式/认证失败都会抛出异常。Glob 显示 app/Core/Crypto.php 与 app/Security/SecretBox.php 不存在，因此这两个 is_callable() 条目始终为 false。因此，正是 Crypto::decrypt() 抛出的异常使执行落入第 810-812 行的明文兜底逻辑。

### 步骤 3: 将加密材料追溯至存储及其写入方

**证据**: `app/Domain/Security/SecuritySettings.php:230-232`

```
$ciphertext = Crypto::encrypt(
    json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)
);
```

唯一写入 cc_provider_configs.config_ciphertext 的代码是 SecuritySettings::saveCredentials()，它始终使用 AES-256-GCM 封装负载（Crypto::encrypt）。因此，正确写入的行是密文，而明文兜底仅仅是一种替代性的、未经认证的表示形式，函数却仍然信任它。设计意图在 SecuritySettings.php:16（'敏感凭据存 ... config_ciphertext（AES-256-GCM 密文）'）与 database/007_security_verification.sql:5 中有明确表述。

### 步骤 4: 与同类的失败即关闭凭据读取器对比

**证据**: `app/Domain/Security/SecuritySettings.php:199-205`

```
if (is_string($ciphertext) && $ciphertext !== '') {
    $decoded = json_decode(Crypto::decrypt($ciphertext), true);
    if (is_array($decoded)) { $result = $decoded; }
}
```

代码库中最接近的等价读取器从不回退到明文：如果 Crypto::decrypt() 抛出异常，它会被捕获，结果保持为 []（返回“未配置”）。被标记的函数是唯一的例外，其自身的文档块在 merchant/index.php:708 中声明预期契约为“失败时返回空数组”。代码与两者都相矛盾。

### 步骤 5: 追踪返回的配置在何处被消费

**证据**: `public/api/merchant/index.php:723-726`

```
$config = decryptPaymentConfig((string) ($stmt->fetchColumn() ?: ''));
$apiUrl = trim((string) ($config['api_url'] ?? ''));
$merchantId = trim((string) ($config['merchant_id'] ?? $config['pid'] ?? ''));
$merchantKey = trim((string) ($config['merchant_key'] ?? $config['key'] ?? ''));
```

buildRechargePaymentUrl() 从该函数加载支付凭据，并立即使用 $apiUrl/$merchantId/$merchantKey 构建并签名出站支付请求（第 761 行的 epay 签名 md5(implode(...) . $merchantKey)；第 776 行的 codepay token）。因此，明文提供的配置被当作合法的网关凭据加以信任。

### 步骤 6: 检查可达性与写入侧门禁

**证据**: `public/api/admin/index.php:3253-3312`

```
if ($path === '/payment/config' && $method === 'POST') {
    if (!PlatformAuth::isSuperAdmin()) { respond(-1, '仅超级管理员可修改支付配置', null, 403); }
    ...
    SecuritySettings::saveCredentials('payment', $config, (int) ($user['id'] ?? 0), $provider);
```

合法的写入路径受超级管理员门禁限制，并且始终加密，因此管理员无法通过 API 注入明文。该兜底逻辑的增量风险，只有在拥有对 cc_provider_configs 的直接写权限（泄露的数据库凭据、表级 SQL 写入原语、被恢复/编辑的数据库）但不持有 APP_KEY 的一方手中才会实现：没有该兜底逻辑，他们无法伪造经 GCM 认证的配置；有了它，他们就可以。读取侧消费方（resolvePaymentMethods 第 672 行、buildRechargePaymentUrl 第 723 行）可从商户钱包/充值端点到达（调用方位于第 6794 与 6821 行）。

### 分析过程

- Q1: 攻击者可影响的某个值是否会到达汇聚点（index.php:811 处的 json_decode 兜底）？ -> 部分成立：被读取的值是 cc_provider_configs.config_ciphertext，仅由 SecuritySettings::saveCredentials 写入（加密、受超级管理员门禁限制）。需要直接写数据库才能植入明文 -> 在数据库失陷威胁模型下成立（步骤 7）。
- Q2: 写入路径上的静态加密控制是否被正确应用？ -> 是（SecuritySettings.php:230-232 始终使用 AES-256-GCM 加密），因此损失发生在读取/信任路径，而非写入路径（步骤 3-4）。
- Q3: 是否有足够的防护来阻止汇聚点失败开放（fail open）？ -> 否。唯一实际存在的解密器（Crypto::decrypt，Crypto.php:25-42）以失败即关闭的方式抛出异常，但 index.php:804-806 的 catch 将其吞掉，第 810-812 行接受原始明文，且没有 tag/完整性校验，也没有日志记录（步骤 1）。
- Q4: 被标记的代码是否与项目声明及同类行为一致？ -> 否。文档块（index.php:708）承诺失败时返回 []，且 SecuritySettings::credentials（SecuritySettings.php:199-205）是失败即关闭的；decryptPaymentConfig 是唯一的偏离（步骤 4）。
- Q5: 返回的值一旦被信任是否具有安全相关性？ -> 是。它提供用于签名支付请求的 merchant_key/api_url（index.php:724-726,761,776），因此明文注入 = 支付参数注入（步骤 5）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/merchant/index.php:810-812 在解密失败时无条件地对原始存储值执行 json_decode() 并将其作为配置返回——没有真实性校验，也没有拒绝明文。
- app/Security/Crypto.php:25-42 是唯一存在且失败即关闭（抛出异常）的解密器，因此正是 Crypto::decrypt() 的失败导致执行被路由至明文兜底逻辑。
- app/Domain/Security/SecuritySettings.php:230-232 证明对 config_ciphertext 的每一次合法写入都是 AES-256-GCM 加密的，因此接受明文破坏了该控制措施的完整性保证。
- app/Domain/Security/SecuritySettings.php:199-205 表明同类的凭据读取器是失败即关闭的（解密失败时返回 []），且 public/api/merchant/index.php:708 记载了相同的预期契约——被标记的函数偏离了两者。
- public/api/merchant/index.php:723-726 将返回的配置用作 merchant_id/merchant_key/api_url，且第 761/776 行用它签名出站请求，使得被注入的明文配置具有安全关键性。

## 4. 验证思路与复现步骤

- **前置条件**: cc_provider_configs 中存在一行支付提供方记录（provider_type='payment'，provider_name 属于 {epay, codepay}，tenant_id IS NULL，status='active'）。测试人员具备直接写入该行的能力（例如泄露的/受作用域限制的数据库凭据，或某个 INSERT/UPDATE 原语），但不持有应用的 APP_KEY，因此无法伪造有效的 AES-256-GCM 数据块。调用 buildRechargePaymentUrl() 的商户钱包充值端点可达（index.php:6821）。

**复现步骤：**

1. 读取活跃的 epay/codepay 行：SELECT id, config_ciphertext FROM cc_provider_configs WHERE tenant_id IS NULL AND provider_type='payment' AND provider_name='epay' AND status='active'。
2. 用一个明文的 JSON 数据块（而非密文）覆盖 config_ciphertext，例如 {"api_url":"https://attacker.example/pay","merchant_id":"attacker","merchant_key":"attackerkey"}，保留 status='active'。
3. 触发一次选择 epay 驱动的商户余额充值（即到达 index.php:6794/6821 处 resolvePaymentMethods()/buildRechargePaymentUrl() 的路径）。
4. 检查返回的 payment_url（index.php:6823-6828）。

**测试样例：**

```
UPDATE cc_provider_configs SET config_ciphertext='{"api_url":"https://attacker.example/pay","merchant_id":"attacker","merchant_key":"attackerkey"}' WHERE tenant_id IS NULL AND provider_type='payment' AND provider_name='epay' AND status='active';  then POST the merchant wallet-recharge create request selecting payment_method=alipay (driver=epay).
```

- **预期现象**: 应用会返回一个 payment_url，其 host/pid/sign 由被注入的明文值构建（网关主机 = attacker.example，签名使用 merchant_key 'attackerkey' 计算），而不是拒绝该行。在失败即关闭的实现中，同样的明文行会导致 Crypto::decrypt() 抛出异常，config 保持为 []，且 buildRechargePaymentUrl() 抛出 RuntimeException('后台支付通道配置不完整')（index.php:727-728）——也就是说，永远不会产生受攻击者控制的 URL。

## 5. 修复建议

删除 public/api/merchant/index.php:810-812 处的明文兜底逻辑：如果所有解密器都失败，则记录该失败并返回 []，让调用方将该通道视为未配置（与 SecuritySettings.php:199-205 处的 SecuritySettings::credentials() 保持一致）。不要静默接受 json_decode($ciphertext)。可选择记录 key_version 并要求其与当前 APP_KEY 匹配，使轮换密钥的行失败即关闭，而不是降级处理。任何导入提供方配置的运维工具都必须经由 Crypto::encrypt()/saveCredentials()；绝不要将明文 JSON 写入 config_ciphertext。
