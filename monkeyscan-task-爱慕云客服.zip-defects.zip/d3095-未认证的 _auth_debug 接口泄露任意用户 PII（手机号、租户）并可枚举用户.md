## 1. 总结

- **漏洞类型**: information_disclosure (CWE-200)
- **标记位置**: public/api/merchant/index.php:975
- **漏洞描述**: POST /auth/debug 在 public/api/merchant/index.php 的 L975 处被分发，该位置早于 L1887 处由 requireMerchant() 保护的已认证代码段，因此无需任何凭据即可访问。它会把攻击者提供的 'token' 转发给 TenantAuth::debugToken()；后者在 L489 计算 signature_valid，但在对 payload 进行 base64 解码并执行以攻击者选择的 uid 为键的数据库查询（L509-518）之前，从不检查该值，并返回 user_phone、tenant_id、tenant_name、tenant_status、tenant_deleted 和 auth_would_pass。这使未认证攻击者能够伪造 {"uid":N} payload，读取任意商户的电话/租户 PII，并枚举账户。

## 2. 分析逻辑

### 步骤 1：确认 /auth/debug 的分发未经认证

**证据**：`public/api/merchant/index.php:975`

```
if ($path === '/auth/debug' && $method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $token = (string) ($input['token'] ?? '');
    ...
    $debug = \App\Security\TenantAuth::debugToken($token);
    ...
    respond(200, 'ok', $debug);
}
```

该路由从 JSON body 中读取攻击者可控的 'token'，并返回 debugToken() 的结果。它位于 L975，且在 try 块之外、之前，而认证调用 `$user = requireMerchant();` 要到后面的 L1887 才发生。下一步：验证 L1 到 L975 之间是否存在任何内容会对调用者进行认证。

### 步骤 2：检查 L975 之前是否存在任何全局认证门禁

**证据**：`public/api/merchant/index.php:1-97`

```
require dirname(__DIR__, 3) . '/app/Core/bootstrap.php';
\App\Security\LicenseGate::enforce();
...
\App\Security\DomainGuard::requirePlatformHost();
...
Session::start();
```

唯一的预分发守卫是 LicenseGate::enforce()（软件许可，app/Security/LicenseGate.php:75-81）、DomainGuard::requirePlatformHost()（仅主机/域名检查，app/Security/DomainGuard.php:10-37）和 Session::start()。它们都不认证用户。已确认不存在覆盖 L975 的认证中间件。

### 步骤 3：确认已认证代码块从 debug 路由之后开始

**证据**：`public/api/merchant/index.php:1887`

```
$user = requireMerchant();
$pdo = Database::connection();
$tenantId = (int) $user['tenant_id'];
```

requireMerchant()（定义于 public/api/merchant/index.php:173-233）是认证门禁，它在 L1887 运行——远在 L975 处的 /auth/debug 处理器之后。对 /auth/debug 的请求永远不会到达它。

### 步骤 4：追踪 debugToken：签名已计算但从未强制执行

**证据**：`app/Security/TenantAuth.php:488-518`

```
$expectedSig = hash_hmac('sha256', $payloadB64, self::tokenSecret());
$result['signature_valid'] = hash_equals($expectedSig, $signature);

$payloadJson = base64_decode(strtr($payloadB64, '-_', '+/'));
...
$payload = json_decode($payloadJson, true);
...
$result['user_id'] = (int) ($payload['uid'] ?? 0);
...
if (!empty($payload['uid'])) {
    $stmt = Database::connection()->prepare(
        'SELECT u.id, u.tenant_id, u.status, u.phone, u.display_name, ... WHERE u.id = :id LIMIT 1');
    $stmt->execute(['id' => (int) $payload['uid']]);
```

signature_valid（L489）被计算出来，但从未用作守卫。payload 解码（L492-499）以及仅由 `!empty($payload['uid'])`（L509）作为门禁的数据库查询，无论签名是否有效都会执行。uid 完全由攻击者控制，并且 base64_decode(strtr(...'-_','+/')) 接受 URL 安全的 base64。

### 步骤 5：识别响应中返回的 PII

**证据**：`app/Security/TenantAuth.php:520-531`

```
$result['user_phone'] = $user['phone'] ?? '';
$result['tenant_id'] = $user['tenant_id'] ?? null;
$result['tenant_status'] = $user['tenant_status'] ?? 'null(无租户)';
$result['tenant_name'] = $user['tenant_name'] ?? '';
$result['tenant_deleted'] = $user['tenant_deleted'] !== null;
...
$result['auth_would_pass'] = $wouldPass;
```

响应包含账户的电话号码、租户 id、租户名称、租户状态以及认证通过/失败状态——仅通过伪造 uid 即可获取的任意商户 PII。随后这些字段通过 public/api/merchant/index.php:982 处的 respond(200, 'ok', $debug) 返回给未认证调用者。

### 步骤 6：确认该路由的网络可达性

**证据**：`deploy/nginx/aimu-customer-cloud.conf:49-52`

```
location /api/merchant/ {
    rewrite ^/api/merchant/(.*)$ /api/merchant/index.php?route=$1&$args last;
    add_header Cache-Control "no-store, private" always;
}
```

生产 Nginx 配置将 /api/merchant/<x> 重写为 ?route=<x>，而 routePath()（public/api/merchant/index.php:147-171）读取 $_GET['route']。因此，对 /api/merchant/auth/debug 的公开请求会解析为 `$path === '/auth/debug'`。此 location 未应用任何认证或速率限制。

### 分析过程

- Q1：敏感信息是否暴露给未授权用户？ -> 是。该端点向未认证调用者（public/api/merchant/index.php:975，L975 之前没有认证）返回 user_phone/tenant_name/tenant_status/tenant_id（app/Security/TenantAuth.php:522-525）。
- Q2：应用程序是否处于生产模式并具有适当的错误处理？ -> 与此暴露无关：该泄露属于正常的成功数据流，而非错误/堆栈跟踪。响应是故意返回的带 PII 的 200（public/api/merchant/index.php:982）。
- Q3：是否仅暴露服务器版本/技术信息？ -> 否。实际 PII（商户电话号码、租户名称）被暴露，此外还暴露了签名有效性 oracle（app/Security/TenantAuth.php:489）。
- Q4：代码是测试/演示/生成的，或不可达吗？ -> 否。public/api/merchant/index.php 是正在使用的商户 REST 路由器，可通过 deploy/nginx/aimu-customer-cloud.conf:49-52 处的 Nginx 重写访问。它是框架入口点，而非死代码。
- Q5：签名检查是否使 payload 失效？ -> 否。在 L509-518 的数据库查询之前，从未检查 signature_valid（app/Security/TenantAuth.php:489）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/merchant/index.php:975 在认证之前分发 '/auth/debug'；requireMerchant() 仅在 L1887 被调用。
- app/Security/TenantAuth.php:489 计算 signature_valid，但 L492-518 解码 payload 并查询数据库，却从未检查它。
- app/Security/TenantAuth.php:509-518 执行以攻击者控制的 uid 为键的数据库查询，且没有签名强制执行。
- app/Security/TenantAuth.php:522-525 返回 user_phone、tenant_id、tenant_status 和 tenant_name——任意用户的 PII。
- deploy/nginx/aimu-customer-cloud.conf:49-52 表明 /api/merchant/auth/debug 可通过该重写公开访问，且没有认证门禁。

## 4. 验证思路与复现步骤

- **前置条件**：该安装已完成（storage/install.lock 存在，在 public/api/merchant/index.php:957 处强制执行）。目标主机与配置的平台域名匹配。由于该端点在 requireMerchant() 之前被处理，因此不需要认证 token 或 session。

**复现步骤：**

1. 为目标 uid N 构造 payload，例如 {"uid":N,"client":"app"} 的 base64url。
2. 在点号后附加任意（无效）签名：'<payloadB64>.AAAA'。
3. 发送 POST /api/merchant/auth/debug，携带 X-Client-Type: app 和 JSON body {"token":"<payloadB64>.AAAA"}。
4. 观察该 uid 的 JSON 结果。
5. 使用连续的整数 uid 重复上述步骤，以枚举账户。

**测试样例：**

```
POST /api/merchant/auth/debug HTTP/1.1
Host: <platform-domain>
Content-Type: application/json

{"token":"eyJ1aWQiOjEsImNsaWVudCI6ImFwcCJ9.AAAA"}
```

- **预期现象**：一个 200 响应，其 result 包含 user_found=true 以及 uid 1 的 user_phone、tenant_name、tenant_status 和 auth_would_pass——即使 'AAAA' 不是有效的 HMAC——证明签名未强制执行，且 PII 被泄露给未认证调用者。

## 5. 修复建议

在生产环境中，从 public/api/merchant/index.php 移除 /auth/debug 路由，或者将该处理器移到 L1887 处的 requireMerchant() 门禁之后，并将其限制为平台超级管理员。另外，在 app/Security/TenantAuth.php:debugToken() 中，当 hash_equals($expectedSig, $signature) 为 false 时提前返回（即基于 signature_valid 对解码和数据库查询进行门禁），并停止从诊断方法返回原始 PII（user_phone、tenant_name、tenant_status）。L488-489 处的 HMAC 验证形式正确，但必须在任何 payload 处理之前真正强制执行。
