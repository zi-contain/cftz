## 1. 总结

- **漏洞类型**：missing_authentication (CWE-306)
- **标记位置**：public/widget/widget-position.php:126
- **漏洞描述**：widget-position.php 是一个 POST 端点，会以 (site_id, visitor_token) 为键向 cc_widget_positions 写入数据，既不进行身份验证，也不验证 visitor token。应用的其他位置将 visitor_token 视为经 HMAC-SHA256 签名的 bearer 凭证，并对无效令牌返回 401（public/api/widget/index.php:719-736, 1115-1122），而该端点却直接将客户端提供的原始字符串用作 upsert 键。由此导致：(a) 可篡改任何已知令牌所存储的位置；(b) 由于 UNIQUE 键为 (site_id, visitor_token) 且未应用速率限制，可通过任意唯一令牌无限创建行。

## 2. 分析逻辑

### 步骤 1：读取被标记的端点及其危险操作点

**证据**：`public/widget/widget-position.php:118-132`

```
$pdo->prepare('INSERT INTO cc_widget_positions (site_id, visitor_token, position_x, position_y, viewport_hint) VALUES (:sid, :vt, :px, :py, :hint) ON DUPLICATE KEY UPDATE position_x = VALUES(position_x), position_y = VALUES(position_y), viewport_hint = VALUES(viewport_hint)')->execute(['sid'=>$siteId,'vt'=>$visitorToken,'px'=>$posX,'py'=>$posY,'hint'=>$hint]);
```

该写入将 $visitorToken 原样绑定为行键。唯一前提是 site_public_id 能解析到活跃站点（第 106-115 行）。此处既未进行身份验证，也未验证令牌。下一步：确认 visitor_token 在其他位置是否属于可验证的凭证。

### 步骤 2：确认 visitor_token 是经过签名、可验证的凭证

**证据**：`public/api/widget/index.php:706-736`

```
function generateVisitorToken(...) { $payload = base64_encode(json_encode(['visitor_id'=>..., 'site_id'=>..., 'exp'=>...])); return $payload . '.' . hash_hmac('sha256', $payload, ChatCollaborationService::visitorTokenSecret()); } function verifyVisitorToken(string $token): ?array { ... if (!hash_equals($expected, $sig) && !hash_equals($legacyExpected, $sig)) return null; ... }
```

visitor_token 是一种 payload.HMAC-SHA256 bearer 凭证，具有可验证的签名和过期时间。widget-position.php 具备验证它所需的一切（验证辅助函数就在同一应用内），却从未调用它。

### 步骤 3：与确实进行身份验证的同级 widget 端点进行对比

**证据**：`public/api/widget/index.php:1115-1122`

```
$tokenData = verifyVisitorToken($visitorToken); if ($tokenData === null) { respond(-1, '访客令牌无效或已过期', null, 401); }
```

同级端点要求提供令牌，并在签名无效/过期时返回 401（另见第 1240-1265、1303-1365 行）。预期的安全姿态是验证 visitor_token；被标记的端点属于例外。速率限制（第 989、1106、2138 行的 checkIpRateLimit）在其他位置也有应用，但此处缺失。

### 步骤 4：追踪真实令牌如何到达该端点

**证据**：`public/customer.php:368-375 and public/widget/widget-render.php:363-377`

```
$widgetVisitorToken = $widgetPayload . '.' . hash_hmac('sha256', $widgetPayload, ChatCollaborationService::visitorTokenSecret()); ... fetch(POS_URL, { method:'POST', ... body: JSON.stringify({ site_public_id: SITE_ID, visitor_token: VISITOR_TK, ... }) })
```

合法客户端会发送它在页面中收到的已签名令牌。由于服务器从不重新验证它，任何调用者都可以替换为任意或第三方的令牌字符串；签名的保护价值在该端点处被完全丢弃。

### 步骤 5：通过数据库模式验证行放大路径

**证据**：`database/027_widget_positions.sql:23,29`

```
visitor_token VARCHAR(128) NOT NULL COMMENT '访客标识，取自挂件下发的 token', ... UNIQUE KEY uk_widget_position (site_id, visitor_token),
```

UNIQUE 键为 (site_id, visitor_token)。Upsert 只会合并相同令牌的重复项；任意唯一的令牌字符串都会各自创建新行。再加上没有任何速率限制（已通过 grep 确认：文件中没有 rate/rateLimit/throttle/flock），且请求体上限仅为 2048 字节，未认证的调用者即可使该表膨胀。该文件自身的注释（第 19-21 行）声称 upsert 可防止表增长，但这仅对重复的相同令牌成立。

### 步骤 6：排除框架/全局身份验证网关

**证据**：`public/widget/widget-position.php:30-31 and app/Core/bootstrap.php:29-31`

```
require dirname(__DIR__, 2) . '/app/Core/bootstrap.php'; \App\Security\LicenseGate::enforce();
```

bootstrap.php 仅设置错误显示、加载环境并调用 LicenseGate::enforce()。LicenseGate 验证的是部署的许可证/域名绑定（app/Security/LicenseGate.php），而非调用者的身份。没有 session/auth include，没有 auto_prepend，且 public/widget/ 下没有 .htaccess（只有 public/uploads/* 目录下有一个）。该端点可在未认证的情况下直接访问。

### 分析过程

- Q1：该端点是否执行会改变状态的操作？ -> 是：向 cc_widget_positions 执行 INSERT ... ON DUPLICATE KEY UPDATE（public/widget/widget-position.php:118-132）。
- Q2：该路径上是否强制执行任何身份验证？ -> 否：没有 session/auth include，没有调用 verifyVisitorToken，只有部署级别的 LicenseGate（bootstrap.php:31）。
- Q3：是否验证了调用者提供的身份值？ -> 否：$visitorToken 仅被 trim 和限制长度（widget-position.php:71,76），然后直接用作 upsert 键（:128）。应用自身的 verifyVisitorToken（public/api/widget/index.php:719-736）从未被调用。
- Q4：资源是否通过服务端检查限定到调用者？ -> 否：站点是否存在/活跃是唯一检查（:106-115）；调用者与 (site_id, visitor_token) 行之间没有任何所有权或签名绑定。
- Q5：是否存在补偿控制（速率限制/行数上限）？ -> 否：在文件中 grep rate/throttle/flock 无结果；2048 字节请求体上限和 128 字符令牌上限并不能限制行数。
- Q6：代码是否不可达或仅用于测试？ -> 否：它是 Web 根目录下的生产 POST 处理器，被 widget 客户端引用（public/widget/widget-render.php:523）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/widget/widget-position.php:126-132 将客户端提供的原始 visitor_token 绑定为 upsert 键，且不进行签名验证。
- public/api/widget/index.php:719-736 定义了 verifyVisitorToken（HMAC-SHA256 + hash_equals + exp 检查），而该端点从未调用它。
- public/api/widget/index.php:1115-1122 展示了预期姿态：缺失/无效的 visitor token => 401。
- database/027_widget_positions.sql:29 的 UNIQUE (site_id, visitor_token) 意味着不同令牌数量不受限制，即可创建无限多行。
- public/widget/widget-position.php:31 依赖 LicenseGate::enforce()，它是一个许可证网关，而非调用者身份验证（app/Core/bootstrap.php:31）。

## 4. 验证思路与复现步骤

- **前置条件**：站点可通过 HTTP/HTTPS 访问，并持有有效许可证（LicenseGate 通过）。攻击者只需一个能映射到活跃站点的 site_public_id；公开站点 ID 会出现在面向客户的 URL 中。无需 session、cookie 或令牌。

**复现步骤：**

1. 从任意客户页面 URL 获取某个活跃站点的有效 site_public_id。
2. 发送 POST /widget/widget-position.php，Content-Type: application/json，请求体为 {"site_public_id":"<known_id>","visitor_token":"attacker-chosen-string","position_x":1,"position_y":1,"viewport_hint":"desktop"}。
3. 观察到 HTTP 200 及 {"code":200,"message":"saved"}，即使 visitor_token 是任意未签名的值。
4. 每次使用新的唯一 visitor_token 值重复请求，确认每个请求都成功并使 cc_widget_positions 增长。
5. 为演示篡改，使用受害者的 visitor_token（例如从 URL/日志中泄露的令牌）重放同一请求，确认受害者存储的位置发生变化。

**测试样例：**

```
POST /widget/widget-position.php HTTP/1.1
Content-Type: application/json

{"site_public_id":"<known_active_site_public_id>","visitor_token":"forged-token-0001","position_x":10,"position_y":10}
```

- **预期现象**：对于 HMAC 签名缺失/无效的令牌，返回 200 响应且消息为 "saved"，并在 cc_widget_positions 中出现 (site_id, forged token) 的新行。相比之下，经过正确认证的同级调用 /api/widget/messages 在令牌无效时返回 401（public/api/widget/index.php:1120-1122）；该端点从不返回这种拒绝响应。

## 5. 修复建议

使用令牌前先验证它：对提供的 visitor_token 调用现有的 verifyVisitorToken(public/api/widget/index.php:719-736)，当其返回 null 时以 401 拒绝，并额外要求令牌 payload 中的 site_id 与从 site_public_id 解析出的站点匹配。由于当前无需令牌也能成功写入，请添加 IP 速率限制（复用 checkIpRateLimit，public/api/widget/index.php:268），并考虑对每个站点的位置行数设置上限或使其过期，以限制增长。如果出于可用性确实需要未认证写入，至少签名检查成本很低，并能关闭篡改向量；而行放大向量需要速率限制/行数上限。
