## 1. 总结

- **漏洞类型**：hardcoded_credentials（CWE-798）
- **标记位置**：config.php:10
- **漏洞描述**：config.php 以硬编码形式将应用的授权协议凭据（app_key 与 secret_key）内嵌为高熵 64 位十六进制字面量，且该文件已被跟踪并提交至版本控制。生产环境的授权校验路径（bootstrap.php:36 -> LicenseGate::enforce -> authorizeWithCode -> aimu_auth_check）直接 require config.php，并将 secret_key 用作 HMAC-SHA256 签名密钥、将 app_key 用作 AES-256 密钥，该路径中没有任何环境变量加载逻辑。唯一基于环境变量的覆盖入口（LicenseGate::config()）是从未被调用的死代码，因此硬编码值在运行时即为实际生效值。

## 2. 分析逻辑

### 步骤 1: 读取 config.php 中被标记的值

**证据**: `config.php:10`

```
'app_key' => 'ed41...42f7', (line 10)
'secret_key' => '7a48...d60d', (line 11)
```

两个值均为 64 字符的小写十六进制字符串（高熵，符合 256 位密钥形态），且不含任何占位符标记（并非 changeme/xxx/TODO/example）。它们看起来是真实的加密密钥，而不是模板值。

### 步骤 2: 确认授权客户端如何使用这些机密

**证据**: `auth.php:162`

```
$config = require __DIR__ . '/config.php';
```

运行时的授权客户端直接读取 config.php。它将 $config['secret_key'] 用作请求一次性验证码与签名的 HMAC-SHA256 密钥（auth.php:191、auth.php:193）以及缓存 MAC 密钥（auth.php:122、auth.php:155），并将 $config['app_key'] 用作请求/响应及缓存的 AES-256-CBC 密钥（auth.php:195、auth.php:226、auth.php:151）。上述任何一行都没有使用 Env::get。

### 步骤 3: 追踪从 HTTP 入口点出发的实时调用路径

**证据**: `app/Core/bootstrap.php:36`

```
App\Security\LicenseGate::enforce();
```

每个业务入口点（public/index.php:4、public/api/admin/index.php:5、public/api/widget/index.php:19 等）都会调用 LicenseGate::enforce()。enforce()（LicenseGate.php:77）-> isAuthorized()（LicenseGate.php:85）-> authorizeWithCode('')（LicenseGate.php:132）会 require auth.php（LicenseGate.php:142）并调用 aimu_auth_check()（LicenseGate.php:148），后者又会 require config.php（auth.php:162）。因此，这些硬编码值位于实时授权校验路径上。

### 步骤 4: 检查是否存在环境变量/密钥管理服务的覆盖机制

**证据**: `app/Security/LicenseGate.php:164`

```
'app_key' => trim((string) Env::get('LICENSE_APP_KEY', self::APP_KEY)),
```

LicenseGate::config()（LicenseGate.php:156-171）确实会读取 Env 并提供环境变量回退，但在 LicenseGate.php 中对 `self::` 执行 Grep 显示，`self::config()` 在该类及整个项目中从未被调用，因此该方法属于死代码。即便它被调用，其默认值也仍是同一批硬编码字面量。auth.php 路径完全不查询 Env。结果是：这些凭据在运行时没有被任何有效的环境变量加载机制覆盖。

### 步骤 5: 验证版本控制状态与运行状态

**证据**: `config.php:1`

```
git ls-files -> config.php, authcode.php, .env.example ; git cat-file -e HEAD:config.php -> present
```

config.php 已被跟踪并提交；.gitignore 中仅包含 `verify_requirements/`。仓库中没有任何写入方会重新生成 config.php（不存在对 config.php 的 file_put_contents/fwrite）。检出目录中不存在 .env 文件，且无论如何 auth.php 都会忽略 .env。此外，相同的值还被重复硬编码为 app/Security/LicenseGate.php:15-16 中的常量以及已提交的模板 .env.example:46-47。

### 分析过程

- Q1: 被标记的值是真实机密（而非占位符/测试/示例）吗？-> 是：config.php:10-11 保存的是 64 字符高熵十六进制值，不含占位符模式，被用作 HMAC-SHA256 与 AES-256 密钥（auth.php:191、195）。
- Q2: 该机密在运行时是否从环境变量/密钥管理服务加载？-> 实时路径上为否：auth.php:162 直接 require config.php 并使用这些字面量（auth.php:191、193、195、226）。基于环境变量的 LicenseGate::config()（LicenseGate.php:164-165）是死代码（没有 self::config() 调用方），且将相同的字面量硬编码为默认值。
- Q3: 该文件确实不在版本控制中吗？-> 否：`git ls-files` 与 `git cat-file -e HEAD:config.php` 证实 config.php 已被跟踪并提交；.gitignore 仅排除了 verify_requirements/。
- Q4: 该值是否经过加密或哈希，且密钥存储在仓库之外？-> 否：这些值就是 config.php 中的明文字面量，它们本身就是密钥。
- Q5: 该代码是否仅用于测试/演示/文档？-> 否：config.php 由生产环境的授权关卡加载，而该授权关卡被每个业务 API 入口点调用（public/index.php:4、public/api/admin/index.php:5）。
- 结论：一个真实的、明文的、已提交的凭据，被用于实时签名/加密路径且没有任何运行时密钥管理 -> 真实漏洞（TP）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- config.php:10-11 包含明文形式的授权 app_key 与 secret_key，二者均为 64 字符十六进制字面量。
- auth.php:162 `$config = require __DIR__ . '/config.php';` 与 auth.php:193 `hash_hmac('sha256', ..., (string) $config['secret_key'])` 表明该机密在运行时被原样用于签署授权协议。
- app/Core/bootstrap.php:36 `App\Security\LicenseGate::enforce();` 证明从生产入口点可达；LicenseGate.php:148 调用了 aimu_auth_check()。
- Git 跟踪情况：`git ls-files` 列出 config.php，且 `git cat-file -e HEAD:config.php` 执行成功，因此该机密已提交至版本控制；.gitignore 仅排除了 verify_requirements/。
- app/Security/LicenseGate.php:164-165 展示了唯一的 Env::get 覆盖入口，但 `self::config()` 没有任何调用方，因此它是死代码，无法保护实时路径。

## 4. 验证思路与复现步骤

- **前置条件**：拥有对仓库或产品发布副本的读取权限。这些凭据是静态的，且在所有部署中完全相同（相同的值也出现在已提交的模板 .env.example 中），因此，任何获取到源码的一方也就同时获取了授权协议密钥。

**复现步骤：**

1. 在项目检出目录中打开 config.php，读取 app_key（第 10 行）与 secret_key（第 11 行）的值，或运行 `git show HEAD:config.php` 从已提交历史中获取它们。
2. 通过 grep 其使用位置，确认这些值为实时生效值：`grep -rn "config\['secret_key'\]\|config\['app_key'\]" auth.php`（匹配 auth.php:191、193、195、226 ...）。
3. 通过搜索环境变量键，确认不存在运行时覆盖：`grep -rn "LICENSE_APP_KEY\|LICENSE_SECRET_KEY" app/` —— 它们仅出现在从未被调用的 LicenseGate::config() 中；实时路径 auth.php 会忽略它们。
4. 确认该文件已被提交：`git ls-files config.php` 有返回结果，且 `.gitignore` 仅包含暂存目录。

**测试样例：**

```
git show HEAD:config.php   # observe the literal app_key/secret_key fields are present in the committed file
```

- **预期现象**：已提交的 config.php 会暴露非占位符形式的 64 位十六进制 app_key 与 secret_key 值，而生产环境的授权客户端会将这些值直接传入 hash_hmac('sha256', ..., secret_key)（auth.php:193）与 openssl_encrypt(..., app_key)（auth.php:195），中间没有任何环境变量或密钥管理服务作为间接层——也就是说，仅凭代码库即可还原这些密钥。

## 5. 修复建议

从 config.php 中移除字面量形式的 app_key/secret_key，并停止提交它们。应在运行时从环境变量（例如 LICENSE_APP_KEY / LICENSE_SECRET_KEY）或经 .gitignore 排除的、按部署生成的配置文件中加载授权凭据，并让 auth.php 从该来源读取凭据，从而使实时路径真正遵循该覆盖机制（现有的 LicenseGate::config() 环境变量回退是死代码，必须接入或者删除）。为每个部署配置唯一的凭据值，轮换当前密钥对（因为已提交的副本必须视为已泄露），从 Git 历史中清除这些值，将已提交的 .env.example 中泄露的值替换为占位符，并在 CI 中加入密钥扫描检查（gitleaks/trufflehog）以防止问题再次发生。
