## 1. 总结

- **漏洞类型**：硬编码凭据（hardcoded_credentials，CWE-321）
- **标记位置**：app/Core/WidgetGuard.php:42
- **漏洞描述**：当 WIDGET_SIGN_KEY 为空且 APP_KEY 缺失时，WidgetGuard::signKey() 会静默回退到一个硬编码字面量：第 42 行读取 Env::get('APP_KEY', 'aimu-default-key')，并将其哈希为实际生效的 HMAC 密钥。该路径上没有任何环节会失效关闭——bootstrap.php 只加载 Env 并强制执行许可证门禁，管理员健康检查也只是发出警告——因此在任何未填充 APP_KEY 的部署中，渲染令牌签名密钥都是源码树中公开的常量。由于 public/widget/widget-render.php:31 仅通过 verifyRenderToken() 对请求进行认证，伪造的令牌可绕过域名白名单反爬门禁，因此这是一个真实漏洞（有条件触发，TP）：硬编码密钥/不安全默认值。

## 2. 分析逻辑

### 步骤 1：查看被标记的回退密钥派生逻辑

**证据**: `app/Core/WidgetGuard.php:36`

```
public static function signKey(): string { $key = (string) Env::get('WIDGET_SIGN_KEY', ''); if ($key !== '') { return $key; } $appKey = (string) Env::get('APP_KEY', 'aimu-default-key'); return hash('sha256', 'widget-sign|' . $appKey); }
```

签名密钥在被设置时为 WIDGET_SIGN_KEY，否则为 sha256('widget-sign|' . APP_KEY)；如果 APP_KEY 缺失，则为 sha256('widget-sign|aimu-default-key')——这是源码树中公开的常量。第 30-35 行的文档注释指出这是有意为之，以便全新部署“无需额外配置即可立即运行”，即一个显式的生产环境失效开放回退。

### 步骤 2：确认 Env::get 确实返回字面量默认值

**证据**: `app/Core/Env.php:27`

```
public static function get(string $key, $default = null) { $environment = getenv($key); return self::$values[$key] ?? ($environment !== false ? $environment : $default); }
```

当键既不存在于已加载的 .env（self::$values）中，也不存在于进程环境（getenv）中时，Env::get 会原样返回传入的默认值。因此，在没有 WIDGET_SIGN_KEY 且没有 APP_KEY 时，signKey() 会确定性地返回 sha256('widget-sign|aimu-default-key'|)。

### 步骤 3：检查启动引导处是否存在失效关闭的 APP_KEY 防护

**证据**: `app/Core/bootstrap.php:33`

```
App\Core\Env::load(dirname(__DIR__, 2) . '/.env'); date_default_timezone_set(...); App\Security\LicenseGate::enforce();
```

Bootstrap 加载 .env 并仅强制执行产品许可证门禁；它从不校验 APP_KEY。没有任何致命检查会阻止 widget 路径在使用默认密钥的情况下运行。

### 步骤 4：检查管理员健康检查是否执行强制措施

**证据**: `public/api/admin/index.php:2486`

```
if (strlen($appKey) < 16) $securityProblems[] = 'APP_KEY 未正确配置'; ... 'status' => ($securityProblems || $debugOn) ? 'warning' : 'ok',
```

代码库中唯一的 APP_KEY 校验只会将健康状态降级为 'warning'；它不会阻止请求，也不会阻止 WidgetGuard::signKey() 使用硬编码默认值。注意，同一代码块引用的是 WIDGET_TOKEN_SECRET（admin/index.php:2483），而非 WIDGET_SIGN_KEY，这证实 widget guard 的变量从未由安装器或文档填充。

### 步骤 5：确认该密钥被用作实际生效的 HMAC 签名密钥

**证据**: `app/Core/WidgetGuard.php:56`

```
$sig = hash_hmac('sha256', $payload, self::signKey());
```

signKey() 是 issueRenderToken()（第 56 行）和 verifyRenderToken()（第 84 行）唯一的 HMAC 密钥，因此该回退值直接控制令牌伪造——它并非与安全无关的用途。

### 步骤 6：确认验证汇点可在未认证情况下到达

**证据**: `public/widget/widget-render.php:31`

```
$claims = WidgetGuard::verifyRenderToken($rawToken); if ($claims === null) { echo '/* aimu widget: invalid or expired token */'; exit; }
```

widget-render.php 从攻击者可控的 'token' GET 参数获取令牌（第 24 行），并完全基于 verifyRenderToken() 控制响应。它是一个公共 HTTP 端点，仅由许可证门禁防护，而非用户认证，并且不会调用 checkDomain——因此伪造的令牌是唯一需要的凭据。

### 步骤 7：评估正常安装路径的缓解作用

**证据**: `app/Core/Installer.php:1896`

```
'APP_KEY=' . $this->envValue('base64:' . base64_encode(random_bytes(32))),
```

成功运行安装器会写入一个强随机 APP_KEY，因此在正确安装的系统上不会使用该硬编码字面量。因此，该漏洞以 APP_KEY 缺失/被重命名为条件，但失效开放默认值意味着在这种状态下没有任何机制拒绝服务。

### 步骤 8：确认相邻令牌路径中存在同类回退

**证据**: `app/Domain/Chat/ChatCollaborationService.php:139`

```
return $appKey !== '' ? hash('sha256', $appKey . '|widget-token') : hash('sha256', 'aimu-widget-install-required');
```

visitorTokenSecret() 重复了完全相同的失效开放模式（回退到硬编码字符串 'aimu-widget-install-required'），这佐证了静默弱化默认密钥处理是系统性问题，而非一次性问题。

### 分析过程

- 问题 1：代码中是否包含用作实际生效签名密钥的硬编码加密密钥？-> 是。WidgetGuard.php:42 将 APP_KEY 默认设为字面量 'aimu-default-key'，并在 WidgetGuard.php:56 和 :84 由 hash_hmac 使用。
- 问题 2：该密钥是否可从未认证入口点到达？-> 是。public/widget/widget-render.php:31 将攻击者可控的 'token' GET 参数传入 verifyRenderToken()，后者在 WidgetGuard.php:84 使用 signKey()。
- 问题 3：是否存在失效关闭防护，强制在使用默认值前完成配置？-> 否。bootstrap.php:33-36 加载 .env 并仅强制执行许可证门禁；admin/index.php:2486 记录一个非阻塞的 'warning'。
- 问题 4：该回退是否仅限于开发/测试代码？-> 否。它位于生产核心代码（app/Core/WidgetGuard.php）中，且第 30-35 行的文档注释指出该回退是专为全新部署有意设置的。
- 问题 5：强 APP_KEY 是否能消除该问题？-> 仅在条件成立时。Installer.php:1896 在正常安装时设置随机 APP_KEY，因此那里不会使用默认值；该发现之所以成立，正是因为当 APP_KEY 缺失或变量被重命名时，代码会静默降级而不是失效关闭。
- 问题 6：具体影响是什么？-> widget-render.php 不调用 checkDomain()，因此在默认密钥下伪造令牌会绕过域名白名单反爬门禁，并为任意 site_public_id 产出渲染后的 widget 载荷。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Core/WidgetGuard.php:42 将 'aimu-default-key' 硬编码为 APP_KEY 回退值，并成为 HMAC 签名密钥。
- app/Core/WidgetGuard.php:56 和 :84 使用 signKey() 作为签发和验证渲染令牌的唯一 HMAC 密钥。
- app/Core/bootstrap.php:33-36 从不校验 APP_KEY（仅执行 Env::load 和 LicenseGate::enforce）。
- public/api/admin/index.php:2486 仅将错误的 APP_KEY 视为非阻塞的 'warning'。
- public/widget/widget-render.php:31 仅通过 verifyRenderToken() 认证公共请求，且从不调用 checkDomain()。
- app/Core/Installer.php:1896 在正常安装时设置随机 APP_KEY，这就是该发现是条件触发而非始终可利用的原因。

## 4. 验证思路与复现步骤

- **前置条件**：部署未填充 APP_KEY（手写 .env 省略了它，或变量被重命名），并且未设置 WIDGET_SIGN_KEY——guard 的变量从未由安装器写入或记录在文档中。许可证门禁（LicenseGate::enforce）必须通过，以便端点能够提供服务。攻击者只需要能够网络访问公共 /widget/ 端点；不涉及用户认证。

**复现步骤：**

1. 推导默认密钥：K = sha256('widget-sign|aimu-default-key')（对应 app/Core/WidgetGuard.php:42-43 的精确表达式）。
2. 选择受害者相关值，例如 site_public_id=<target site public_id>、origin=<any value>、issuedAt=当前 Unix 时间、nonce=<8 random bytes hex>。
3. 计算 payload = '{site_public_id}|{origin}|{issuedAt}|{nonce}' 和 sig = HMAC-SHA256(payload, K)，复现 app/Core/WidgetGuard.php:55-56。
4. 完全按照 issueRenderToken 的方式构造令牌：base64url( payload . '|' . sig )，并将 '+/' -> '-_' 且去掉 '='（WidgetGuard.php:58）。
5. 直接请求渲染端点，绕过 /widget/widget-token.php，从而绕过 checkDomain()：GET /widget/widget-render.php?token=<forged token>。
6. 观察响应是渲染后的 widget JavaScript/配置（cfg 对象），而不是 'invalid or expired token' 注释。

**测试样例：**

```
GET /widget/widget-render.php?token=<base64url(site_public_id|origin|issuedAt|nonce|hex(HMAC_SHA256(site_public_id|origin|issuedAt|nonce, sha256('widget-sign|aimu-default-key'))))>
```

- **预期现象**：存在漏洞的部署会为任意 site_public_id 返回 widget 脚本/配置载荷，且从不调用 widget-token.php，即使 checkDomain() 本会拒绝调用方域名；加固后（失效关闭）的部署会返回 '/* aimu widget: invalid or expired token */'，或因为未配置强密钥而拒绝签发/验证令牌。

## 5. 修复建议

让 WidgetGuard::signKey() 失效关闭：如果 WIDGET_SIGN_KEY 和 APP_KEY 均为空/缺失，则抛出 RuntimeException（例如 'WIDGET_SIGN_KEY 未正确配置'），而不是替换为 'aimu-default-key'；可参照 app/Security/Crypto.php:58 在 APP_KEY 不可用时已经会抛出的做法。强制最小密钥长度（>=32 字节），并按照 Crypto::key() 的方式重建派生密钥，而不是接受任意短的 APP_KEY。此外，将变量名与系统其余部分对齐（安装器、.env.example 和管理员健康检查使用 WIDGET_TOKEN_SECRET，而 WidgetGuard 读取 WIDGET_SIGN_KEY），以便真正使预期的显式密钥可配置，并将 app/Domain/Chat/ChatCollaborationService.php:139 更新为相同的失效关闭行为。
