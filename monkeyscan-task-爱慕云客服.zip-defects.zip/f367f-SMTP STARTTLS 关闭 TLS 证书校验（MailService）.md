## 1. 总结

- **漏洞类型**: insecure_tls (CWE-295)
- **标记位置**: app/Domain/Mail/MailService.php:254
- **漏洞描述**: MailService::smtpSend() 的 STARTTLS 分支（加密方式配置为 'tls'，例如端口 587）在将明文 SMTP 套接字升级为 TLS 时，传入了一个显式流上下文，其中 verify_peer=false、verify_peer_name=false，证书链验证与主机名验证由此同时被禁用。这段代码是无条件生效的生产代码，可通过管理员邮件测试端点以及告警/租户提醒流程触达；它也是整个代码库中唯一禁用验证的位置（PHPMailer、SmtpMailer、AliyunSms 与 Captcha 均使用 verify_peer=true）。能够拦截或重定向该 SMTP 连接的网络攻击者可以出示任意证书，进而窃取 AUTH LOGIN 的 base64 凭证以及邮件正文。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的 STARTTLS 分支

**证据**: `app/Domain/Mail/MailService.php:252-259`

```
if ($enc === 'tls') {
    $this->cmd($fp, 'STARTTLS', [220], $errorOut);
    $crypto = @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT,
        stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'SNI_server_name' => $host]]));
    if ($crypto !== true) { $errorOut = 'STARTTLS 加密握手失败'; return false; }
    $this->cmd($fp, 'EHLO ' . $ehlo, [250], $errorOut);
}
```

此处向 stream_socket_enable_crypto 传入了一个显式 SSL 上下文，其中 verify_peer=false、verify_peer_name=false，即对 STARTTLS 升级而言，证书链验证与主机名验证均已禁用。这与不安全模式 `stream_context_create(['ssl' => ['verify_peer' => false]])` 如出一辙。

### 步骤 2: 确认不安全的上下文确实传入了加密调用（套接字没有安全的默认上下文）

**证据**: `app/Domain/Mail/MailService.php:240-255`

```
$remote = $enc === 'ssl' ? 'ssl://' . $host : $host;
$fp = @stream_socket_client($remote . ':' . $port, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT);
...
$crypto = @stream_socket_enable_crypto($fp, true, ..., stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, ...]]));
```

明文套接字在创建时（第 242 行）未指定任何流上下文，因此流上并未附加验证性上下文。STARTTLS 加密升级时唯一起作用的上下文，就是第 255 行内联构造的那个显式禁用验证的上下文，没有任何其他环节会恢复验证。

### 步骤 3: 与同一代码库中其他安全实现进行对比

**证据**: `app/Domain/Notification/PHPMailer.php:157-163, app/Domain/Notification/SmtpMailer.php:128-131, app/Domain/Notification/AliyunSms.php:262`

```
$context = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false]]);
// SmtpMailer: 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
// AliyunSms:  'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
```

PHPMailer、SmtpMailer 和 AliyunSms 均强制使用 verify_peer=true。对 verify_peer 做全项目范围的 Grep 搜索，结果显示 MailService.php:255 是唯一出现 verify_peer=false 的位置，说明这是一处不一致的缺陷，而非有意为之的策略。

### 步骤 4: 确认生产可达性，并确认加密方式可由管理员配置

**证据**: `public/api/admin/index.php:2000-2011, public/api/admin/index.php:504-512, app/Domain/Mail/MailService.php:62`

```
if ($path === '/mail/test' && $method === 'POST') {
    if (!PlatformAuth::isSuperAdmin()) { respond(-1, '仅超级管理员可发送测试邮件', null, 403); }
    ...
    $result = (new \App\Domain\Mail\MailService())->testSend($to);
}
```

MailService 属于生产代码（而非测试/开发代码）。SMTP 的 'encryption' 值由管理员设置端点（index.php:507）从管理员提供的输入中保存下来，并在 MailService.php:62 处读取；将其设为 'tls' 恰好会触发该易受攻击的分支。testSend() -> smtpSend() 可到达第 254 行，send()/sendTemplate() 也能在告警与租户提醒流程中到达该处（app/Domain/Ops/AlertService.php:56-62, scripts/tenant-remind.php:25-99）。tls 分支周边不存在任何环境开关。

### 分析过程

- Q1: 证书链验证是否被禁用 / 是否安装了接受一切的验证器？ -> 是：app/Domain/Mail/MailService.php:255 处 verify_peer=false（步骤 1）。继续到 Q3。
- Q2: 主机名验证是否也被禁用？ -> 同样是：MailService.php:255 处 verify_peer_name=false（步骤 1）。两项检查均缺失。
- Q3: 这是生产配置（而非开发/测试/localhost）吗？ -> 是：app/Domain/Mail/MailService.php 是主应用代码，可从管理员 /mail/test 端点以及生产告警/提醒流程触达（步骤 4）。
- Q4: 该连接是否指向具有基础设施级 TLS（服务网格）的内部服务？ -> 否：它是一个通用 SMTP 客户端，连接的是可配置的外部邮件主机；仓库中不存在网格/sidecar 配置（步骤 4）。
- Q5: 自定义信任是否仅限于某个特定的内部 CA（而非接受一切）？ -> 否：根本没有配置任何信任锚；验证被直接关闭，因此会接受任意证书（步骤 1）。
- Q6: 该代码是否处于测试/演示/生成上下文，或确实不可达？ -> 否：它是可达的生产代码（步骤 4）。
- 结论: -> 真实漏洞（TP，CWE-295 证书验证不当）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Domain/Mail/MailService.php:255 在 STARTTLS 路径上向 stream_socket_enable_crypto 传入了 stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, ...]])。
- app/Domain/Mail/MailService.php:242 在创建套接字时未指定任何流上下文，因此在加密升级时没有任何机制恢复验证。
- 对 verify_peer 做全项目范围的 Grep 搜索，结果显示 MailService.php:255 是唯一出现 verify_peer=false 的位置；PHPMailer.php:159-161、SmtpMailer.php:130 和 AliyunSms.php:262 均使用 verify_peer=true。
- public/api/admin/index.php:2008 调用了 testSend()，且 index.php:507 持久化了管理员提供的 'encryption' 设置，使得 'tls' 分支在生产环境中可达。
- app/Domain/Mail/MailService.php:264-266 在未经验证的 TLS 会话上发送 AUTH LOGIN 凭证（base64 编码，无挑战保护），因此拦截即可获取 SMTP 凭证与邮件内容。

## 4. 验证思路与复现步骤

- **前置条件**：平台邮件渠道已启用 STARTTLS 配置：SMTP 凭证以 encryption='tls'（通常为端口 587）保存，使 MailService::config()['encryption'] === 'tls'。攻击者必须位于服务器与所配置 SMTP 主机之间的网络路径上（ARP 欺骗、DNS 重绑定、敌对环境/已被攻陷的网络，或透明代理），并能够使用自签名证书完成 TCP/TLS 握手。

**复现步骤：**

1. 在管理面板中配置使用 STARTTLS（encryption = 'tls'）的主机和端口，然后通过管理员"发送测试"端点 POST /api/admin/mail/test，或任何调用 MailService::send()/sendTemplate() 的告警/租户提醒流程触发投递。
2. 在网络路径上部署一个 MITM 响应器，应答 TCP 连接，并针对该主机名出示自签名证书。

**测试样例：**

```
On the network path, intercept the connection to the configured SMTP host:port, respond to EHLO, answer 'STARTTLS' with 220, and during the TLS handshake present a certificate that does NOT match the SMTP hostname (e.g. a self-signed cert for 'attacker.local'); after the handshake complete AUTH LOGIN and capture the following bytes.
```

- **预期现象**：尽管证书不可信或不匹配，握手仍然成功（代码中的 stream_socket_enable_crypto 返回 true，发送流程继续进入 AUTH LOGIN）。若验证被正确启用，stream_socket_enable_crypto 会失败，代码将设置 'STARTTLS 加密握手失败' 并中止。观察到在伪造证书下发送成功，且拦截器捕获到 base64 编码的用户名/密码与邮件正文，即可确认该漏洞。

## 5. 修复建议

在 app/Domain/Mail/MailService.php:254-255 中，停止以禁用验证的方式覆盖 SSL 上下文。可以完全移除内联上下文，并在向流附加验证性上下文后调用 stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)；或者传入 stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false, 'SNI_server_name' => $host]])，与 PHPMailer::connect()（app/Domain/Notification/PHPMailer.php:157-163）保持一致。此外，在第 242 行创建套接字时也应附加验证性上下文，以确保套接字的默认上下文是安全的。如果必须支持自签名内部 SMTP 服务器，应将其作为显式的选择加入设置对外暴露（例如由管理员配置的 CA 文件路径），而不是无条件地禁用验证。
