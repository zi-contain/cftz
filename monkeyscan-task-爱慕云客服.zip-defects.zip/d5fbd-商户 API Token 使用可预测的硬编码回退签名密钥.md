## 1. 总结

- **漏洞类型**：hardcoded_credentials (CWE-798)
- **标记位置**：app/Security/TenantAuth.php:312
- **漏洞描述**：当 storage/app-token-secret.key 缺失或长度不足 16 字节时，tokenSecret() 会返回一个完全确定性的 HMAC 密钥，该密钥由硬编码的前缀/盐常量与 md5(__DIR__ . '|aimu_cloud_secure_2024') 拼接而成。代码库中没有任何地方会生成该文件（版本控制中仅跟踪 storage/*/.gitkeep，且安装程序只配置 APP_KEY），因此在每次全新部署中，这个可预测的回退值就是实际生效的签名密钥。同一密钥既在 issueToken() 中用于签发令牌，也在 authenticateByToken() 中用于验证令牌，而 requireMerchant() 将其作为公开商户 API 的唯一认证关口，从而使知道（已公开的）安装路径的攻击者能够为任意活跃商户用户 id 伪造令牌。

## 2. 分析逻辑

### 步骤 1: 读取被标记的密钥派生逻辑

**证据**: `app/Security/TenantAuth.php:303-316`

```
private static function tokenSecret(): string { static $secret = null; if ($secret === null) { $file = dirname(__DIR__, 2) . '/storage/app-token-secret.key'; if (is_file($file)) { $secret = trim((string) file_get_contents($file)); } if (!$secret || strlen($secret) < 16) { $secret = 'aimu_kefu_v2_token_sig_' . md5(__DIR__ . '|aimu_cloud_secure_2024'); } } return $secret; }
```

当密钥文件缺失或过短时，HMAC 密钥完全由两个源码常量与 __DIR__（该文件自身的安装目录）确定，是纯函数计算结果：既无随机性，也不依赖环境变量或密钥管理服务。这是硬编码的回退密钥，而非每次部署独立的密钥。

### 步骤 2: 确认没有任何机制会生成密钥文件（回退值即默认值）

**证据**: `storage/（已跟踪内容）与 app/Core/Installer.php:1896`

```
git ls-files storage/ -> storage/.gitkeep, storage/cache/.gitkeep, storage/logs/.gitkeep, storage/uploads/.gitkeep (no app-token-secret.key). Installer.php:1896 -> 'APP_KEY=' . $this->envValue('base64:' . base64_encode(random_bytes(32)))
```

全仓库 grep 显示，storage/app-token-secret.key 仅在 TenantAuth.php:307 的读取处被引用，不存在任何写入方：安装程序只生成 APP_KEY，且 .env.example 中未列出任何 token-secret 变量。在全新安装环境中，is_file() 为 false，因此总会选中这个确定性的回退密钥。

### 步骤 3: 追踪该密钥在签发与验证中的使用

**证据**: `app/Security/TenantAuth.php:332 与 app/Security/TenantAuth.php:355`

```
issueToken(): $signature = hash_hmac('sha256', $payloadB64, self::tokenSecret());  authenticateByToken(): $expectedSig = hash_hmac('sha256', $payloadB64, self::tokenSecret()); if (!hash_equals($expectedSig, $signature)) { return null; }
```

同一个回退密钥既在 issueToken() 中签发令牌，也在 authenticateByToken() 中验证令牌。令牌是自包含的（payloadB64 + '.' + HMAC），因此任何能派生出该密钥的人，都可以用任意 uid 和未来的 exp 铸造令牌；唯一的签名校验就是与该密钥进行 hash_equals 比较。

### 步骤 4: 确认伪造令牌可获取商户访问权限

**证据**: `public/api/merchant/index.php:201-211, 1035, 1887`

```
requireMerchant(): $token = (string) ($_SERVER['HTTP_TOKEN'] ?? ''); ... $tokenUser = TenantAuth::authenticateByToken($token, 'app'); if ($tokenUser === null) { $tokenUser = TenantAuth::authenticateByToken($token, null); } if ($tokenUser !== null) { $_SESSION['tenant_user'] = $tokenUser; return $tokenUser; }  // login: TenantAuth::issueToken((int) $user['id'], 2592000, $loginClient)
```

requireMerchant() 是商户 API 的唯一认证关口（在第 1887、7990、8013、8047、8110 行等处使用）。它会接受来自 HTTP_TOKEN、Authorization: Bearer、_token POST/GET 或 JSON 请求体的令牌。authenticateByToken() 仅校验 HMAC，然后按 uid 加载用户；一个带有有效 uid 的伪造令牌即可在无需任何凭据的情况下获得完全认证的会话。

### 步骤 5: 验证该端点可达且路径已知/可猜测

**证据**: `deploy/nginx/aimu-customer-cloud.conf:49-50 与 docs/BT-INSTALL.md:8`

```
location /api/merchant/ { rewrite ^/api/merchant/(.*)$ /api/merchant/index.php?route=$1&$args last; }   // docs: /www/wwwroot/aimu-customer-cloud
```

/api/merchant/ 没有任何 auth_basic/deny 防护；index.php:14-69 处的 CORS 代码块仅在存在 Origin 头时才会执行，因此非浏览器的直接请求会绕过它。文档中给出了规范安装路径 /www/wwwroot/aimu-customer-cloud，因此 __DIR__（/www/wwwroot/aimu-customer-cloud/app/Security）是已知的，md5 的输入完全可推导。

### 分析过程

- Q1: 被标记的值是真实密钥（而非占位符/测试/示例）吗？ -> 是。它是用于生产环境商户令牌的实际 HMAC 密钥（TenantAuth.php:332,355），并非占位值；它被用于认证真实的 API 调用（步骤 1）。
- Q2: 它在运行时是否从环境变量或密钥管理服务加载？ -> 否。tokenSecret() 由源码内常量与 md5(__DIR__ . '|aimu_cloud_secure_2024') 计算得到；该路径上不存在 getenv/Env::get，也不存在 Vault/密钥管理集成（步骤 1）。
- Q3: 包含该密钥的文件是否确实不在版本控制中？ -> 否。该密钥存在于受跟踪的源码 app/Security/TenantAuth.php:312 中。密钥文件 storage/app-token-secret.key 不存在，而这正是默认使用硬编码回退值的原因（步骤 2）。
- Q4: 该值是否经过加密/哈希，且密钥保存在仓库之外？ -> 否。它是明文派生；唯一的“哈希”（md5）以公开常量和源码路径作为输入，而非外部密钥（步骤 1）。
- Q5: 该代码是否仅用于测试/演示/文档？ -> 否。它是公开商户 API 入口点所调用的生产认证路径（步骤 3-4）。
- 结论：决策树的所有分支均指向真实漏洞（TP）——受版本控制的源码中存在硬编码回退签名密钥，可用于认证商户 API 令牌。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Security/TenantAuth.php:312 - 回退密钥 = 'aimu_kefu_v2_token_sig_' . md5(__DIR__ . '|aimu_cloud_secure_2024')；两个输入均为源码常量，不存在每次部署的熵。
- app/Security/TenantAuth.php:307 - storage/app-token-secret.key 的唯一引用是读取；代码中没有任何地方创建它，且安装程序（app/Core/Installer.php:1896）只配置 APP_KEY。
- app/Security/TenantAuth.php:332 与 :355 - 同一个 tokenSecret() 值用于签发（issueToken）和验证（authenticateByToken）商户令牌。
- public/api/merchant/index.php:199-211 - requireMerchant() 仅凭请求提供的令牌完成认证并建立会话，没有任何凭据校验。
- deploy/nginx/aimu-customer-cloud.conf:49-50 - /api/merchant/ 被公开路由，没有额外的认证层。
- docs/BT-INSTALL.md:8 - 规范安装路径 /www/wwwroot/aimu-customer-cloud 已公开，因此 md5 输入中的 __DIR__ 是已知/可推导的。

## 4. 验证思路与复现步骤

- **前置条件**：目标运行默认部署（storage/app-token-secret.key 从未被生成——即随附的默认状态），这使 tokenSecret() 返回确定性的回退值。攻击者已知或可猜测安装路径（文档中为 /www/wwwroot/aimu-customer-cloud），并针对一个满足以下条件的用户 id：该用户存在且 status='active'、租户状态属于 {trial,active,past_due} 且审核已通过。/api/merchant/ 路由在没有任何网络层认证的情况下即可访问（nginx 中没有 auth_basic/deny）。

**复现步骤：**

1. 计算签名密钥：SECRET = 'aimu_kefu_v2_token_sig_' + md5('<install_root>/app/Security' + '|aimu_cloud_secure_2024')。
2. 构造载荷 JSON {"uid":<target_user_id>,"iat":<now>,"exp":<now+2592000>,"client":"app"}，并将其以无填充的 base64url 编码 -> payloadB64。
3. 计算 signature = HMAC_SHA256(payloadB64, SECRET)，使用小写十六进制；伪造令牌为 payloadB64 + '.' + signature。
4. 使用伪造令牌发送任意需认证的商户请求，例如通过 token 头或 Authorization: Bearer。
5. 读取某个需要特权的商户端点，例如 GET /api/merchant/storage/quota 或 GET /api/merchant/storage/list，这些端点会调用 requireMerchant() 并返回被冒充商户的租户数据。

**测试样例：**

```
curl -s -H 'token: <payloadB64>.<hmac>' -H 'X-Client-Type: app' 'https://<platform-host>/api/merchant/storage/quota'  -- where <payloadB64>.<hmac> is forged as described (base64url({"uid":1,"iat":... ,"exp":...,"client":"app"}) + '.' + HMAC_SHA256(payloadB64, SECRET)).
```

- **预期现象**：仅携带伪造令牌（无 cookie、无密码）的请求返回 HTTP 200 及目标商户的租户数据（used_bytes/quota_bytes、文件列表等），而不是 401 响应体 {"code":912,"message":"登录身份已失效，请重新登录"}。对于同一 uid，服务器合法签发的令牌行为完全相同，而使用任何其他密钥签名的令牌会在 authenticateByToken() 处被拒绝——因此使用自行计算的密钥成功访问即证明了该绕过。

## 5. 修复建议

移除确定性的回退逻辑：如果 storage/app-token-secret.key 缺失、不可读或短于 32 字节，应安全地失败（fail closed），即从 tokenSecret() 抛出异常/返回 null，而不是从源码常量派生密钥。在安装过程中使用 random_bytes(32) 生成该密钥，以 0600 权限写入 storage/ 下并置于 Web 根目录之外，并在 .env.example/安装程序中与 APP_KEY 一并说明。将现有的回退密钥视为已泄露：轮换密钥并使尚未失效的商户令牌全部失效（这些令牌是自包含的，因此任何使用回退密钥签名的令牌都必须被拒绝，例如通过提升 key id/版本）。可选地，遵循 .env.example 中 WIDGET_TOKEN_SECRET 已有的模式，通过 App\Core\Env::get() 从环境变量加载密钥且不设默认值。
