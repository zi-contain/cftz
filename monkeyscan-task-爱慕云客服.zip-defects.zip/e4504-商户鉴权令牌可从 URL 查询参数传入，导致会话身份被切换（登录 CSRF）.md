## 1. 总结

- **漏洞类型**：CSRF (CWE-598)
- **标记位置**：public/api/merchant/index.php:186
- **漏洞描述**：requireMerchant() 会从 URL 查询字符串（$_GET['_token']）读取 Bearer 凭据，并在令牌认证成功后，将解析出的身份写入当前会话，而未调用 Session::regenerate()。由于传递给 TenantAuth::authenticateByToken() 的回退作用域为 null，客户端作用域检查被跳过，因此 Web 签发的令牌（client='web'）会被接受。这样一来，攻击者只需构造一个携带其有效令牌的顶层 GET 链接，即可将受害者的会话重新绑定到攻击者的租户账号（登录 CSRF/会话身份切换）；此外，该凭据本身还会在 URL 中传输，因而可能被访问日志、浏览器历史和 Referer 捕获。

## 2. 分析逻辑

### 步骤 1: 被标记的汇聚点：从 URL 查询字符串读取令牌

**证据**: `public/api/merchant/index.php:185-187`

```
if ($token === '') {
    $token = (string) ($_POST['_token'] ?? $_GET['_token'] ?? '');
}
```

当请求中不存在 token/Authorization 头时，Bearer 凭据会直接从 $_GET['_token'] 接受，因此任意已认证路由的普通 GET 请求都可以在 URL 中携带该凭据（CWE-598）。

### 步骤 2: 令牌认证会覆盖会话身份而不重新生成会话

**证据**: `public/api/merchant/index.php:199-211`

```
$tokenUser = TenantAuth::authenticateByToken($token, 'app');
if ($tokenUser === null) {
    $tokenUser = TenantAuth::authenticateByToken($token, null);
}
if ($tokenUser !== null) {
    Session::start();
    $_SESSION['tenant_user'] = $tokenUser;
    $_SESSION['merchant_api_token'] = $token;
    return $tokenUser;
}
```

认证成功后，代码会将 $_SESSION['tenant_user'] 替换为令牌所有者，但从不调用 Session::regenerate()（在该文件中 grep 'regenerate' 没有任何结果），因此原会话 ID 得以保留，只是被重新绑定到另一个账号。

### 步骤 3: null 回退作用域破坏了 app/web 客户端隔离

**证据**: `app/Security/TenantAuth.php:343-376`

```
if ($expectedClient !== null) {
    $tokenClient = (string) ($payload['client'] ?? 'web');
    if ($tokenClient !== $expectedClient) {
        return null;
    }
}
```

当 $expectedClient 为 null 时，客户端检查会被完全跳过，因此以 client='web' 签发的令牌在 'app' 尝试中会失败，随后在 null 作用域尝试中成功。

### 步骤 4: Web 令牌正是正常登录所签发的内容

**证据**: `public/api/merchant/index.php:1032-1035`

```
$loginClient = ((string) ($_SERVER['HTTP_X_CLIENT_TYPE'] ?? '') === 'app') ? 'app' : 'web';
$user = TenantAuth::user() ?? [];
$token = !empty($user['id'])
    ? TenantAuth::issueToken((int) $user['id'], 2592000, $loginClient)
```

任何通过浏览器登录的商户都会获得一个 client='web' 且 TTL 为 30 天的令牌，而该令牌正是能够通过 null 作用域回退的凭据。因此，攻击者只需拥有一个普通账号即可。

### 步骤 5: 会话 Cookie 为 SameSite=Lax，因此受害者的会话会在顶层 GET 中存在

**证据**: `app/Security/Session.php:15-21`

```
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => self::isHttps(),
    'httponly' => true,
    'samesite' => 'Lax',
]);
```

SameSite=Lax 允许会话 Cookie 在跨站顶层 GET 导航中发送，因此携带 _token 的链接会在受害者现有会话中被处理，随后该会话即被重新绑定到攻击者的身份。

### 步骤 6: 端点仅由基于 Origin 的 CORS 防护；不验证任何反 CSRF 令牌

**证据**: `public/api/merchant/index.php:14-15`

```
$corsOrigin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
if ($corsOrigin !== '') {
```

CORS/主机检查仅在存在 Origin 头时执行；用户发起的顶层 GET 导航不会发送 Origin，因此该检查会被跳过。全项目 grep 显示，Csrf::verify 仅用于 public/robot-admin.php、public/customer.php 和 public/api/send-code.php，从未用于商户 API，因此通过令牌提供的身份无需任何 CSRF 令牌。

### 步骤 7: 可达性：requireMerchant() 在路由处理之前运行，且身份由 GET 路由返回

**证据**: `public/api/merchant/index.php:1887`

```
$user = requireMerchant();
```

对于所有已认证路由（例如 /home 位于 2286，/verify/status 位于 1980，/security/overview 位于 1894），requireMerchant() 都会被调用一次；而 /verify/status 和 /home 会返回 currentUserResponse($user)（1987、2355），从而在响应中暴露可观察到的身份。令牌采用发生在任何路由特定逻辑之前。

### 分析过程

- Q1: 是否从 URL 查询字符串接受敏感凭据？ -> 是（步骤 1，index.php:186 读取 $_GET['_token']）。
- Q2: 成功的令牌认证是否会在不重新生成会话的情况下改变会话身份？ -> 是（步骤 2，index.php:206-211 设置 $_SESSION['tenant_user']，没有 Session::regenerate()）。
- Q3: 普通攻击者能否获得一个能通过校验的令牌？ -> 是（步骤 3 + 步骤 4：null 回退跳过客户端检查；正常 Web 登录签发 client='web' 令牌）。
- Q4: 受害者的会话是否会参与跨站顶层 GET？ -> 是（步骤 5，Session.php:20 SameSite=Lax；步骤 6，仅 Origin 的 CORS 防护，且该 API 中没有 Csrf::verify）。
- Q5: 汇聚点是否可达，且其效果是否可观察？ -> 是（步骤 7，index.php:1887 的 requireMerchant() 先于路由；/verify/status 和 /home 返回当前身份）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/merchant/index.php:186 从 $_GET['_token'] 接受 Bearer 凭据。
- public/api/merchant/index.php:206-211 将令牌所有者写入 $_SESSION['tenant_user'] 和 $_SESSION['merchant_api_token']，且未调用 Session::regenerate()。
- app/Security/TenantAuth.php:371-376 当预期客户端为 null 时会跳过客户端作用域检查，因此 index.php:204 的回退会接受 Web 令牌。
- app/Security/Session.php:20 将会话 Cookie 设置为 SameSite=Lax，因此跨站顶层 GET 会携带受害者的会话。
- public/api/merchant/index.php 中不存在 Csrf::verify 调用（仅 public/robot-admin.php、public/customer.php、public/api/send-code.php 使用它）。

## 4. 验证思路与复现步骤

- **前置条件**：攻击者持有自己账号的有效商户令牌（可通过在浏览器中正常登录（POST route=/login）获取，client='web'，TTL 为 30 天）。受害者持有以自己身份登录的有效商户会话 Cookie（AIMU_SUPPORT_SESSION）。受害者打开攻击者提供的链接（顶层 GET 导航，不发送 Origin 头；在 SameSite=Lax 下仍会发送会话 Cookie）。

**复现步骤：**

1. 以攻击者身份，使用有效凭据 POST 到 route=/login，并记录返回的 `token` 值。
2. 确认受害者已登录商户平台并持有 AIMU_SUPPORT_SESSION Cookie。
3. 向受害者发送形式为 https://<platform-host>/api/merchant/index.php?route=/verify/status&_token=<attacker_token> 的链接。
4. 诱导受害者打开该链接；服务器会在 index.php:186 从 $_GET 读取 _token，authenticateByToken(token,'app') 因客户端作用域检查失败，authenticateByToken(token,null) 成功，并且 $_SESSION['tenant_user'] 被替换（index.php:206-211）。
5. 从同一浏览器会话重新请求 route=/verify/status，并将返回的用户对象与访问前的值进行比较。

**测试样例：**

```
GET /api/merchant/index.php?route=/verify/status&_token=<attacker_token> HTTP/1.1 with header Cookie: AIMU_SUPPORT_SESSION=<victim_session_id> (no Origin header, simulating a top-level navigation).
```

- **预期现象**：在访问精心构造的 URL 之前，route=/verify/status 通过 currentUserResponse() 返回受害者自己的 id/phone/tenantId；在加载该 URL 之后，同一会话返回攻击者的 id/phone/tenantId，而会话 Cookie 值保持不变（未重新生成）。受害者随后执行的写入操作会落到攻击者的租户中，并在攻击者登录自己账号时可见。

## 5. 修复建议

删除 public/api/merchant/index.php:186 处的 $_GET['_token'] 回退，使令牌仅从 `token`/Authorization 头读取；或者，如果确实需要正文回退，则将其限制为 POST JSON `_token`。移除 index.php:204 处的 null 作用域回退（或要求显式客户端作用域），避免 Web 令牌在 app 流程中被静默接受。当令牌认证请求成功时，在写入 $_SESSION['tenant_user'] 之前调用 Session::regenerate()，并将会话绑定到令牌所有者；同时，对任何通过令牌提供身份的请求，要求提供反 CSRF 令牌或自定义头，并使用 SameSite=Strict。
