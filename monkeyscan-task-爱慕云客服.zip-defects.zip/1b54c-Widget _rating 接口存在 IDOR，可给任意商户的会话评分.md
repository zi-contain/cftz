## 1. 总结

- **漏洞类型**：IDOR (CWE-639)
- **标记位置**：public/api/widget/index.php:2174
- **漏洞描述**：widget 的 /rating 处理逻辑虽校验了访客令牌，却从未使用解析得到的 visitor_id 来限定被评价的会话。它仅根据客户端提供的 conversation_id 加载会话，没有任何访客范围约束（public/api/widget/index.php:2174），随后使用该会话自身的 tenant_id/agent_id/visitor_id 写入/覆盖评价（第 2178-2186 行）。由于 cc_conversations.id 是顺序自增（AUTO_INCREMENT）整数，且 cc_ratings 在 conversation_id 上设有 UNIQUE KEY，任何持有有效访客令牌的人（该令牌由公开的 /init 端点自由签发）都可以注入或覆盖任意租户的任意会话的评价与评论。这是一个跨租户的 IDOR / 数据完整性缺陷。

## 2. 分析逻辑

### 步骤 1：阅读被标记的 /rating 处理逻辑

**证据**：`public/api/widget/index.php:2164-2188`

```
$conversationId = (int) ($data['conversation_id'] ?? 0); ... $tokenData = verifyVisitorToken($visitorToken); if ($tokenData === null) respond(-1, '访客令牌无效', null, 401); $conv = $pdo->prepare('SELECT id,tenant_id,agent_id,visitor_id,status FROM cc_conversations WHERE id=:id'); $conv->execute(['id' => $conversationId]); ... INSERT INTO cc_ratings (...) VALUES (:cid,:tid,:aid,:vid,:score,:comment) ON DUPLICATE KEY UPDATE score=VALUES(score), comment=VALUES(comment)
```

该端点接受客户端提供的 conversation_id（第 2167 行）和访客令牌，校验了令牌（第 2172-2173 行）但丢弃了 visitor_id，随后仅按 id 获取会话（第 2174 行，WHERE 子句中不含 visitor_id），并使用该会话自身的 tenant/agent/visitor id 写入评价（第 2183-2184 行）。`$tokenData['visitor_id']` 与 `$conversation['visitor_id']` 之间不存在任何归属比对。

### 步骤 2：确认令牌中携带 visitor_id 且任何人都可获取

**证据**：`public/api/widget/index.php:706-714, 719-736, 988-1030, 1061-1064`

```
generateVisitorToken: $payload = base64_encode(json_encode(['visitor_id' => $visitorId, 'site_id' => $siteId, 'exp' => time() + 31536000])); return $payload . '.' . hash_hmac('sha256', $payload, ChatCollaborationService::visitorTokenSecret());
```

签名令牌的载荷中包含 visitor_id 与 site_id；verifyVisitorToken 返回该解码后的数组。/init 端点（公开、无需认证）会向任何访客签发这样的令牌（第 1062 行）。因此，该端点本应据以比对的已认证身份，正存在于 `$tokenData['visitor_id']` 中——只是在 /rating 中从未被使用。

### 步骤 3：与其他按访客限定范围的同类 widget 端点对比

**证据**：`public/api/widget/index.php:1132, 1216, 1248, 1309, 1399, 1620, 1805`

```
SELECT ... FROM cc_conversations WHERE id = :id AND visitor_id = :visitor_id LIMIT 1
```

其他所有以会话为作用域的 widget 端点都在 SQL 本身中强制校验访客归属（例如第 1132 行 messages、1216 行 status、1248 行 typing、1309 行 human-handoff、1620 行 upload）。/rating 是唯一的例外，这表明缺失的校验是疏漏，而非有意的设计。

### 步骤 4：确认 ID 可被枚举且评价可被覆盖

**证据**：`database/schema.sql:262-283 and database/050_canned_offline_tag_rating_recall.sql:48-60`

```
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY  ...  UNIQUE KEY uk_conversation (conversation_id)
```

cc_conversations.id 是顺序自增整数，因此 conversation ID 在所有租户范围内都可被轻易枚举。cc_ratings 在 conversation_id 上设有 UNIQUE KEY，因此 ON DUPLICATE KEY UPDATE 子句使攻击者能够覆盖既有的评价/评论，而不仅仅是插入。

### 步骤 5：确认完整性影响会波及受害租户

**证据**：`public/api/merchant/index.php:4085-4091`

```
$where = 'tenant_id=:tid'; ... SELECT AVG(score) FROM cc_ratings WHERE $where ... SELECT score,COUNT(*) AS cnt FROM cc_ratings WHERE $where GROUP BY score
```

商户的评价统计数据按 tenant_id/agent_id 从 cc_ratings 聚合而来，因此被注入/覆盖的记录会破坏另一租户的满意度指标——构成具体的跨租户完整性影响。

### 步骤 6：检查是否存在全局授权中间件

**证据**：`public/api/widget/index.php:897-901, 2164`

```
$path = routePath(); $method = strtoupper(...); $clientIp = getClientIp(); try { $pdo = Database::connection(); if ($path === '/media' ...) { ... }
```

分发逻辑是基于 `$path` 的扁平 if 链；没有任何包裹处理逻辑的认证/授权中间件。每个端点各自执行自己的令牌校验。因此 /rating 仅依赖于（不完整的）处理逻辑内部判断。

### 分析过程

- Q1: 端点是否接受用户提供的资源标识符？ -> 是：conversation_id 从请求体读取并强制转换为 int（public/api/widget/index.php:2167）。
- Q2: 该资源按设计是否为公开可访问？ -> 否：私有客服会话上的评价/评论属于租户/访客私有数据（database/050_...sql:48-60）。
- Q3: 查询是否限定在已认证用户范围内？ -> 否：获取语句为 'SELECT ... FROM cc_conversations WHERE id=:id'，没有 visitor_id 约束（public/api/widget/index.php:2174），而同类端点确实按 visitor_id 限定（例如第 1132 行）。
- Q4: 获取之后是否有归属/授权校验？ -> 否：`$tokenData['visitor_id']` 从未与 `$conversation['visitor_id']` 比对；该行被直接使用（public/api/widget/index.php:2174-2186）。
- Q5: 是否存在资源级授权中间件/策略？ -> 否：路由器是扁平 if 链，没有任何中间件（public/api/widget/index.php:897-901, 2164）。
- Q6: 该代码是否为测试/演示/生成代码或不可达？ -> 否：它是可通过 ?route=/rating 访问的实时 HTTP 处理逻辑（public/api/widget/index.php:2164）。
- 结论 -> 真实漏洞（TP）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:2174 仅按客户端提供的 id 加载会话，没有 visitor_id 作用域限制。
- public/api/widget/index.php:2172-2173 校验令牌并取得 visitor_id，却从未用它来约束会话。
- public/api/widget/index.php:2183-2184 使用该会话自身的 tenant_id/agent_id/visitor_id 写入评价，将攻击者的评价归属到受害者的数据上。
- public/api/widget/index.php:1132（以及 1216/1248/1309/1399/1620/1805）证明预期模型是 'AND visitor_id = :visitor_id'，而 /rating 遗漏了这一点。
- database/schema.sql:263 使 conversation id 顺序可枚举；database/050_canned_offline_tag_rating_recall.sql:58 通过 UNIQUE KEY + ON DUPLICATE KEY UPDATE 实现了覆盖能力。

## 4. 验证思路与复现步骤

- **前置条件**：应用已安装（存在 storage/install.lock），widget API 可达，且攻击者持有由公开 /init 端点签发的任意有效 visitor_token（任何运行该 widget 的站点都会生成一个）。必须存在属于另一租户的受害者会话 id；由于 id 是顺序的，任何有效 id 都可用。

**复现步骤：**

1. 使用有效的 site_public_id 和空的 visitor_token 向 widget 的 /init 端点发送 POST 请求，获取有效访客令牌；记录 result.visitor_token（这是攻击者自己 visitor_id 对应的令牌）。
2. 选择一个属于其他租户的目标 conversation_id（顺序 id 使其极易被猜测或枚举）。
3. 使用攻击者的令牌和受害者的 conversation_id 向 widget API 路由 /rating 发送 POST 请求，设置 score 和 comment，例如请求体 {"visitor_token":"<attacker token>","conversation_id":<victim id>,"score":1,"comment":"injected"}。
4. 观察返回 200 响应 '感谢您的评价'（评价被接受），尽管该令牌的 visitor_id 并不拥有目标会话。
5. 以受害者租户身份调用商户 /ratings/stats 端点，观察被注入的评分/评论出现在其聚合统计中。

**测试样例：**

```
POST /api/widget/index.php?route=/rating HTTP/1.1\nContent-Type: application/json\n\n{"visitor_token":"<valid token for attacker's own visitor_id>","conversation_id":<victim conversation id>,"score":1,"comment":"idor-test"}
```

- **预期现象**：服务器返回 code 200 及 '感谢您的评价'，而不是 401/403/404，并且受害者会话的评价记录被创建或覆盖（可在数据库/按租户隔离的商户统计中看到）。若实现正确限定了作用域，则应因该 conversation_id 不属于令牌的 visitor_id 而返回 '会话不存在' 予以拒绝。

## 5. 修复建议

将会话查询限定到已认证访客范围内，与同类端点保持一致：把第 2174 行的查询替换为 "SELECT id,tenant_id,agent_id,visitor_id,status FROM cc_conversations WHERE id=:id AND visitor_id=:visitor_id"，并绑定 'visitor_id' => (int) $tokenData['visitor_id']。当没有返回任何行时以 404 拒绝，这样来自其他访客/租户的令牌就无法评价该会话。此外，在接受评价前还应要求会话处于允许评价的状态（例如 status in ('closed','resolved')），并考虑对 /rating 按访客进行限流。
