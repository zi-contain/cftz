## 1. 总结

- **漏洞类型**：information_disclosure (CWE-200)
- **标记位置**：app/Security/TenantAuth.php:461
- **漏洞描述**：TenantAuth::debugToken() 会以攻击者提供的 token payload 中的 uid 为键执行数据库查询，且不要求签名有效；其返回数组中包含用户是否存在、电话号码、显示名称、租户 id/名称/状态以及 auth_would_pass 标志。该数组由 public/api/merchant/index.php 中未认证的 POST /auth/debug 路由原样返回给客户端，而该路由注册在任何 requireMerchant() 认证调用之前。其结果是：攻击者可在未认证的情况下对商家电话号码与租户名称进行用户枚举，并泄露 PII（Oracle）。

## 2. 分析逻辑

### 步骤 1：阅读被标记的函数及其签名校验

**证据**：`app/Security/TenantAuth.php:488-489`

```
$expectedSig = hash_hmac('sha256', $payloadB64, self::tokenSecret());
$result['signature_valid'] = hash_equals($expectedSig, $signature);
```

该函数计算了签名是否有效，但仅将其保存为诊断字段——当 signature_valid 为 false 时并不会提前返回。无论签名是否有效，执行都会继续进入 payload 解码与数据库查询。

### 步骤 2：确认数据库查询以攻击者可控的 uid 为键并返回 PII

**证据**：`app/Security/TenantAuth.php:509-531`

```
if (!empty($payload['uid'])) {
    $stmt = ... 'WHERE u.id = :id LIMIT 1';
    $stmt->execute(['id' => (int) $payload['uid']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $result['user_found'] = (bool) $user;
    ...
    $result['user_phone'] = $user['phone'] ?? '';
    $result['tenant_name'] = $user['tenant_name'] ?? '';
    $result['auth_would_pass'] = $wouldPass;
```

uid 直接来自解码后的 token payload（由调用方提供的 base64 JSON）。该查询返回 user_phone（PII）、display_name、tenant_id、tenant_status、tenant_name、user_found 与 auth_would_pass——即用户是否存在 + PII + 认证结果。该 SELECT 使用绑定参数，因此不存在 SQL 注入，但所返回的数据正是信息泄露问题所在。

### 步骤 3：定位调用方与 HTTP 路由

**证据**：`public/api/merchant/index.php:975-983`

```
if ($path === '/auth/debug' && $method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $token = (string) ($input['token'] ?? '');
    ...
    $debug = \App\Security\TenantAuth::debugToken($token);
    $debug['client_type_header'] = $clientType;
    ...
    respond(200, 'ok', $debug);
}
```

token 直接取自 JSON 请求体，而 debugToken() 的完整结果通过 respond() 返回在 HTTP 响应体中。该路由没有认证、没有速率限制、也没有验证码。

### 步骤 4：验证该路由在认证之前即可访问

**证据**：`public/api/merchant/index.php:961-983`

```
$path = routePath();
$method = ...;
if ($path === '/auth/version' && $method === 'GET') { ... }
if ($path === '/auth/debug' && $method === 'POST') { ... }
```

/auth/debug 分支仅根据 path+method 进行分发，紧跟在 /auth/version 之后、主 try 块之前。对整个文件执行 grep 可以看到，requireMerchant() 仅在 1887、7990、8013、8047 与 8110 行被调用——这些位置都远在第 975 行之后。因此 /auth/debug 从未受认证约束。

### 步骤 5：检查是否存在更早的全局防护提供认证

**证据**：`public/api/merchant/index.php:4-96`

```
require dirname(__DIR__, 3) . '/app/Core/bootstrap.php';
\App\Security\LicenseGate::enforce();
...
\App\Security\DomainGuard::requirePlatformHost();
...
Session::start();
```

bootstrap.php（app/Core/bootstrap.php:36）仅调用 LicenseGate::enforce()；DomainGuard::requirePlatformHost() 仅依据 APP_URL 校验 Host 头（app/Security/DomainGuard.php:20-37）。二者都不对用户进行认证。第 975 行之前没有任何会话/登录检查。

### 步骤 6：确认所泄露字段为真实 PII，且该路由在生产环境可访问

**证据**：`database/schema.sql:94-107`

```
phone VARCHAR(32) NOT NULL,
...
display_name VARCHAR(80) NOT NULL,
...
UNIQUE KEY uk_tenant_user_phone (phone),
```

cc_tenant_users.phone 是一个唯一且真实的电话号码列——所泄露的值是可直接识别身份的 PII，且该唯一索引使其成为可靠的枚举目标。该路由仅在 storage/install.lock 存在时生效（index.php:957），即已安装的生产部署，而非仅供开发使用的路径。

### 分析过程

- Q1：敏感信息是否暴露给未授权用户/客户端？→ 是。debugToken() 返回 user_phone、tenant_name、user_found、auth_would_pass（app/Security/TenantAuth.php:520-531），而该数组由未认证路由 public/api/merchant/index.php:982 原样返回在 HTTP 响应中（respond(200,'ok',$debug)）。
- Q2：应用是否处于生产模式，且其错误处理能够遏制该暴露？→ 就本暴露而言：否。这不是错误页面，而是有意返回的结果对象。该路由没有认证，也没有任何自定义处理器对其进行抑制。（注：TenantAuth.php:533 处的 db_error 也可能泄露 SQL 错误文本，但主要暴露的是 PII 结果本身。）
- Q3：该暴露是否仅为服务器版本/技术信息？→ 否。它是 PII（商家电话号码、显示名称）以及用户是否存在与租户名称/状态——不仅仅是 banner/版本之类的琐碎信息。
- Q4：该代码是否为测试/演示/生成代码，或确实不可达？→ 否。它是一个由路由器在主 try 块之前分发的 HTTP 框架入口点（POST /auth/debug）；框架路由在设计上就是可达的，且仓库内没有调用方。该端点在已安装部署上处于启用状态（受 install.lock 门控）。
- Q5：无效签名是否会阻止数据库查询？→ 否。signature_valid 仅在 TenantAuth.php:489 作为诊断信息计算；无论其取值如何，执行都会继续到第 509-535 行以 uid 为键的查询。
- 结论：四个决策树分支均对照代码得到确认，因此结论为真实漏洞（TP：未认证信息泄露 / 用户枚举 + PII）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Security/TenantAuth.php:489 设置了 $result['signature_valid'] 但从不提前返回，因此无效/伪造的签名仍会进入数据库查询。
- app/Security/TenantAuth.php:518 以 'id' => (int) $payload['uid'] 执行查询，其中 uid 在第 492-496 行由调用方提供的 token 解码而来。
- app/Security/TenantAuth.php:522-531 将 user_phone、tenant_id、tenant_status、tenant_name、user_found 与 auth_would_pass 放入返回的数组中。
- public/api/merchant/index.php:979-982 将攻击者提供的 token 传给 debugToken()，并通过 respond(200,'ok',$debug) 将整个结果返回给客户端。
- public/api/merchant/index.php:975 在主 try 块之前声明了 /auth/debug 路由，且它未被 requireMerchant() 包裹（后者仅在 1887/7990/8013/8047/8110 行被调用）。
- database/schema.sql:94,107 显示 cc_tenant_users.phone 是一个 NOT NULL 唯一列，确认所泄露的值是可识别身份的 PII，且可被枚举。

## 4. 验证思路与复现步骤

- **前置条件**：部署已安装（存在 storage/install.lock），因此商家 API 处于启用状态。/auth/debug 路由不需要任何认证 cookie、会话或 token。请求 Host 必须与所配置的平台 APP_URL 匹配（DomainGuard），且在没有重写时，路由前缀为 /api/merchant。

**复现步骤：**

1. 构造一个 token，其 payload 段为 {"uid":1} 的 base64url 编码，签名段为任意非空字符串（例如 'x'）；在查询之前签名从不会被验证。
2. 发送 POST /api/merchant/auth/debug，JSON 请求体为 {"token":"<payloadB64>.<fakeSignature>"}。
3. 读取 JSON 响应中的 'result' 对象。
4. 以 uid 值 1..N 逐次递增重复请求，以枚举账号。

**测试样例：**

```
POST /api/merchant/auth/debug HTTP/1.1
Host: <platform-host>
Content-Type: application/json

{"token":"eyJ1aWQiOjF9.x"}   // base64url of {"uid":1} + arbitrary signature
```

- **预期现象**：响应为 HTTP 200、code 200，且 result 中包含 user_found:true、signature_valid:false，以及 uid 为 1 的 user_phone、tenant_name、tenant_id、tenant_status 与 auth_would_pass。遍历 uid 会返回其他账号的电话号码与租户名称，而不存在的 uid 会返回 user_found:false——二者共同构成确凿的用户枚举与 PII 泄露（Oracle）。一个正确加固的端点应拒绝伪造签名（例如 user_found 缺失 / 为 null），而不是填充这些字段。

## 5. 修复建议

在生产环境部署前，从 public/api/merchant/index.php 中移除 /auth/debug 路由，或将其置于 requireMerchant() 加超级管理员角色检查之后。不要将 debug 数组返回给客户端——如果需要诊断信息，请将其保留在服务端（仅写入 error_log，正如 index.php:213-218 处现有 requireMerchant() 调用所做的那样）。独立加固 TenantAuth::debugToken()：当 signature_valid 为 false 时立即返回（在解码 payload / 任何数据库访问之前），并且绝不在任何对外输出中包含 user_phone、display_name、tenant_name、user_found 或 auth_would_pass。同时避免回显原始异常文本（TenantAuth.php:533 处的 db_error），并且如果保留任何此类端点，请添加速率限制。
