## 1. 总结

- **漏洞类型**: weak_password_requirements (CWE-521)
- **标记位置**: app/Security/Password.php:29
- **漏洞描述**: Password::strong() 返回 `$password !== ''`，因此它只强制非空，并接受“1”或“a”这类密码。该谓词是以下路径上唯一的密码复杂度门禁：公开商户注册端点（public/api/merchant/index.php:1233）、商户代理创建（public/api/merchant/index.php:2513）以及安装后的平台超级管理员账户（app/Core/Installer.php:1158）。代码库其他地方也体现了预期的最低要求（public/api/merchant/index.php:5461 处的密码修改强制要求 >=6 个字符），这表明该谓词并不充分，并非有意设计的全局标准。扫描器关于“离线攻击可立即完成”的说法言过其实，因为哈希采用 Argon2id/bcrypt；但弱策略缺陷（CWE-521）确为真实漏洞，且可影响公开、未经认证的注册路径。

## 2. 分析逻辑

### 步骤 1: 阅读密码策略基础实现

**证据**: `app/Security/Password.php:27`

```
public static function strong(string $password): bool
{
    return $password !== '';
}
```

整个密码强度策略只是一个非空检查：既不检查长度、字符类别，也不检查常见密码或泄露密码。其上方中文注释（第 19-26 行）说明，10 字符以及字母+数字要求已被有意移除，仅保留非空作为底线。Password::hash()（第 8-12 行）使用 PASSWORD_ARGON2ID 或 PASSWORD_BCRYPT，因此存储的哈希属于慢哈希——扫描器“离线攻击可立即完成”的措辞并不准确，但该策略弱点仍构成真实漏洞。

### 步骤 2: 阅读公开商户注册调用点

**证据**: `public/api/merchant/index.php:1233`

```
if ($password !== $confirmation) {
    respond(-1, '两次输入的密码不一致');
}
if (!Password::strong($password)) {
    respond(-1, '请填写登录密码');
}
```

/register 处理器（POST，起始于第 1180 行）在第 1201 行通过 input() 读取 $password，且除 Password::strong() 外未应用任何长度或复杂度检查。之前的检查仅验证两次输入是否一致，因此密码“1”也能通过。下游第 1472 行通过 Password::hash() 对其哈希并存储。该端点是公开的；防护措施包括 CAPTCHA（第 1182 行）、8 秒提交节流（第 1192 行）以及可选的短信/QQ 邮箱验证——这些都不会限制密码值本身。

### 步骤 3: 阅读代理创建与安装器调用点

**证据**: `public/api/merchant/index.php:2513`

```
if (!Password::strong($password)) {
    respond(-1, '请填写客服密码');
}
```

/agents/create 处理器（第 2476 行）对 agent_password（在第 2486 行读取）应用 Password::strong()，没有其他强度规则，然后在第 2537 行对其进行哈希。此外，app/Core/Installer.php:1158 在安装过程中对平台超级管理员密码应用同一个谓词：`if (!Password::strong($data['admin_password']))`（admin_password 在第 1130 行读取），并在第 1817 行存储。安装器仅可在安装前访问（一旦存在 storage/install.lock，public/install.php:52 就会阻止访问），并且受令牌/许可证门禁限制，但它仍然允许单字符的超级管理员密码。

### 步骤 4: 检查补偿性控制与内部不一致

**证据**: `public/api/merchant/index.php:5461`

```
if (mb_strlen($newPassword) < 6) {
    respond(-1, '新密码长度不能少于6位');
}
```

密码修改端点（/profile/password，第 5449 行）确实强制要求至少 6 个字符，并且登录通过 app/Security/RateLimiter.php:37 在 app/Security/PlatformAuth.php:31 和 app/Security/TenantAuth.php:109 中限制为每 (IP|凭据) 8 次尝试 / 900 秒。这些控制措施确实存在，但并未修复策略缺口：创建/注册路径会接受修改路径所拒绝的简单密码，且 8/900 秒仍允许在数小时内枚举单字符密码。这种不一致表明该弱谓词属于缺陷，而非一致的全局策略。

### 分析过程

- Q1: 代码是否强制实施密码复杂度/长度要求？-> 否。Password::strong() 为 `return $password !== ''`（app/Security/Password.php:29）；不存在长度、字符类别或泄露检查。
- Q2: 该弱策略是否位于可到达的、不受信任的路径上？-> 是。该谓词约束公开的商户注册（public/api/merchant/index.php:1233）和商户代理创建（public/api/merchant/index.php:2513）；安装器超级管理员路径（app/Core/Installer.php:1158）也使用它。
- Q3: 是否存在可抵消它的补偿性控制？-> 仅部分存在。CAPTCHA、8 秒提交节流、可选短信/邮箱验证以及 8/900 秒登录速率限制器确实存在，但都不会限制密码值；单字符密码仍会被接受并可被猜测（RateLimiter.php:37）。
- Q4: 代码库其他位置是否将短密码视为不可接受？-> 是。密码修改处理器拒绝 <6 个字符（public/api/merchant/index.php:5461），证实创建时的谓词不充分，而非有意为之的统一标准。
- Q5: 扫描器的影响声明是否准确？-> 部分准确。哈希使用 Argon2id/bcrypt（Password.php:10），因此“离线攻击可立即完成”言过其实；CWE-521 弱策略缺陷本身确为真实漏洞。

## 3. 结论

**真实漏洞 (TP)**

**关键证据：**

- app/Security/Password.php:29 - `return $password !== '';` 就是整个强度策略；任何非空字符串都会被视为“强”。
- public/api/merchant/index.php:1233 - 公开的 /register 在密码于第 1472 行被哈希前，仅对其应用 Password::strong()。
- public/api/merchant/index.php:2513 - /agents/create 在第 2537 行哈希前仅应用 Password::strong()。
- app/Core/Installer.php:1158 - 平台超级管理员密码在存储于第 1817 行前，由同一个仅检查非空的谓词验证。
- public/api/merchant/index.php:5461 - 密码修改路径强制要求 >=6 个字符，表明创建路径遗漏了预期的最低要求。

## 4. 验证思路与复现步骤

- **前置条件**: 商户注册处于开放状态（SecuritySettings::registerReviewMode() != 'closed'）且 CAPTCHA 可解；其他字段以及启用时的短信/邮箱验证均已满足。或者，已认证的商户所有者/管理员调用 /agents/create。

**复现步骤：**

1. 向商户注册端点 /register（public/api/merchant/index.php:1180）发送 POST 请求，提供有效的 tenant_name、tenant_slug、owner_name、phone、qq_number、agreed=true 并通过 CAPTCHA，但将 password=1、password_confirmation=1。
2. 完成配置所要求的任何短信/邮箱验证步骤。
3. 观察响应返回成功且账户被创建（第 1472 行存储 Password::hash('1')）。
4. 使用密码 '1' 对创建的凭据尝试正常登录；登录成功。

**测试样例：**

```
POST /api/merchant/register with body: tenant_name=Test&tenant_slug=testshop01&owner_name=Test&phone=13800000000&qq_number=123456&agreed=true&password=1&password_confirmation=1 (plus captcha/sms/email_code as configured)
```

- **预期现象**: 服务器响应成功并创建账户，随后使用单字符密码 '1' 即可登录成功。合规的密码策略应以“密码过弱”错误拒绝该请求。

## 5. 修复建议

在 App\Security\Password::strong() 中强制执行实际的密码策略（或将其替换为在每个调用点调用的显式策略检查）：要求最小长度（例如 >= 10）并拒绝最常见/已泄露的密码，然后将同一检查应用于注册（public/api/merchant/index.php:1233）、代理创建（public/api/merchant/index.php:2513）以及安装器超级管理员密码（app/Core/Installer.php:1158）。保留现有的非空检查作为额外防护，并使最低要求与密码修改处理器已使用的 >=6 规则保持一致（public/api/merchant/index.php:5461），以免创建路径比修改路径更弱。
