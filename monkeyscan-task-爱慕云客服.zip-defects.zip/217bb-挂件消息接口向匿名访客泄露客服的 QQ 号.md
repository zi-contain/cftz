## 1. 总结

- **漏洞类型**: information_disclosure (CWE-200)
- **标记位置**: public/api/widget/index.php:1158
- **漏洞描述**: widget 的 /messages 端点会针对每条客服消息返回 sender_avatar；当 avatar_url 未设置时，该字段由 cc_tenant_users.qq_number 构建（COALESCE(NULLIF(u.avatar_url,''), CONCAT('https://q.qlogo.cn/headimg_dl?dst_uin=', u.qq_number, ...))）。任何匿名访客只要获取 visitor token，该字段就会原样出现在返回给该访客的 JSON 响应中；而在整个响应处理过程中使用的 maskPhoneInArray 仅会遮蔽 11 位连续数字的电话号码模式，因此 5 到 10 位的 QQ 号会未脱敏地通过。平台本身将 qq_number 视为不可更改的账号唯一标识，因此将其泄露给匿名第三方属于内部员工标识的意外暴露。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的 SELECT 及 sender_avatar 表达式

**证据**: `public/api/widget/index.php:1157-1159`

```
CASE WHEN m.sender_type = :agent_avatar_type THEN
    COALESCE(NULLIF(u.avatar_url, \'\'), CONCAT(\'https://q.qlogo.cn/headimg_dl?dst_uin=\', u.qq_number, \'&spec=640&img_type=jpg\'))
    ELSE NULL END AS sender_avatar
```

当客服消息（sender_type='agent'）对应的 u.avatar_url 为空时，该 SELECT 会基于 u.qq_number 生成头像 URL（来自第 1161-1162 行的 LEFT JOIN cc_tenant_users u）。这样，原始 QQ 号就会进入 sender_avatar。接下来需确认：该值是否会返回给客户端，以及是否应用了脱敏。

### 步骤 2: 确认该值会在 HTTP JSON 响应中返回

**证据**: `public/api/widget/index.php:1208 and 1221-1223`

```
$messages = maskPhoneInArray($messages);
...
respond(200, 'ok', [
    'messages' => $messages,
```

获取到的 messages（含 sender_avatar）会传入 maskPhoneInArray，随后由 respond() 作为 'messages' 数组返回。respond()（第 44-48 行）直接向客户端输出 json_encode(['code'=>..., 'result'=>$result])，因此 sender_avatar 会到达访客浏览器。接下来检查 maskPhoneInArray 实际遮蔽了哪些内容。

### 步骤 3: 检查脱敏函数——QQ 号未被覆盖

**证据**: `public/api/widget/index.php:100-118`

```
function maskPhoneNumber(string $text): string {
    return preg_replace('/(\d{3})\d{4}(\d{4})/', '$1****$2', $text);
}
function maskPhoneInArray(array $data): array { /* recurses, applies maskPhoneNumber to every string */ }
```

maskPhoneNumber 仅会遮蔽 11 位连续数字（3+4+4）。QQ 号为 5-15 位（在 merchant/index.php:2501 和 :5374 中通过 /^[1-9][0-9]{4,14}$/ 校验），因此以 dst_uin=<qq> 形式嵌入的 5-10 位 QQ 号完全不会被遮蔽；即使是 11 位 QQ 号也只会被部分遮蔽。该发现中“maskPhoneInArray 仅遮蔽类电话号码字符串”的说法得到确认。

### 步骤 4: 验证匿名访客是否可达

**证据**: `public/api/widget/index.php:988-1030, 1105-1138, 1119-1138`

```
if ($path === '/init' && $method === 'POST') { ... respond(200, 'ok', [ 'visitor_token' => $token, ... 'conversation_id' => (int) $conversation['id'], ...]); }
```

/init 无需认证（仅要求 26 字符的 site_public_id），会签发 visitor_token 与 conversation_id。/messages（第 1105 行）同样无需登录——只要求有效的 visitor_token，且其 conversation 属于调用者（第 1119-1138 行）。因此，任何开始聊天的匿名访客都能读取客服消息并获取 sender_avatar。访客无需拥有账号。

### 步骤 5: 确认 qq_number 是账号唯一内部标识，且空头像分支可达

**证据**: `public/api/merchant/index.php:5364 and 5400, 2501-2506`

```
if ($qqNumber !== $currentQqNumber) {
    respond(-1, 'QQ号是账号唯一标识，不能直接修改或解绑；如需处理请完成账号安全验证后联系管理员');
}
...
'qq_number' => $qqNumber !== '' ? $qqNumber : null,
'avatar_url' => $avatarUrl !== '' ? $avatarUrl : null,
```

商户代码明确将 qq_number 称为“账号唯一标识”，并禁止在未完成安全验证的情况下修改/解绑，确认其被视为敏感的内部标识。同一处理函数允许将 avatar_url 置空（第 5400 行）而保留 qq_number，因此 widget 中的 COALESCE 回退分支可达。客服创建时也要求绑定 QQ（2501），并存储由 QQ 派生的 avatar_url（2505），因此无论使用存储的 avatar_url 还是 CONCAT 回退，QQ 号都会暴露在 sender_avatar 中。qq_number 还会被用作邮箱前缀（merchant/index.php:1060 'qq_number@qq.com'），即 PII。

### 分析过程

- Q1: 是否将敏感信息暴露给未授权客户端？ -> 是。包含客服 qq_number 的 sender_avatar 会在 /messages 的 JSON 响应中返回（index.php:1158 在第 :1221-1223 行输出），任何匿名访客只要持有易于获取的 visitor token 均可读取（步骤 4）。
- Q2: 应用是否处于生产模式，并有适当处理可消除该问题？ -> 不适用/否。这是正常成功路径的响应数据，并非调试产物，且没有任何脱敏机制覆盖它：maskPhoneInArray（index.php:100-118）仅遮蔽 11 位电话号码串，5-10 位 QQ 号会保持原样（步骤 3）。
- Q3: 暴露的是否仅为服务器版本/技术信息？ -> 否。被泄露的值是客服账号唯一的 QQ 标识/QQ 邮箱前缀（merchant/index.php:5364, :1060）。
- Q4: 代码是否为测试/演示/不可达？ -> 否。它是匿名访客可触达的线上公开 widget API（步骤 4）。
- 结论：真实漏洞（TP，低危，CWE-200）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:1158 在 u.avatar_url 为空时根据 u.qq_number 构建 sender_avatar，将员工原始 QQ 号嵌入 URL。
- public/api/widget/index.php:1221-1223 通过 respond() 将已脱敏、但仍可识别身份的 $messages 数组（含 sender_avatar）返回给调用方。
- public/api/widget/index.php:100-118 — maskPhoneNumber 仅匹配 11 位连续数字的电话号码模式，因此普通的 5-10 位 QQ 号永远不会被遮蔽。
- public/api/widget/index.php:988-1030 — /init 无需认证即可签发 visitor_token 和 conversation_id，因此任何匿名访客均可触达 /messages 的暴露。
- public/api/merchant/index.php:5364 将 qq_number 标为“账号唯一标识”，并禁止修改/解绑，确立其为敏感内部标识；:5400 允许清空 avatar_url 而保留 qq_number，使回退分支可达。

## 4. 验证思路与复现步骤

- **前置条件**：目标站点至少有一个客服（cc_tenant_users），其角色为 'agent'，且没有自定义 avatar_url（要么从未上传——客服创建时会存储一个由 QQ 派生的 avatar_url，见 merchant/index.php:2505，其中的 dst_uin 也会泄露 QQ——要么已通过 /profile 保存清空，见 merchant/index.php:5400）。该客服已回复过某个访客会话。攻击者不需要账号，只需具备访问 widget API 的网络权限。

**复现步骤：**

1. 向 /api/widget/index.php?route=/init 发送 POST 请求，JSON 请求体为 {"site_public_id":"<26-char site id>"}，以获取 visitor_token 和 conversation_id（无需认证）。
2. 向 /api/widget/index.php?route=/send 发送 POST 请求，携带 visitor_token、conversation_id、body 和 type="text"，以打开/继续对话。
3. 让客服从商户控制台回复（或等待已有的客服消息），使该会话在 cc_messages 中存在一条由客服编写的记录。
4. 使用请求头 X-Visitor-Token: <visitor_token>，向 /api/widget/index.php?route=/messages&conversation_id=<id>&after_id=0 发送 GET 请求，并检查每个 sender_type 为 'agent' 的 messages[] 条目。
5. 读取 messages[].sender_avatar，提取 dst_uin 查询参数的值。

**测试样例：**

```
GET /api/widget/index.php?route=/messages&conversation_id=<conversation_id>&after_id=0 HTTP/1.1
Host: <target>
X-Visitor-Token: <visitor_token>
```

- **预期现象**：JSON 中的 messages[].sender_avatar 会包含类似 'https://q.qlogo.cn/headimg_dl?dst_uin=123456789&spec=640&img_type=jpg' 的 qlogo.cn URL，其中 dst_uin 为客服完整的、未脱敏的 QQ 号（5-10 位数字会原样返回，而不会被替换为 '****'）。修复后，响应应省略原始 QQ（返回代理/默认头像或脱敏标识），使 dst_uin 不存在或已被遮蔽。

## 5. 修复建议

停止在公开端点上使用原始 QQ 号派生客服头像。具体而言：(1) 在 /messages 的 SELECT（public/api/widget/index.php:1157-1159）中，不要将 qq_number CONCAT 到响应中——而应仅返回 u.avatar_url，当其为空时返回平台默认/匿名头像或同源代理图片 URL；这同样适用于客服创建时存储的由 QQ 派生的 avatar_url（public/api/merchant/index.php:2505），应将其替换为不可识别身份的默认头像或代理 URL。(2) 如果 QQ 号必须在服务器端保持可检索，则在服务器端获取 qlogo 图片，并通过同源的 /media 风格端点提供服务，从而使发送到浏览器的数据中绝不出现 dst_uin。(3) 不要依赖 maskPhoneInArray 处理此问题：它仅覆盖 11 位电话号码（public/api/widget/index.php:100-118）。由于 qq_number 被视为账号唯一标识（public/api/merchant/index.php:5364），并映射到 QQ 邮箱地址（public/api/merchant/index.php:1060），因此不应以任何形式将其暴露给匿名访客。
