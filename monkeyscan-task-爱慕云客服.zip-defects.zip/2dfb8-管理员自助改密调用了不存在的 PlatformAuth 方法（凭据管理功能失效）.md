## 1. 总结

- **漏洞类型**: broken_functionality (CWE-754)
- **标记位置**: public/api/admin/index.php:861
- **漏洞描述**: 已认证的 /profile POST 处理器通过调用 PlatformAuth::verifyPassword()（第 861 行）与 PlatformAuth::updatePassword()（第 864 行）执行自助式密码修改。PlatformAuth 是 final 类，没有父类、没有 trait，也没有 __callStatic，仅定义了 user()、check()、attempt()、logout() 与 isSuperAdmin()。调用未定义的静态方法会抛出致命的 PHP Error（属于 Throwable），而第 3918 行的顶层 catch 会将其转换为通用 HTTP 500，因此密码分支永远不会执行。此外，同一处理器还会将个人资料字段写入 cc_platform_admins（第 868 行），但该表在 schema 中根本不存在（用于认证的记录位于 cc_platform_users），因此对于已登录的管理员而言，整个 /profile POST 接口都不可用。

## 2. 分析逻辑

### 步骤 1: 确认 PlatformAuth 实际定义了哪些方法

**证据**: `app/Security/PlatformAuth.php:9-74`

```
final class PlatformAuth { ... public static function user() / check() / attempt() / logout() / isSuperAdmin() ... }
```

该类声明为 `final class PlatformAuth`，没有 `extends`，也没有 `use` trait（仅有命名空间导入）。其公开接口恰好只有 user()、check()、attempt()、logout()、isSuperAdmin()。不存在 verifyPassword()，不存在 updatePassword()，也没有 __callStatic 兜底。因此，这两个被标记的方法均未定义。

### 步骤 2: 阅读被标记的 /profile POST 处理器

**证据**: `public/api/admin/index.php:831-874`

```
if (!PlatformAuth::verifyPassword($adminId, $oldPassword)) { respond(-1, '原密码错误'); }
PlatformAuth::updatePassword($adminId, $newPassword);
```

在密码修改分支（第 855-865 行）中，处理器调用了这两个不存在的静态方法。只要同时提供 old_password 与 new_password，就会进入该分支，因此对任何凭据轮换尝试而言，该调用都位于正常执行路径上。

### 步骤 3: 全仓库搜索方法定义及任何魔术解析

**证据**: `public/api/admin/index.php:861,864 (仅有的调用点)`

```
grep -rn 'verifyPassword|updatePassword' -> 仅匹配 public/api/admin/index.php:861 与 :864（外加扫描器自身的暂存文件）
```

仓库中任何位置都不存在这两个方法的定义，也不存在 `class PlatformAuth`、`__callStatic`、trait 或抽象类的替代实现。这些调用无法解析；在 PHP 中，未定义的静态调用会抛出 Error: Call to undefined method App\Security\PlatformAuth::verifyPassword()。

### 步骤 4: 确认该 Error 被吞掉并转为通用 500

**证据**: `public/api/admin/index.php:3918-3928`

```
} catch (Throwable $exception) { error_log('[admin-api] ' . get_class($exception) ...); respond(-1, Env::bool('APP_DEBUG') ? '请求处理失败：'.$exception->getMessage() : '请求处理失败，请查看服务器错误日志', null, 500); }
```

主分发逻辑包裹在 `try {`（第 261 行）中。PHP 的 Error 实现了 Throwable，因此未定义方法产生的 Error 会在此处被捕获，并转换为 code -1 / HTTP 500 以及一条通用消息。密码修改从未被应用，请求在个人资料 UPDATE 之前即中止，与扫描器的说法完全一致。

### 步骤 5: 检查可达性以及该功能是否确实暴露

**证据**: `public/api/admin/index.php:386,831 ; public/admin-app/assets/profile-ufapUtQ_.js`

```
$user = requireAdmin();  ... if ($path === '/profile' && $method === 'POST') { ... }
```

第 386 行的 requireAdmin() 对后续所有逻辑进行门控（会话检查 + 对 $_SESSION['admin_api_token'] 与 HTTP TOKEN 头执行 hash_equals），因此任何已认证的平台管理员都可访问 /profile POST。管理端前端打包文件会渲染 old_password / new_password / new_password_confirmation 字段（标签为 '原密码'/'新密码'）并引用 '/profile'，因此密码修改是一项真实且面向用户暴露的功能，但端到端已损坏。路由前缀为 /api/admin（第 204 行），即 POST /api/admin/profile。

### 步骤 6: 核实存在分歧的 UPDATE 目标表

**证据**: `public/api/admin/index.php:868 ; app/Security/PlatformAuth.php:36-37 ; database/schema.sql:6-22`

```
$sql = 'UPDATE cc_platform_admins SET ' . implode(', ', $updates) . ' WHERE id = :id';
// auth: 'SELECT ... FROM cc_platform_users WHERE username = :username'
```

PlatformAuth::attempt() 依据 cc_platform_users 进行认证（这是 database/schema.sql:6 中定义的唯一平台管理员表，包含 password_hash）。对 `cc_platform_admins` 进行全仓库 grep 恰好只命中一处（index.php:868），且任何位置都没有 CREATE TABLE，因此个人资料 UPDATE 同样指向不存在的表。密码路径与个人资料更新路径均不可用，进一步印证了该发现。

### 分析过程

- Q1: 被标记的代码是否存在且可达？-> 是。public/api/admin/index.php:386 处的 requireAdmin() 对分发进行门控，/profile POST 在第 831 行被处理；管理端 UI 暴露了 old_password/new_password 字段。
- Q2: 所调用的 PlatformAuth::verifyPassword()/updatePassword() 是否确实定义？-> 否。app/Security/PlatformAuth.php:9-74 显示这是一个 final 类，无父类、无 trait、无 __callStatic，仅暴露 user/check/attempt/logout/isSuperAdmin；全仓库 grep 仅在这两个调用点（index.php:861,864）找到这些名称。
- Q3: 未定义的调用是否会以告警所声称的方式失败？-> 是。PHP 对未定义的静态调用会抛出 Error；index.php:3918 处的顶层 `catch (Throwable $exception)` 会捕获它并返回 code -1 与 HTTP 500，因此密码分支永远不会完成。
- Q4: 其影响是否与安全相关（凭据管理损坏），是否存在次要缺陷？-> 是。对于已认证的管理员而言，密码轮换不可达，且 index.php:868 处同级的个人资料 UPDATE 写入 cc_platform_admins，而该表在任何地方都未定义（认证使用 cc_platform_users，database/schema.sql:6）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Security/PlatformAuth.php:9 声明了 `final class PlatformAuth`（无父类、无 trait），且第 14-73 行仅定义了 user()、check()、attempt()、logout()、isSuperAdmin() —— verifyPassword() 与 updatePassword() 均不存在。
- public/api/admin/index.php:861 与 :864 调用了 PlatformAuth::verifyPassword()/updatePassword()；全仓库 grep 显示这是唯一出现的位置，因此这些调用是未定义的，会抛出致命 Error。
- public/api/admin/index.php:3918-3928 捕获 Throwable 并返回 code -1 / HTTP 500，确认未定义方法的 Error 会退化为通用服务器错误，密码分支永远不会生效。
- public/api/admin/index.php:386（`$user = requireAdmin();`）以及管理端 UI 打包文件（public/admin-app/assets/profile-ufapUtQ_.js）将损坏的密码修改路径暴露给已认证的管理员。
- public/api/admin/index.php:868 更新 cc_platform_admins，而 app/Security/PlatformAuth.php:36-37 与 database/schema.sql:6 表明账户实际位于 cc_platform_users；`cc_platform_admins` 在仓库中任何地方均未定义。

## 4. 验证思路与复现步骤

- **前置条件**: 在 cc_platform_users 中有一个可登录的平台管理员账户；通过 POST /api/admin/login 建立活动会话，该接口会设置 $_SESSION['platform_user'] 与 $_SESSION['admin_api_token']；请求必须携带匹配的 TOKEN 头。安装锁（storage/install.lock）必须存在，以确保 API 不会返回 503。

**复现步骤：**

1. 使用 POST /api/admin/login 进行认证，并捕获会话 cookie 与返回的管理员 token。
2. 发送 POST /api/admin/profile，请求头为 `TOKEN: <admin token>`，JSON 体包含有效的 `old_password` 和至少 6 个字符的 `new_password`。
3. 观察响应的 HTTP 状态与 JSON 体。
4. 通过使用新密码重新登录（或检查该账户的 cc_platform_users.password_hash）复核该账户的密码哈希。

**测试样例：**

```
POST /api/admin/profile
TOKEN: <valid admin session token>
Content-Type: application/json

{"old_password":"<current password>","new_password":"newpass123"}
```

- **预期现象**: 服务器返回 HTTP 500 和 JSON `{"code":-1,...}` 以及一条通用消息（除非 APP_DEBUG 开启，否则为 '请求处理失败，请查看服务器错误日志'），且服务器错误日志会记录 `[admin-api] Error: Call to undefined method App\Security\PlatformAuth::verifyPassword()`；密码保持不变，随后使用 `newpass123` 登录会失败。安全/易受攻击的差异：正常工作的实现会返回 `{"code":200,"message":"个人信息已更新"}`，且新密码会生效。

## 5. 修复建议

在 PlatformAuth 上针对正确的表实现缺失的凭据管理方法，例如 `public static function verifyPassword(int $id, string $plain): bool`，该方法从 cc_platform_users 中 WHERE id = :id 加载 `password_hash`，并委托给 Password::verify($plain, $hash)；以及 `public static function updatePassword(int $id, string $plain): void`，该方法将 `Password::hash($plain)` 写回 cc_platform_users 中该 id 对应的记录（app/Security/Password.php:8,14 已提供 hash/verify）。或者，修改 /profile POST 处理器，直接使用现有的 Password 辅助类。无论采用哪种方式，都需消除写入目标的分歧：public/api/admin/index.php:868 处的个人资料 UPDATE 指向 cc_platform_admins，而该表在任何地方都未创建（根据 database/schema.sql:6 与 app/Security/PlatformAuth.php:36-37，账户行位于 cc_platform_users），因此个人资料与密码写入都必须重定向到当前会话管理员 id 对应的 cc_platform_users。
