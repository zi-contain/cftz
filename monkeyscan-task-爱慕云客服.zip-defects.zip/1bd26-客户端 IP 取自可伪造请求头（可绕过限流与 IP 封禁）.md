## 1. 总结

- **漏洞类型**: trusting_untrusted_input (CWE-348)
- **标记位置**: public/api/widget/index.php:242
- **漏洞描述**: widget API 中的 getClientIp() 完全依据客户端提供的请求头（CF-Connecting-IP、X-Forwarded-For、X-Real-IP）来确定客户端 IP，从不检查直接对端（REMOTE_ADDR）是否为受信任代理。因此，任何客户端只要设置相应请求头，就能自称任意合法 IP。这个由攻击者选定的值是 IP 速率限制（checkIpRateLimit）与 IP 黑名单（checkVisitorBlocked）的唯一键，并会被原样持久化到 cc_visitors.ip_address 和 cc_offline_messages.ip。仓库中已提供一个正确实现（App\Security\ClientIp，由 TRUSTED_PROXIES 允许列表控制，并从右到左遍历 X-Forwarded-For），但 widget 端点并未使用它，可见此处确实存在实现偏差，而非有意接受的设计。

## 2. 分析逻辑

### 步骤 1: 读取被标记的 getClientIp() 实现

**证据**: `public/api/widget/index.php:242-263`

```
$headers = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR']; foreach ($headers as $header) { $value = (string)($_SERVER[$header] ?? ''); if ($value !== '') { $ips = explode(',', $value); $ip = trim($ips[0]); if (filter_var($ip, FILTER_VALIDATE_IP)) { return $ip; } } }
```

这三个 HTTP_* 条目都是原始请求头，完全由调用方控制；REMOTE_ADDR 是唯一由对端派生出的值，却排在最后检查，只要攻击者设置了任意一个请求头，它实际上就永远取不到。对于 X-Forwarded-For，代码取的是 $ips[0]，即最左侧、最不可信的一跳。代码也没有判断 REMOTE_ADDR 是否落在受信任代理范围内。这正是 CWE-348：用可信度较低的来源（请求头）取代了可信度较高的来源（REMOTE_ADDR）。

### 步骤 2: 确认代码库已提供的对端信任门控在此处缺失

**证据**: `app/Security/ClientIp.php:23-47,67-92`

```
public static function get(): string { $remote = (string)($_SERVER['REMOTE_ADDR'] ?? ''); if (!self::isTrustedProxy($remote)) { return self::normalize($remote); } $forwarded = ...; for ($i = count($chain) - 1; $i >= 0; $i--) { ... } } ... private static function isTrustedProxy(string $ip): bool { $configured = trim((string) Env::get('TRUSTED_PROXIES', '')); ... }
```

应用的规范实现 ClientIp 类只有在 REMOTE_ADDR 位于配置的 TRUSTED_PROXIES 允许列表（默认为 127.0.0.1/::1）中时，才会采用 X-Forwarded-For，并从最右侧的不可信跳开始遍历整条链。Grep 结果显示，widget 文件从未引用 ClientIp 或 TRUSTED_PROXIES，只引用了它自身的 getClientIp（位于第 242/371/390/899 行）。加固实现确实存在，且已被 admin/merchant/alerting 使用，但在此处被绕开。

### 步骤 3: 追踪该值到速率限制汇聚点

**证据**: `public/api/widget/index.php:899,989,268-289`

```
$clientIp = getClientIp(); ... if ($path === '/init' && $method === 'POST') { checkIpRateLimit($pdo, $clientIp); ... } ... "SELECT COUNT(*) FROM cc_audit_logs WHERE actor_type='visitor' AND INET6_NTOA(ip)=:ip AND created_at >= UTC_TIMESTAMP() - INTERVAL 1 SECOND" ... if ((int)$stmt->fetchColumn() > 3) respond(...,429);
```

速率限制计数器完全以客户端可控的 IP 作为键。只要每个请求轮换 CF-Connecting-IP/X-Forwarded-For 请求头，各请求就会落入各自的计数桶，>3 的阈值永远不会被触发。/init 和 /offline-message（第 2138 行）是唯一调用该控制的位置；而按访客计数的限制器是有意留空的空操作（checkMessageRateLimit，第 436-439 行），因此它是仅存的垃圾请求防护手段。

### 步骤 4: 追踪该值到 IP 黑名单汇聚点

**证据**: `public/api/widget/index.php:402-427,1127,1373,1576,1750`

```
function checkVisitorBlocked(PDO $pdo, int $visitorId, string $ip) { ... if (isset($columns['ip_address'])) { $stmt = $pdo->prepare('SELECT id, ... FROM cc_visitors WHERE ip_address = :ip AND status = :status LIMIT 1'); $stmt->execute(['ip' => $ip, 'status' => 'blocked']); ... } }
```

基于 IP 的封禁会使用同一个由攻击者选定的 $clientIp 查询 cc_visitors.ip_address。被封禁的行为者只要注册一个新的 anonymous_id（通过未认证的 /init），并发送一个未被封禁的请求头值，就能通过该检查。第 1127/1373/1576/1750 行的调用方传入的都是伪造的 $clientIp。

### 步骤 5: 追踪该值到持久化（数据投毒）

**证据**: `public/api/widget/index.php:573-575,601-605,2150-2157`

```
UPDATE cc_visitors SET last_seen_at = UTC_TIMESTAMP(), ip_address = :ip WHERE id = :id ... INSERT INTO cc_visitors (..., ip_address) VALUES (...); $insertParams['ip'] = $ip; ... INSERT INTO cc_offline_messages (site_id,tenant_id,name,contact,message,ip,user_agent) VALUES (...); 'ip' => $clientIp
```

伪造值会被写入 cc_visitors.ip_address（新访客时插入，回访访客时更新）；对于未认证的 /offline-message 端点，还会写入 cc_offline_messages.ip。这既污染了分析/滥用数据，又为前一步的黑名单查询提供了输入，因此伪造 IP 会被当作库中存储的权威依据。

### 步骤 6: 检查部署中的框架/基础设施缓解措施

**证据**: `deploy/nginx/aimu-customer-cloud.conf:206-211`

```
# CDN / 真实 IP: 1. 源站防火墙仅允许 CDN 官方回源 IP 和受控运维 IP。 2. set_real_ip_from 只能填写 CDN 官方 IP 段，禁止信任任意 X-Forwarded-For。
```

nginx 示例中并未包含 real_ip_header / set_real_ip_from 指令；那几行只是注释，说明运维人员「应该」在防火墙/主机层做什么。仓库内和代码中都没有任何剥离或校验这些请求头的控制，因此代码对它们的信任是无条件的。即便处在 CDN 之后，X-Forwarded-For/X-Real-IP 回退取的仍是最左侧值，也就是攻击者可控的值。

### 分析过程

- Q1: 被标记的值是否由攻击者控制？ -> 是：getClientIp() 直接从 $_SERVER 读取 HTTP_CF_CONNECTING_IP / HTTP_X_FORWARDED_FOR / HTTP_X_REAL_IP，没有任何对端检查（public/api/widget/index.php:245-258，步骤 1）。
- Q2: 代码是否强制执行了信任边界？ -> 否：widget 从不校验 REMOTE_ADDR 是否可信，也不检查 TRUSTED_PROXIES；它绕开了应用其余部分使用的加固版 App\Security\ClientIp（步骤 2、6）。
- Q3: 该值是否到达安全相关汇聚点？ -> 是：速率限制键（989/1106/2138）、IP 黑名单键（1127/1373/1576/1750），以及持久化列 cc_visitors.ip_address 和 cc_offline_messages.ip（573-575、601-605、2150-2157）（步骤 3-5）。
- Q4: 实际路径上是否有防护？ -> 否：filter_var() 只能保证该值在语法上是合法 IP，而这恰恰是攻击者需要的；在值被使用之前，没有任何代理允许列表被应用（步骤 1、3）。
- Q5: 此仓库中是否有基础设施控制可以消除它？ -> 没有：唯一可称防护的只是示例 nginx 配置里的注释建议，并未实际配置 set_real_ip_from/real_ip_header（步骤 6）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/widget/index.php:245-250 将 HTTP_CF_CONNECTING_IP、HTTP_X_FORWARDED_FOR 和 HTTP_X_REAL_IP 列在 REMOTE_ADDR 之前，因此客户端请求头总是被优先采用。
- public/api/widget/index.php:255-256 取 $ips[0]，即 X-Forwarded-For 最左侧（可伪造）的一跳，与应用自身的从右到左逻辑相反。
- app/Security/ClientIp.php:27-44 实现了正确的受信任代理 + 最右侧不可信算法，证明 widget 的遗漏属于缺陷，而不是设计选择。
- public/api/widget/index.php:989 和 :2138 将 /init 与 /offline-message 的垃圾请求控制完全建立在可伪造 IP 上，而 checkMessageRateLimit() 在第 436-439 行是一个空的 no-op。
- public/api/widget/index.php:416-425 通过 cc_visitors.ip_address = :ip 进行封禁，且第 573-575/601-605 行用可伪造的值写入该列，使得轮换请求头即可绕过 IP 封禁。
- public/api/widget/index.php:2150-2156 从未认证的 /offline-message 端点将可伪造 IP 持久化到 cc_offline_messages.ip。

## 4. 验证思路与复现步骤

- **前置条件**：widget API 可通过 /api/widget/* 访问。对于速率限制和持久化路径（/init 和 /offline-message 属于预认证接口），攻击者不需要有效的访客令牌。源站必须能够以下述方式访问：客户端提供的转发请求头可以原样到达 PHP（直接访问，或经由任何不会覆盖这些请求头的代理），也就是说，主机/防火墙层面没有实施真实 IP 强制，而此仓库并未配置此类措施。

**复现步骤：**

1. 连续发送多个 POST /api/widget/index.php?route=/init 请求，每个请求在 CF-Connecting-IP（或 X-Forwarded-For / X-Real-IP）请求头中使用不同的合法 IP，例如 203.0.113.1、203.0.113.2、...
2. 观察可见，即使发送频率远超每秒 3 次的阈值，所有请求也都不会收到 HTTP 429 响应，因为每个伪造 IP 都会形成自己的速率限制桶。
3. 封禁一个访客（或一个 IP），使 cc_visitors.ip_address 保存一个被封禁的 IP；然后重复发送提供未封禁请求头值的请求，确认不会返回黑名单 403。
4. 使用选定的 CF-Connecting-IP 提交 POST /api/widget/index.php?route=/offline-message，然后检查新增的 cc_offline_messages 行——存储的 ip 等于请求头值，而不是真实来源地址。
5. 使用攻击者选择的 CF-Connecting-IP 和新的 anonymous_id 调用 POST /api/widget/index.php?route=/init，然后读取所创建行的 cc_visitors.ip_address，以确认伪造值已被持久化。

**测试样例：**

```
curl -s -X POST 'https://<target>/api/widget/index.php?route=/offline-message' -H 'Content-Type: application/json' -H 'CF-Connecting-IP: 198.51.100.77' --data '{"site_public_id":"<26-char-public-id>","contact":"a@b.c","message":"hi"}'
```

- **预期现象**：插入到 cc_offline_messages 的行中 ip = 198.51.100.77（请求头值），而不是实际源地址；并且使用轮换的 CF-Connecting-IP 重复请求，永远不会触发 checkIpRateLimit 返回 HTTP 429——表明用于限制、封禁和持久化的值均由客户端掌控。

## 5. 修复建议

将 widget 的 getClientIp() 函数体替换为应用的加固解析器（App\Security\ClientIp::get()，位于 app/Security/ClientIp.php）：当 REMOTE_ADDR 不在 TRUSTED_PROXIES 允许列表中时，直接返回 REMOTE_ADDR；只有满足该条件，才从最右侧的不可信跳开始遍历 X-Forwarded-For。使用 CDN/代理回源范围配置 TRUSTED_PROXIES（.env），并辅以主机级强制措施（源站防火墙仅接受来自这些范围的连接，nginx 的 real_ip_header/set_real_ip_from 也限制为相同范围），使客户端提供的 CF-Connecting-IP/X-Forwarded-For/X-Real-IP 无法从不可信对端到达 PHP。不要把客户端提供的值当作持久化或封禁的权威依据；在条件允许时，除 IP 之外还应结合访客令牌/会话为反滥用措施建立键。
