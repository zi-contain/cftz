## 1. 总结

- **漏洞类型**: 认证 (CWE-307)
- **标记位置**: app/Security/TenantAuth.php:109
- **漏洞描述**: 商户登录限流将其计数桶的键设为 SHA256(客户端 IP + '|' + 提交的凭据)（app/Security/RateLimiter.php:112-116），因此每个不同账户都会创建独立的计数器。密码喷洒攻击者针对大量账户尝试一个或少数几个常见密码时，每个桶只会留下 1-2 次命中，永远达不到最大值 8，因此不会有任何请求被阻止。扫描器“仅以凭据为键”的表述并不精确（IP 也是键的一部分），但报告的效果是正确的：不存在仅按 IP 或全局聚合的桶，而唯一的另一项控制（验证码）默认关闭，因此密码喷洒不受限制。该发现为真实漏洞（低危）。

## 2. 分析逻辑

### 步骤 1: 阅读 TenantAuth::attempt 中被标记的限流逻辑

**证据**: `app/Security/TenantAuth.php:109`

```
if (RateLimiter::tooMany('tenant_login', 8, 900, $credential)) { return false; }
```

商户登录限流使用作用域 'tenant_login'，在 900 秒窗口内 max=8，并将提交的凭据作为额外维度传入。失败时调用 RateLimiter::hit('tenant_login', $credential)（第 164 行），成功时调用 clear（第 178 行）。凭据是调用方提供的唯一维度；接下来需要查看 RateLimiter 如何将其转换为桶键。

### 步骤 2: 从 RateLimiter 推导实际的桶键

**证据**: `app/Security/RateLimiter.php:37-54,112-116`

```
public static function tooMany(string $scope, int $max, int $windowS, string $extra = ''): bool { ... WHERE scope = :scope AND identifier = :id ... bindValue('id', self::identifier($extra)); ... }
private static function identifier(string $extra): string { $raw = ClientIp::get() . '|' . $extra; return hash('sha256', $raw); }
```

桶键为 sha256(IP + '|' + credential)，按 (IP, 账户) 划分作用域：更换凭据会产生一个计数为 0 的全新桶。不存在仅按 IP 键控的桶，也不存在全局桶，因此从同一个 IP 遍历许多不同凭据永远不会累积到最大值 8。这正是密码喷洒得以可行的原因。

### 步骤 3: 确认登录端点公开可达并会进入限流逻辑

**证据**: `public/api/merchant/index.php:1000-1011`

```
if ($path === '/login' && $method === 'POST') { $data = input(); $credential = trim((string) ($data['credential'] ?? $data['phone'] ?? '')); ... if (!preg_match('/^(?:1[3-9][0-9]{9}|[A-Za-z0-9_.-]{4,32})$/', $credential) || !TenantAuth::attempt($credential, $password)) { ... }
```

POST /api/merchant/login 是未认证的公开路由（该路径上没有 session/auth 检查；路由前只有 LicenseGate::enforce() 和 DomainGuard::requirePlatformHost() 分别在第 5 行和第 75 行运行）。仅有的预检查是凭据格式正则以及 attempt() 内部的限流。凭据空间为可枚举的手机号或短登录名。

### 步骤 4: 检查另一项登录控制：验证码默认关闭

**证据**: `app/Domain/Security/Captcha.php:88-93 and app/Domain/Security/SecuritySettings.php:36-46,380-389`

```
public static function verify(string $scene, array $input): array { if (!SecuritySettings::captchaEnabled($scene)) { return ['ok' => true, 'message' => '']; } ... }
// DEFAULTS: self::KEY_CAPTCHA => ['enabled' => false, ...]
```

Captcha::verify('merchant_login', $data) 在 public/api/merchant/index.php:1005 被调用，但 captchaEnabled() 要求 'enabled' 开关，并且需要完整的 geetest 凭据；默认配置将 enabled=false。开箱即用时，验证码无条件返回 ok=true，因此不提供任何挑战，数据库限流成为唯一的暴力破解控制。

### 步骤 5: 检查边缘层是否存在基于 IP 的登录限制

**证据**: `deploy/nginx/aimu-customer-cloud.conf:39-52 and deploy/nginx-security.conf:74-91`

```
location = /api/admin/login { limit_req zone=aimu_admin_login burst=5 nodelay; rewrite ^/api/admin/(.*)$ /api/admin/index.php?route=$1&$args last; }
location /api/merchant/ { rewrite ^/api/merchant/(.*)$ /api/merchant/index.php?route=$1&$args last; add_header Cache-Control "no-store, private" always; }
```

管理员登录 location 带有边缘 IP 限流（limit_req zone=aimu_admin_login rate=10r/m），但商户 location /api/merchant/ 没有。加固文件（deploy/nginx-security.conf:83-86）中的商户登录限制仍处于注释状态。因此，无论应用层还是代理层，商户登录都没有服务器 IP 级别的上限。

### 步骤 6: 交叉检查同类平台登录是否存在相同模式

**证据**: `app/Security/PlatformAuth.php:31`

```
if (RateLimiter::tooMany('platform_login', 8, 900, $username)) { return false; }
```

PlatformAuth 采用相同的 IP+username 方案作为键，确认这是有意设计（SECURITY.md:14,207 记录 identifier = SHA256(IP + '|' + dimension)），而非一次性错误。该设计能防御来自单个 IP 的单账户暴力破解，但无法解决多账户喷洒问题。

### 分析过程

- Q1: 被标记的代码能否被攻击者触达？-> 能。POST /api/merchant/login 是公开路由，会调用 TenantAuth::attempt ($credential,$password)（public/api/merchant/index.php:1000-1011），且没有 auth 守卫。
- Q2: 该控制能否限制跨多个账户的尝试（密码喷洒）？-> 不能。桶标识符为 sha256(IP|credential)（app/Security/RateLimiter.php:112-116）；每个不同凭据都是一个全新桶，因此每个账户 1-2 次尝试永远达不到 max=8，也不会有请求被拒绝。
- Q3: 是否存在补偿性的、仅按 IP 或全局的限制？-> 不存在。在项目范围内 grep 发现 'tenant_login' 仅在 TenantAuth.php:109/164/178 中使用；不存在仅按 IP/全局的 RateLimiter 调用，并且 nginx 商户 location 没有 limit_req（deploy/nginx/aimu-customer-cloud.conf:49-52）。
- Q4: 是否还存在另一种认证尝试控制（验证码）？-> 默认不存在。Captcha::verify('merchant_login') 在验证码禁用时短路返回 ok=true，并且发布默认值为 enabled=false（SecuritySettings.php:38,380-389; Captcha.php:88-93）。
- Q5: 该代码是否属于测试/演示/不可达代码？-> 不是。它是 public/api/merchant/ 下的生产商户 API 登录代码。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Security/RateLimiter.php:112-116 将 identifier 构造为 hash(ClientIp::get() . '|' . $extra)，因此 'tenant_login' 桶按 (IP, 账户) 划分，每个新凭据都会把计数器重置为 0。
- app/Security/TenantAuth.php:109 检查 tooMany('tenant_login', 8, 900, $credential)，且仅在失败时通过 hit(..., $credential) 递增（第 164 行）——每个账户一次密码尝试远低于 max=8。
- public/api/merchant/index.php:1000-1011 公开暴露登录端点，并将攻击者提供的凭据直接传入 attempt()。
- app/Domain/Security/SecuritySettings.php:38 发布时验证码为 'enabled' => false，因此 Captcha.php:91-92 返回 ok=true，默认不会添加任何人机验证挑战。
- deploy/nginx/aimu-customer-cloud.conf:39-52 在边缘对 /api/admin/login 进行限流，但未对 /api/merchant/ 应用任何 limit_req，并且 deploy/nginx-security.conf:83-86 将商户登录规则保留为注释状态。

## 4. 验证思路与复现步骤

- **前置条件**: 商户 API 可通过 POST /api/merchant/login 访问，且请求 Host 能通过 DomainGuard（已配置的平台主机）。攻击者拥有一份候选商户凭据列表（可枚举的手机号或短登录名）。验证码保持发布默认值（禁用）；如果启用，攻击者按请求解决验证码。在 /api/merchant/ 上未配置 nginx limit_req。

**复现步骤：**

1. 准备一份包含 N 个不同且格式有效的凭据列表（例如 1000 个匹配 1[3-9][0-9]{9} 的手机号）。
2. 对每个凭据发送一次 POST /api/merchant/login，使用相同的常见密码（例如 'Password123'）但不同的凭据值；将总耗时控制在 15 分钟窗口内。
3. 观察到没有任何响应报告限流，并且无论尝试了多少个不同账户，每个请求都会执行完整的凭据检查（对已找到的用户进行 bcrypt 校验）。
4. 检查 cc_rate_limits 表中 scope='tenant_login' 的记录，确认存在 N 条不同的 identifier 行，每行只有一个 hit_at，且没有任何一行达到最大值 8——即没有任何桶触发限流。
5. 与反复针对同一个账户的情况对比：窗口内的第 9 次失败会在密码检查之前被拒绝，表明该控制仅限制每账户（每 IP）的重复尝试。

**测试样例：**

```
for phone in $(cat merchants_phones.txt); do curl -s -X POST https://<platform-host>/api/merchant/login -H 'Content-Type: application/json' -d '{"credential":"'"$phone"'","password":"Password123"}'; done   # one common password, many distinct credentials
```

- **预期现象**: 针对数百/数千个不同账户，服务器永远不会返回限流/锁定，也永远不会停止运行密码检查，而 cc_rate_limits 行全都是不同的 identifier，计数为 1（没有 >= 8）。对于正确配置了 IP 或全局限流的登录，运营方反而会看到：无论针对哪个账户，在达到固定尝试预算后就开始出现拒绝。

## 5. 修复建议

为登录限流添加聚合维度，使预算跨账户消耗，而不仅仅按账户消耗。具体而言，在 TenantAuth::attempt（app/Security/TenantAuth.php:109）中，仅针对客户端发起第二次检查（RateLimiter::tooMany('tenant_login_ip', <lowerMax>, 900)），复用现有 RateLimiter，传入空/固定 extra 或使用新作用域，并在每次失败尝试时（第 164 行）为该作用域调用 RateLimiter::hit，从而减缓单个来源使用许多不同凭据进行失败尝试。或者/另外，对商户登录 location 强制执行边缘 IP 限制（仿照 deploy/nginx/aimu-customer-cloud.conf:39-40 中针对 /api/merchant/login 的 limit_req），并启用登录验证码场景（SecuritySettings KEY_CAPTCHA 'enabled'=true），使自动化喷洒必须解决挑战。仅降低每个作用域的 max 本身并不足够；缺失聚合桶才是核心修复点。
