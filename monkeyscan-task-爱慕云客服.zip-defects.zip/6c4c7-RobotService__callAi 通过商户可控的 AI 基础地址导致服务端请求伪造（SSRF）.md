## 1. 总结

- **漏洞类型**：SSRF（CWE-918）
- **标记位置**：app/Domain/Robot/RobotService.php:532
- **漏洞描述**：一个由租户控制的值（cc_tenant_ai_settings.custom_base_url）未经任何过滤即流入 RobotService::callAi() 中的 curl_init()。唯一的防护是一处 https:// 前缀校验（RobotService.php:499）：没有主机白名单，没有私有/回环/链路本地 IP 黑名单，也没有 DNS 重绑定固定（DNS-rebinding pinning）；同时，租户解密后的 API 密钥会通过 Authorization 请求头发送到该任意主机（RobotService.php:549）。该机器人可由未经身份认证的挂件访客通过 /send 触发（public/api/widget/index.php:1515 和 1532），从而使租户获得一个针对内部 HTTPS 服务的服务端请求原语；上游的错误文本会被回显到会话中。

## 2. 分析逻辑

### 步骤 1: 检查被标记的 SSRF 汇聚点

**证据**: `app/Domain/Robot/RobotService.php:496,532`

```
$endpoint = self::normalizeBase((string) $credential['base']) . '/chat/completions'; ... $curl = curl_init($endpoint);
```

出站请求目标由 $credential['base'] 构建，并传入 curl_init()。下一步需确定 $credential['base'] 的来源，以及主机是否由攻击者控制。

### 步骤 2: 确认该端点上的唯一防护

**证据**: `app/Domain/Robot/RobotService.php:499`

```
if (stripos($endpoint, 'https://') !== 0) { return $fail('API 基址必须以 https:// 开头'); }
```

唯一的校验是 https:// 前缀检查，外加 CURLOPT_FOLLOWLOCATION => false（第 546 行）。整个文件中没有主机白名单，没有 FILTER_VALIDATE_IP / 私有网段检查，也没有任何 CURLOPT_RESOLVE 固定。协议仅限 https，因此明文 HTTP 内部目标会被阻止，但内部 TLS 服务与 DNS 重绑定并未被阻止。

### 步骤 3: 追溯 base URL 至其由租户控制的来源

**证据**: `app/Domain/Robot/RobotService.php:334`

```
$base = trim((string) ($settings['custom_base_url'] ?? '')); ... return ['base' => $base, 'key' => $key, 'model' => $model];
```

当 credential_source='custom' 时，'base' 直接逐字读取自租户设置行。调用链：callAi（第 478 行）<- handleVisitorMessage:165 <- resolveCredential:327/334。

### 步骤 4: 确认写入路径存储了原始 URL

**证据**: `public/api/merchant/index.php:4877,4888,4950`

```
$baseUrl = trim((string) ($data['custom_base_url'] ?? '')); if ($baseUrl !== '' && stripos($baseUrl, 'https://') !== 0) { respond(-1, ...); } ... 'custom_base_url' => $baseUrl === '' ? null : $baseUrl,
```

商户设置保存处理程序仅校验 https:// 前缀，并将该值原样存储（第 4989-4993 行的 INSERT ... ON DUPLICATE KEY UPDATE）。同样的薄弱写入路径也存在于 public/robot-admin.php:80/87/116。写入与读取时均未应用规范化、白名单或 IP 检查。

### 步骤 5: 确认汇聚点可被访客触达

**证据**: `public/api/widget/index.php:1515,1532`

```
RobotService::handleVisitorMessage($pdo, (int) $conversation['tenant_id'], (int) $conversation['site_id'], $conversationId, $visitorId, $body, $type);
```

/send 端点（public/api/widget/index.php:1348）只要求提供访客令牌，而任何匿名访客都可通过 /init 自由获得该令牌（第 719 行的 verifyVisitorToken 只是对自签发 payload 做 HMAC 校验，无需登录）。因此，未经身份认证的访客即可触发发往商户所选主机的出站请求。robot_mode 需为 ai/hybrid，且 only_when_offline 可由租户关闭，因此该汇聚点是否触发完全由租户掌控。

### 步骤 6: 检查项目范围内是否存在 SSRF 缓解措施

**证据**: `app/Domain/Robot/RobotService.php (grep)`

```
grep 'CURLOPT_RESOLVE|OPENSOCKETFUNCTION|FILTER_VALIDATE_IP|allowlist|private_ip' -> no matches in RobotService.php
```

一次全仓库 grep 未在该路径上发现任何出站主机白名单、IP 网段黑名单或 CURLOPT_RESOLVE/OPENSOCKETFUNCTION 固定。仅有的 FILTER_VALIDATE_IP 用法（app/Security/ClientIp.php:126、public/api/widget/index.php:257）用于入站客户端 IP 解析，与出站 URL 无关。

### 分析过程

- Q1：用户可控输入是否会影响服务端请求的 URL/主机？-> 是。custom_base_url 由租户提供（merchant/index.php:4877,4950），并作为完整 base URL 到达 curl_init()（RobotService.php:334 -> 496 -> 532）。
- Q2：目标主机名/URL 是否针对白名单进行了校验？-> 否。仅存在 https:// 前缀校验（RobotService.php:499）；没有域名白名单。重定向已禁用（第 546 行），但这并未限制初始主机。
- Q3：解析后的 IP 是否针对内部/私有网段进行了检查并固定？-> 否。没有 FILTER_VALIDATE_IP，没有私有网段检查，没有 CURLOPT_RESOLVE；主机名被直接交给 curl 自行解析（无 DNS 重绑定防护）。
- Q4：是否仅路径/查询由用户控制，而主机为硬编码？-> 否。整个 base URL（包括协议/主机/端口）均由租户控制；normalizeBase() 仅做 trim 并追加 /v1（RobotService.php:907-936）。
- Q5：该代码是否为测试/示例/生成代码或不可达？-> 否。它是一个真实的框架入口点：挂件 /send 处理程序（public/api/widget/index.php:1515,1532）可被匿名访客触达。
- 结论：所有绕过条件均不成立 -> 真实漏洞（TP）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Domain/Robot/RobotService.php:532 将租户控制的 URL 交给 curl_init()，且未做任何主机/端口/IP 校验。
- app/Domain/Robot/RobotService.php:499 是唯一的防护，仅校验 https:// 前缀，但 https://127.0.0.1:8443 或通过 DNS 重绑定指向内部地址的攻击者域名仍可通过。
- app/Domain/Robot/RobotService.php:334 在 credential_source='custom' 时从租户设置行逐字读取 custom_base_url。
- public/api/merchant/index.php:4877,4888,4950 仅校验 https:// 前缀，并将原始 URL 存储进 cc_tenant_ai_settings。
- public/api/widget/index.php:1515,1532 从匿名挂件 /send 端点调用 handleVisitorMessage，使该汇聚点可被远程触发。
- app/Domain/Robot/RobotService.php:549 将 'Authorization: Bearer ' . $credential['key'] 发送到租户选择的主机，从而把解密后的 API 密钥泄露给该目标。

## 4. 验证思路与复现步骤

- **前置条件**：攻击者需控制一个具有 manage 权限的租户账号。向商户机器人配置保存端点 POST，设置 robot_mode='ai'（或 'hybrid'）、credential_source='custom'、custom_base_url='https://127.0.0.1:8443/v1'（或任意内部 HTTPS 主机），并提供非空的 custom_api_key 与 custom_model_code。将 only_when_offline=0 使机器人始终应答，并将 max_ai_replies_per_conversation=0 以解除调用次数限制。访客侧仅需一个由挂件 /init 端点签发的匿名访客令牌。

**复现步骤：**

1. 以租户身份 POST 机器人配置保存请求，设置 credential_source=custom，并将 custom_base_url 指向某个内部 HTTPS 服务（例如 https://127.0.0.1:8443/v1）。
2. 匿名调用挂件 /init 端点获取访客令牌；记录返回的 conversation_id。
3. 向挂件 /send 端点 POST，请求头 X-Visitor-Token 设为该令牌，JSON 请求体为 {"conversation_id":<id>,"body":"hello","type":"text"}。
4. 服务端处理程序进入 RobotService::callAi，并向租户选择的内部 URL 发起一次 cURL POST，Authorization 请求头中携带租户的 API 密钥。
5. 检查生成的会话/AI 日志记录：上游状态与错误消息被抓取并返回给访客（RobotService.php:562-571）。

**测试样例：**

```
POST /<widget-base>/send  (header: X-Visitor-Token: <anon visitor token>; body: {"conversation_id":1,"body":"hi","type":"text"})  -- after tenant config custom_base_url is set to https://127.0.0.1:8443/v1
```

- **预期现象**：服务端会向攻击者选定的内部主机发起一次出站 TLS 连接（可通过服务端网络日志、netstat 或内部端口上的监听器观察到），所配置的监听器会收到一个发往 /v1/chat/completions 的 HTTP POST，其中携带 'Authorization: Bearer <tenant key>'。当内部服务以非 200 或 TLS 错误应答时，被抓取的消息会出现在面向访客的机器人回复/日志中（RobotService.php:571 处的 '上游返回 ...'），由此确认响应被回显。

## 5. 修复建议

不要让租户提供的 URL 驱动出站请求。应为可信 AI 提供商主机建立严格白名单，并将 parse_url 解析出的主机与之校验。解析主机名后，用 ipaddress/FILTER_VALIDATE_IP 加网段检查拒绝回环/私有/链路本地网段（127.0.0.0/8、10.0.0.0/8、172.16.0.0/12、192.168.0.0/16、169.254.0.0/16、::1、fc00::/7），并通过 CURLOPT_RESOLVE（或 CURLOPT_OPENSOCKETFUNCTION）将连接固定到已校验的 IP，以挫败 DNS 重绑定。保持 CURLOPT_FOLLOWLOCATION 处于禁用状态。作为纵深防御，不要将租户解密后的 Authorization 请求头转发给白名单以外的主机，并在两条写入路径（public/api/merchant/index.php:4877-4950 和 public/robot-admin.php:79-116）上应用相同的主机校验，使恶意值无法被持久化。
