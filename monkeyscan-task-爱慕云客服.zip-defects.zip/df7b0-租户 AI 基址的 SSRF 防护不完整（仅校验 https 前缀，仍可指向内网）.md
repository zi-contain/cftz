## 1. 总结

- **漏洞类型**：SSRF (CWE-918)
- **标记位置**：public/robot-admin.php:87
- **漏洞描述**：租户管理员可设置租户 AI 基础 URL（custom_base_url）。该值会被持久化，随后在 RobotService::callAi 中作为服务端 cURL 请求的主机。唯一的防护是协议检查（stripos(...,'https://') !== 0）；既无主机允许列表，也无解析后 IP 校验，因此租户可将服务器指向任意内部 HTTPS 主机（例如 127.0.0.1、::1、内部管理面板或内部 HTTPS API）。此漏洞可被触发：访客小组件的 /send 路径会调用 RobotService::handleVisitorMessage，后者解析自定义凭据并发起出站请求。结论为真实漏洞。请注意，客户端保持 TLS 校验开启（CURLOPT_SSL_VERIFYPEER/VERIFYHOST），因此目标必须提供受信任证书；这缩小了攻击面，但并未消除该利用原语。

## 2. 分析逻辑

### 步骤 1: 检查针对 custom_base_url 的已标记防护

**证据**：`public/robot-admin.php:80-89, 116`

```
$baseUrl = trim((string) ($_POST['custom_base_url'] ?? ''));
if ($baseUrl !== '' && stripos($baseUrl, 'https://') !== 0) {
    throw new RuntimeException('API 基址必须以 https:// 开头');
}
... 'custom_base_url' => $baseUrl === '' ? null : mb_substr($baseUrl, 0, 500),
```

保存处理程序接受任意 custom_base_url 字符串，仅要求其以 'https://' 开头；没有主机名允许列表，没有 parse_url 规范化，也没有 IP 范围检查。该值会被存储到 cc_tenant_ai_settings。

### 步骤 2: 确认具有相同薄弱防护的第二入口点

**证据**：`public/api/merchant/index.php:4833-4836, 4877-4890, 4950`

```
if ($path === '/robot/config/save' && $method === 'POST') {
    if (!$canManage) { respond(-1, '当前客服账号没有管理权限', null, 403); }
...
if ($baseUrl !== '' && stripos($baseUrl, 'https://') !== 0) {
    respond(-1, 'API 基址必须以 https:// 开头');
}
... 'custom_base_url' => $baseUrl === '' ? null : $baseUrl,
```

JSON API 路由 /robot/config/save 应用相同的仅 HTTPS 检查，且仅要求管理员账户（$canManage），因此控制主机的是租户管理员，而非平台超级管理员。这确认了信任边界为租户管理员。

### 步骤 3: 追踪存储值到出站请求汇聚点

**证据**：`app/Domain/Robot/RobotService.php:327-341, 478-501, 532-557`

```
if ($source === 'custom') {
    $base = trim((string) ($settings['custom_base_url'] ?? ''));
    ... return ['base' => $base, 'key' => $key, 'model' => $model];
}
...
$endpoint = self::normalizeBase((string) $credential['base']) . '/chat/completions';
if (stripos($endpoint, 'https://') !== 0) { return $fail('API 基址必须以 https:// 开头'); }
...
$curl = curl_init($endpoint);
curl_setopt_array($curl, [ ... CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_FOLLOWLOCATION => false, CURLOPT_HTTPHEADER => [ ..., 'Authorization: Bearer ' . $credential['key'], ... ] ]);
$response = curl_exec($curl);
```

持久化的 custom_base_url 经 normalizeBase() 原样流入 curl_init()。汇聚点处唯一的过滤仍是同一个 https:// 协议检查（第 499 行）；不存在主机允许列表，也没有 IP 检查。该请求在 Authorization 头中携带租户解密后的 API 密钥。重定向已禁用，因此缺失主机校验正是问题所在。

### 步骤 4: 确认攻击者可触发的汇聚点可达性

**证据**：`public/api/widget/index.php:1515-1523, 1532-1540`

```
RobotService::handleVisitorMessage(
    $pdo,
    (int) $conversation['tenant_id'],
    (int) $conversation['site_id'],
    $conversationId,
    $visitorId,
    $body,
    $type
);
```

handleVisitorMessage 由面向访客的小组件 /send 处理程序在事务提交后调用。当 robot_mode 为 {ai,hybrid} 且 credential_source=custom 时，callAi 会运行并向租户提供的主机发起出站请求。租户只需以访客身份发送消息即可触发，因此无需等待真实客户即可触达该利用原语。

### 步骤 5: 搜索项目中任何主机/IP 允许列表或 SSRF 缓解措施

**证据**：`app/Domain/Robot/RobotService.php:496-557 (only check), grep for allowlist/IP-range helpers returned none`

```
$endpoint = self::normalizeBase((string) $credential['base']) . '/chat/completions';
if (stripos($endpoint, 'https://') !== 0) { return $fail('API 基址必须以 https:// 开头'); }
```

在项目范围内搜索 '169.254'、'127.0.0'、'::1'、'allowlist'、'whitelist'、'gethostbyname'、'FILTER_VALIDATE_IP'、'FILTER_FLAG_NO_PRIV' 和 'CURLOPT_RESOLVE'，未在 app/ 或 public/ 中发现任何主机或解析后 IP 校验。协议检查是唯一的控制措施；parse_url 仅用于在 normalizeBase 中派生路径段，而不用来校验主机。

### 分析过程

- 问题 1：用户可控输入是否会影响服务端请求的 URL/主机？ -> 是。custom_base_url 是租户管理员请求字段（public/robot-admin.php:80；public/api/merchant/index.php:4877），会被持久化并用作 cURL 目标主机（RobotService.php:334->341->496->532）。
- 问题 2：目标主机名/URL 是否会根据允许列表校验？ -> 否。唯一的检查是 RobotService.php:499 处的 stripos(...,'https://') !== 0（以及 robot-admin.php:87 / merchant:4888 的镜像检查）；不存在主机名允许列表。
- 问题 3：解析后的 IP 是否针对内部/私有范围进行检查？ -> 否。该路径上任何位置都不存在 DNS 解析或 IP 范围校验（项目范围内 grep 未发现）。
- 问题 4：是否仅路径/查询由用户控制，而主机是硬编码的？ -> 否。整个基础 URL（包括协议、authority/主机）均由用户控制；normalizeBase 仅追加 '/v1' 并剥离已知后缀。
- 问题 5：该代码是否为测试/演示/不可达？ -> 否。汇聚点可从框架小组件 /send 处理程序（public/api/widget/index.php:1515,1532）到达，而这是生产入口点。
- 结论：所有防护均已失效 -> 真实漏洞。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/robot-admin.php:87 仅对 custom_base_url 强制校验 `stripos($baseUrl,'https://') !== 0`；没有主机限制。
- public/api/merchant/index.php:4888 在 /robot/config/save API 上应用相同的仅 HTTPS 检查，仅由 $canManage 控制（第 4834 行）。
- app/Domain/Robot/RobotService.php:499 对完全组装后的端点重复仅协议检查，然后第 532 行的 curl_init($endpoint) 使用 `Authorization: Bearer <key>`（第 549 行）发起出站请求。
- public/api/widget/index.php:1515/1532 从访客小组件调用 RobotService::handleVisitorMessage，因此只需发送聊天消息即可触达 SSRF。

## 4. 验证思路与复现步骤

- **前置条件**：已认证且具备管理权限（TenantAuth::canManage() 为 true）的租户账户。该租户的 robot_mode 设置为 'ai' 或 'hybrid'，credential_source 设置为 'custom'，并已保存 custom_api_key。目标内部主机必须提供能通过服务器信任存储校验的 HTTPS 证书，因为 CURLOPT_SSL_VERIFYPEER=true 且 CURLOPT_SSL_VERIFYHOST=2（RobotService.php:543-544）。

**复现步骤：**

1. 以租户管理员身份保存机器人配置：设置 credential_source=custom、有效的 custom_api_key、robot_mode=ai，并将 custom_base_url 设为内部 HTTPS 地址，例如 https://127.0.0.1/ 或 https://<internal-https-service>/（POST /robot/config/save 或 robot-admin.php 表单）。
2. 通过小组件 /send 端点发送一条访客文本消息，以 ai/hybrid 模式触发 RobotService::handleVisitorMessage。
3. 观察服务端请求行为：请求被发往所提供的主机，而不是被拒绝；任何上游响应/超时都会显示在机器人管理页面的机器人回复日志（cc_tenant_robot_logs.error_message）中。

**测试样例：**

```
POST /api/merchant/robot/config/save {"robot_mode":"ai","credential_source":"custom","custom_api_key":"sk-test","custom_base_url":"https://127.0.0.1/"}  then POST a text message to the widget /send endpoint for the tenant's conversation.
```

- **预期现象**：平台向租户选择的内部主机发起出站 TLS 请求，并在机器人回复日志中记录结果（连接错误或上游响应正文摘录），而不是在保存时拒绝该基础 URL。安全实现会在发出任何请求之前拒绝未列入允许列表的主机（或其解析后的私有 IP），且不依赖协议检查。

## 5. 修复建议

在两条保存路径上（public/robot-admin.php:87 和 public/api/merchant/index.php:4888）以及汇聚点处，使用 parse_url() 解析 URL，要求 scheme === 'https'，将主机解析为 IP，并拒绝私有/环回/链路本地/元数据地址范围（10/8、172.16/12、192.168/16、127/8、169.254/16、::1、fc00::/7）。将连接固定到经验证解析后的 IP（例如 CURLOPT_RESOLVE），以防止 DNS 重绑定；最好再将主机限制为已知 AI 提供商端点的显式允许列表。当目标主机未经验证时，不要附带 Authorization 凭据。请注意，当前仅靠 HTTPS 防护和 TLS 校验并不能阻止对内部 HTTPS 主机的请求。
