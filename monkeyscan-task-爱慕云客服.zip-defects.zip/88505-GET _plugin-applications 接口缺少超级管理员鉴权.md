## 1. 总结

- **漏洞类型**：broken_function_level_authorization (CWE-862)
- **告警位置**：public/api/admin/index.php:3564
- **漏洞描述**：public/api/admin/index.php:3564 处的 GET /plugin-applications 处理函数仅由 requireAdmin()（身份认证：会话 + token）防护，未做任何角色校验；而同类的 /plugin-developers GET（第 3534 行）以及写入端点 /plugin-applications/review POST（第 3612 行）均强制要求 PlatformAuth::isSuperAdmin()。因此，任何已通过身份认证、但角色不是 super_admin 的平台账号（cc_platform_users 中枚举的角色包括 admin/finance/risk/support/auditor）均可读取全部插件申请，包括申请人的联系方式、包地址、租户名称以及内部审核备注。该端点实施了身份认证，却未实施授权，这正是告警所描述的 CWE-862 缺陷。

## 2. 分析逻辑

### 步骤 1：阅读被标记的处理函数及其缺失的角色校验

**证据**：`public/api/admin/index.php:3564`

```
if ($path === '/plugin-applications' && $method === 'GET') {
    $status = trim((string) ($_GET['status'] ?? ''));
    $sql = 'SELECT a.id, a.tenant_id, t.name AS tenant_name, a.plugin_name, a.category,
                   a.version, a.homepage, a.package_url, a.description, a.contact,
                   a.price_type, a.price_cents, a.status, a.review_note, a.reviewed_at, a.created_at
            FROM cc_plugin_applications a LEFT JOIN cc_tenants t ON t.id = a.tenant_id';
    ...
    respond(200, 'success', ['list' => $rows, 'counts' => $counts]);
```

该处理函数（第 3564-3609 行）中没有任何位置调用 PlatformAuth::isSuperAdmin()。它返回完整的申请列表，其中包含 contact、package_url、tenant_name 和 review_note。唯一使用的输入是 `status`，且以绑定参数方式传入，因此这纯粹是授权问题，而非数据流问题。

### 步骤 2：与同类读取端点进行对比

**证据**：`public/api/admin/index.php:3533`

```
if ($path === '/plugin-developers' && $method === 'GET') {
    if (!PlatformAuth::isSuperAdmin()) respond(-1, '仅超级管理员可查看开发者申请', null, 403);
```

针对同类资源的类似读取端点显式要求超级管理员权限，否则返回 HTTP 403。而申请列表处理函数恰好省略了这一防护，印证了告警所指出的不一致。

### 步骤 3：与对应的写入端点进行对比

**证据**：`public/api/admin/index.php:3611`

```
if ($path === '/plugin-applications/review' && $method === 'POST') {
    if (!PlatformAuth::isSuperAdmin()) {
        respond(-1, '仅超级管理员可审核插件申请', null, 403);
    }
```

针对同一资源的审核/写入路径要求超级管理员权限。开发者将插件审核视为超级管理员的职责，却允许所有已认证的平台角色读取同一批记录（包括由超级管理员撰写的 review_note）。

### 步骤 4：确认唯一的强制关卡：身份认证而非授权

**证据**：`public/api/admin/index.php:386`

```
$user = requireAdmin();
$pdo = Database::connection();
```

第 386 行的 requireAdmin() 在登录/许可检查块之后对所有路由无条件执行（第 3564 行的 /plugin-applications 处理函数位于同一个 try 块中），因此该端点确实只能由已认证的平台用户访问。但 requireAdmin()（第 83-94 行）仅检查 PlatformAuth::check() 以及会话与 token 是否匹配——不执行任何角色校验。身份认证已强制，授权未强制。

### 步骤 5：确认存在非超级管理员角色且被视为不同权限主体

**证据**：`database/schema.sql:13`

```
role ENUM('super_admin','admin','finance','risk','support','auditor') NOT NULL,
```

cc_platform_users 中定义了除 super_admin 之外的五个角色。PlatformAuth::isSuperAdmin()（app/Security/PlatformAuth.php:70-73）仅在 role === 'super_admin' 时返回 true。代码库在其他位置也使用了这些非超级管理员角色（例如 index.php:1427 允许 ['super_admin','risk']，index.php:1699 允许 ['super_admin','risk','auditor']），证明此类账号确实存在，且不等同于超级管理员。其中任意一个角色均可调用这个未受保护的 GET。

### 步骤 6：排除路由层、网关与框架层面的防护

**证据**：`deploy/nginx/aimu-customer-cloud.conf:44`

```
location /api/admin/ {
    rewrite ^/api/admin/(.*)$ /api/admin/index.php?route=$1&$args last;
    add_header Cache-Control "no-store, private" always;
}
```

nginx 层只是将 /api/admin/* 重写到 index.php，不执行任何角色/授权校验（它也无法执行——它并不了解应用角色）。public/api/admin/ 下没有 .htaccess 或其他中间件。没有任何框架级或网关级角色控制覆盖该路由，因此处理函数中缺失的 isSuperAdmin() 校验是唯一可能的控制手段，而它并不存在。

### 步骤 7：检查前端拦截（UI 并非服务端控制手段）

**证据**：`public/admin-app/assets/applications-BFYDVtRw.js:1`

```
z=T(()=>{...U.userInfo?.role==="super_admin"}), ... s(b,{...,disabled:!z.value||a.status==="approved",...}), z.value?w("",!0):(r(),f("span",ke,"仅超级管理员可审核"))
```

管理端 UI 会计算一个 super_admin 标志，但仅用它来禁用审核按钮并显示“仅超级管理员可审核”（only super admins can review）——它不会拦截列表加载，而该列表通过本处理函数所服务的同一个 API 为每个用户获取。这印证了服务端是读取限制唯一可能存在的位置，而这里完全没有限制。客户端禁用按钮并非授权控制。

### 分析过程

- Q1：该端点是否执行特权/管理操作？-> 是。它是一条平台后台 API 路由（public/api/admin/index.php:3564），暴露商户/插件申请人的个人信息、包地址以及内部超级管理员审核备注。
- Q2：是否配置了路由级角色授权？-> 否。唯一的路由级关卡是 requireAdmin()（index.php:386），它仅强制身份认证（index.php:83-94）；nginx 不执行角色校验（deploy/nginx/aimu-customer-cloud.conf:44）。
- Q3：是否存在方法级角色授权？-> 否。处理函数（index.php:3564-3609）中没有 isSuperAdmin() 调用，这与同类端点 index.php:3534 及其写入对应端点 index.php:3612 不同。
- Q4：是否有 API 网关/代理在强制授权？-> 否。nginx 重写只是转发到 index.php；网关处不存在任何角色逻辑（deploy/nginx/aimu-customer-cloud.conf:44）。
- Q5：该代码是否为测试/演示/生成/不可达？-> 否。它是一个运行中的生产 HTTP 处理函数，任何已认证的平台账号都可以通过 /api/admin/plugin-applications 访问。
- 结论：身份认证已强制，但所需的超级管理员授权缺失 -> 真实漏洞（TP，CWE-862）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/admin/index.php:3564 —— GET /plugin-applications 处理函数中不包含 PlatformAuth::isSuperAdmin() 校验。
- public/api/admin/index.php:3534 —— 同类 GET /plugin-developers 强制要求 isSuperAdmin()，证明该类资源应有的权限级别。
- public/api/admin/index.php:3612 —— 针对同一批记录的写入端点 /plugin-applications/review 强制要求 isSuperAdmin()。
- public/api/admin/index.php:386 —— requireAdmin() 是唯一的关卡，且按其实现（index.php:83-94）只校验身份认证（会话 + token）。
- database/schema.sql:13 —— admin、finance、risk、support、auditor 与 super_admin 是不同的角色，因此非超级管理员的平台账号是真实存在且权限更低的主体。
- public/api/admin/index.php:3567 —— 该 SELECT 会向每个已认证调用方返回 a.contact、a.package_url、a.homepage、t.name AS tenant_name 以及 a.review_note（超级管理员审核评论）。

## 4. 验证思路与复现步骤

- **前置条件**：一个处于活动状态的平台账号（cc_platform_users.status='active'），角色为 'super_admin' 之外的任意值（例如 'support'、'finance'、'admin'、'auditor' 或 'risk'）；平台已安装（存在 storage/install.lock），且 /api/admin/ 路由可通过标准 nginx 重写访问。测试者必须完成正常登录，以同时具备 requireAdmin() 所需的会话（cc_platform 会话 Cookie）和 admin_api_token 请求头。

**复现步骤：**

1. 准备或获取一个角色为非超级管理员值的平台账号，例如执行 UPDATE cc_platform_users SET role='support' WHERE username='...'。
2. 通过 POST /api/admin/login（用户名/密码）进行身份认证；记录返回的 token 和会话 Cookie。
3. 发起 GET /api/admin/plugin-applications 请求，携带会话 Cookie 以及与 session token 匹配的 'token' HTTP 请求头，以满足 requireAdmin()。
4. 观察响应状态码与响应内容。
5. 作为对照，使用同一非超级管理员凭据调用同类端点 GET /api/admin/plugin-developers，并观察其返回的超级管理员 403。

**测试样例：**

```
GET /api/admin/plugin-applications HTTP/1.1
Host: <platform-host>
Cookie: <session-cookie-from-login>
token: <admin_api_token-from-login>
```

- **预期现象**：该请求返回 HTTP 200、code 200，并且 result.list 中有数据（包含 tenant_name、contact、package_url、homepage、review_note 字段）。同一非超级管理员账号调用 GET /api/admin/plugin-developers 时会收到 code -1、HTTP 403 以及消息 '仅超级管理员可查看开发者申请'。/plugin-applications 在同类端点返回 403 的情况下仍返回 200 且带数据，这即为超级管理员角色校验缺失的可观测证据。

## 5. 修复建议

在 public/api/admin/index.php:3564 的 GET /plugin-applications 处理函数顶部、紧随路由条件之后，添加与同类端点及写入端点相同的角色防护：

```
if ($path === '/plugin-applications' && $method === 'GET') {
    if (!PlatformAuth::isSuperAdmin()) {
        respond(-1, '仅超级管理员可查看插件申请', null, 403);
    }
    ...
```

这与 public/api/admin/index.php:3534 和 :3612 保持一致。由于该端点的定位是超级管理员审核功能（审核端点和同类读取端点均已确立这一点），应在服务端强制角色，而不是依赖管理端 UI——后者目前只是禁用审核按钮（public/admin-app/assets/applications-BFYDVtRw.js:1）。反之，如果读取访问确实面向更广泛的平台工作人员，则应在服务端定义并强制一份显式的角色白名单，而不是将该路由向所有已认证的平台账号开放。
