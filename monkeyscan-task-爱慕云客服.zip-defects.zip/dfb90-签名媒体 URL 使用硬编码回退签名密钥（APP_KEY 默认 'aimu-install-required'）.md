## 1. 总结

- **漏洞类型**: hardcoded_cryptographic_key (CWE-321)
- **标记位置**: public/api/merchant/index.php:335
- **漏洞描述**: 媒体 URL 的 HMAC 密钥由 APP_KEY 派生，并带有硬编码的公开回退值 'aimu-install-required'（public/api/merchant/index.php:335 以及 public/api/widget/index.php:63）。/media 端点仅通过比较该 HMAC 来授权下载（public/api/widget/index.php:914-915），且当 APP_KEY 缺失时，签名或验证路径中没有任何逻辑会触发安全失败（fail closed）。由于安装程序可以在 .env 已存在但缺少 APP_KEY 的情况下完成安装（app/Core/Installer.php:362-375），部署可能进入一种状态：每个签名都可由公开常量计算出来，从而使访问控制失效。正确的修复方式是采用代码库中其他地方已用于加密的做法（app/Security/Crypto.php:58）：拒绝签名/验证，而不是回退到固定密钥。

## 2. 分析逻辑

### 步骤 1: 阅读被标记的签名函数

**证据**: `public/api/merchant/index.php:331-341`

```
function merchantSignedMediaUrl(string $objectKey, int $ttl = 3600): string
{
    $objectKey = ltrim($objectKey, '/');
    $expires = time() + max(60, $ttl);
    $key = hash('sha256', 'widget-media|' . (string) \App\Core\Env::get('APP_KEY', 'aimu-install-required'));
    $signature = hash_hmac('sha256', $objectKey . '|' . $expires, $key);
```

HMAC 密钥为 sha256('widget-media|' + APP_KEY)，并带有硬编码回退字符串。当 APP_KEY 未设置时，该密钥会变成完全公开的常量，因此签名可被轻易伪造。下一步：查找该密钥在何处用于验证。

### 步骤 2: 追踪该密钥在 /media 授权检查中的使用

**证据**: `public/api/widget/index.php:61-75, 905-918`

```
function mediaSigningKey(): string
{
    return hash('sha256', 'widget-media|' . (string) Env::get('APP_KEY', 'aimu-install-required'));
}
...
$expected = hash_hmac('sha256', $objectKey . '|' . $expires, mediaSigningKey());
if (!hash_equals($expected, $signature)) {
    http_response_code(403);
    exit;
}
```

mediaSigningKey()（widget/index.php:63）也使用相同的回退值，它既生成（第 70 行）也验证（第 914 行）/media 签名。/media 路由在流式传输文件之前不执行任何其他授权（第 905-980 行）。签名正确性是唯一门槛，因此一旦密钥公开，调用者只要知道对象键，就能越过该门槛。

### 步骤 3: 检查当 APP_KEY 缺失时回退逻辑是否会安全失败

**证据**: `public/api/widget/index.php:63 and app/Security/Crypto.php:44-59`

```
$configured = (string) Env::get('APP_KEY', '');
if (strpos($configured, 'base64:') === 0) { ... }
if (strlen($configured) >= 32) { ... }
throw new RuntimeException('APP_KEY 未正确配置');
```

媒体签名路径没有安全失败（fail closed）防护：mediaSigningKey() 会静默替换为公开常量。相比之下，同级加密模块 Crypto::key()（app/Security/Crypto.php:58）在 APP_KEY 无效时会抛出异常，说明媒体路径违反了预期标准。对 'aimu-install-required' 执行 grep，也未发现任何会拒绝或警告该哨兵值的代码。

### 步骤 4: 判断在正式安装中 APP_KEY 是否可能缺失

**证据**: `app/Core/Installer.php:362-382, 1896`

```
if (!$envExists) {
    $this->step($task, 7, 96, '正在生成 .env 配置文件');
    $this->writeEnvironment($data);
} else {
    $this->step($task, 7, 96, '.env 已存在，跳过生成');
}
...
$this->writeInstallLock($data);
...
'APP_KEY=' . $this->envValue('base64:' . base64_encode(random_bytes(32))),
```

writeEnvironment() 会生成随机的 32 字节 APP_KEY（第 1896 行），且 install.lock 最后写入（第 375 行），因此全新安装程序运行会生成真实密钥。但当 .env 已存在时，安装程序会跳过生成（第 362-367 行），且不验证 APP_KEY 是否存在，随后仍写入 install.lock。因此，一条受支持的手动安装路径（复制手写的、不含 APP_KEY 的 .env，或之后移除 APP_KEY）会产生 install.lock 存在但无 APP_KEY 的状态。在该状态下，mediaSigningKey() 回退逻辑可被触发。

### 步骤 5: 验证端点可达且健康检查会漏掉哨兵值

**证据**: `public/api/widget/index.php:893 and public/api/admin/index.php:2482-2486`

```
if (!is_file(dirname(__DIR__, 3) . '/storage/install.lock')) {
    respond(-1, '系统尚未安装', null, 503);
}
...
$appKey = trim((string) \App\Core\Env::get('APP_KEY', ''));
if (strlen($appKey) < 16) $securityProblems[] = 'APP_KEY 未正确配置';
```

/media 路由是一个公开的 widget 端点（需要 install.lock，widget/index.php:893-895；除签名外无需认证）。唯一的运营保障——管理员安全检查——仅在 strlen < 16 时标记 APP_KEY（admin/index.php:2486），而哨兵值 'aimu-install-required' 有 21 个字符，因此会静默通过该检查，不会向运维人员发出警告。

### 分析过程

- Q1: 被标记的值是否是用于安全决策的加密密钥？-> 是。它是控制 /media 访问的 HMAC-SHA256 密钥（public/api/merchant/index.php:335, public/api/widget/index.php:914-915）。
- Q2: 在某些部署状态下，该值是否是硬编码的 / 可公开推导的？-> 是。回退值 'aimu-install-required' 是固定字面量，因此只要 APP_KEY 未设置，key = sha256('widget-media|aimu-install-required') 就是公开常量（public/api/widget/index.php:63）。
- Q3: 当 APP_KEY 缺失时，代码是否会安全失败？-> 否。mediaSigningKey() 会静默替换为常量；相比之下，Crypto::key() 会抛出异常（app/Security/Crypto.php:58）。
- Q4: 端点在线时，是否可能出现缺少 APP_KEY 的状态？-> 是。当 .env 已存在时，安装程序会跳过 .env 生成，并且在写入 install.lock 之前不验证 APP_KEY（app/Core/Installer.php:362-375, 1896）。
- Q5: 攻击者是否可访问该端点？-> 是。/media 是一个无需认证的 widget 路由，仅由签名把关（public/api/widget/index.php:893-918）。
- Q6: 该路径上是否有任何有效防护？-> 否。管理员健康检查使用 16 字符阈值（admin/index.php:2486）；21 字符的哨兵值会绕过该检查。对象键是 128 位随机值（widget/index.php:1931），这限制了攻击者可获取哪些文件，但并不能保护签名，且仅是缓解因素。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/api/merchant/index.php:335 将媒体 HMAC 密钥派生为 hash('sha256', 'widget-media|' . Env::get('APP_KEY', 'aimu-install-required'))——一个硬编码回退密钥。
- public/api/widget/index.php:63 定义了相同的回退值，并且 public/api/widget/index.php:914-915 将其用作 /media 下载的唯一授权检查。
- app/Security/Crypto.php:58 在密钥无效时抛出 'APP_KEY 未正确配置'，而媒体签名路径会静默回退到公开常量。
- app/Core/Installer.php:362-367 当 .env 已存在时跳过 .env 生成，并且 app/Core/Installer.php:375 仍会写入 install.lock，因此 install.lock 可以与缺失的 APP_KEY 共存。
- public/api/admin/index.php:2486 仅当 strlen(APP_KEY) < 16 时发出警告，而 21 字符的哨兵值 'aimu-install-required' 会规避该检查。

## 4. 验证思路与复现步骤

- **前置条件**: 部署已进入以下状态：storage/install.lock 存在（因此 widget API 可运行），但 .env 和进程环境中缺少 APP_KEY——例如运维人员提供了已存在且不含 APP_KEY 的 .env 并运行安装程序，或之后移除了 APP_KEY 而 install.lock 仍保留。/media 路由除 URL 签名外不需要任何认证。

**复现步骤：**

1. 确认目标处于易受攻击状态：读取已知有效签名 URL 的 /media 响应；如果 APP_KEY 未设置，则实际生效的密钥就是公开常量。
2. 独立计算 key = sha256('widget-media|aimu-install-required')，并针对选定的对象键和可接受窗口内的未来过期时间，计算 sig = HMAC-SHA256(key, objectKey . '|' . expires)。
3. 请求 GET /api/widget/index.php?route=/media&key=<objectKey>&expires=<expires>&signature=<sig>，其中 objectKey 是攻击者从未被签发过的对象键。
4. 与使用错误签名发起的同一请求进行比较，以确认端点能区分二者。

**测试样例：**

```
GET /api/widget/index.php?route=/media&key=2024/01/01/0123456789abcdef0123456789abcdef.jpg&expires=<now+3600>&signature=<HMAC-SHA256(sha256('widget-media|aimu-install-required'), '2024/01/01/0123456789abcdef0123456789abcdef.jpg|<now+3600>)>
```

- **预期现象**: 使用公开回退值计算出的伪造签名会返回 HTTP 200 和媒体字节，而同一请求若签名错误则返回 HTTP 403。在配置正确的部署（随机 APP_KEY）上，伪造签名会被拒绝并返回 403。

## 5. 修复建议

不要从可能缺失的值派生媒体签名密钥并回退到固定值。应采用 app/Security/Crypto.php:58 中已使用的安全失败（fail closed）模式——如果 APP_KEY（或专用的媒体签名密钥）缺失或过短，则拒绝签名和验证（返回错误 / HTTP 500/403），而不是替换为 'aimu-install-required'。优先使用专用的 MEDIA_SIGN_KEY 而不是 APP_KEY，在启动时拒绝已知哨兵值，并在写入 install.lock 时由 Installer 验证 APP_KEY 是否存在（app/Core/Installer.php:362-375）。将管理员健康检查阈值提高到超过哨兵值长度（public/api/admin/index.php:2486），至少可以暴露该错误配置。
