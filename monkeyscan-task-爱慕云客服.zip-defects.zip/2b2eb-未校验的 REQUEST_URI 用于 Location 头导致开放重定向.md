## 1. 总结

- **漏洞类型**: open_redirect (CWE-601)
- **标记位置**: public/build.php:66
- **漏洞描述**: public/build.php 在超级管理员登录成功后（第 66 行）以及登出后（第 82 行）会原样输出 'Location: ' . $_SERVER['REQUEST_URI']。$_SERVER['REQUEST_URI'] 是客户端提供的原始请求目标，从未经过解析、主机校验，也未被限制为单斜杠相对路径，因此当请求目标以 '//' 开头时，就会生成协议相对（protocol-relative）的 Location 头，将浏览器导向外部主机。登出分支无需任何身份认证，也没有 CSRF 令牌保护该 POST 请求，因此很容易跨站触发该重定向；只有前端 Web 服务器的反 CSRF/重复斜杠行为构成一定限制。

## 2. 分析逻辑

### 步骤 1: 检查被标记的重定向汇聚点

**证据**: `public/build.php:66`

```
if (PlatformAuth::attempt($username, $password)) {
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}
```

该代码将请求 URI 未加校验直接拼接到 Location 头中。登出分支 public/build.php:82（`header('Location: ' . $_SERVER['REQUEST_URI']);`）存在第二个完全相同的汇聚点，它在没有任何身份认证检查的情况下无条件执行。

### 步骤 2: 识别被污染的变量及其来源

**证据**: `public/build.php:66`

```
$_SERVER['REQUEST_URI']
```

被污染的变量是 $_SERVER['REQUEST_URI']，即 PHP 接收到的、由客户端发送的原始请求目标（路径 + 查询字符串）。该值直接受请求控制：攻击者可决定请求行中的字节内容。从来源到汇聚点，没有任何环节对其改写或校验；它被直接拼接进响应头。

### 步骤 3: 检查该路径上的每一处防护

**证据**: `app/Security/DomainGuard.php:20`

```
$expected = strtolower((string) parse_url($configuredUrl, PHP_URL_HOST));
$actual = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? '')));
... if ($expected === '' || $actual === '' || !hash_equals($expected, $actual)) {
```

DomainGuard::requirePlatformHost()（在 public/build.php:25 处调用）仅将 Host 头与配置的平台主机进行比对，并不检查 REQUEST_URI，因此无法阻止在受信任主机上使用 '//host/...' 形式的目标。LicenseGate::enforce()（build.php:16）和 Session::start()（build.php:27）同样没有对重定向目标施加任何限制。从来源到响应头之间，不存在任何 parse_url/主机相等性检查，没有允许列表，也没有单前导斜杠检查。

### 步骤 4: 检查该 POST 是否具备 CSRF 防护

**证据**: `public/build.php:53`

```
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim($_POST['action'] ?? '');
```

在 public/build.php 中检索 `Csrf`/`csrf`，无任何匹配；build.php:250 和 build.php:276 处的表单均未携带令牌。登出分支（build.php:80-84）无需身份认证即可执行重定向，因此跨站自动提交的表单无需凭据即可触达该汇聚点。

### 步骤 5: 确认该入口点在参考部署中可达

**证据**: `deploy/nginx/aimu-customer-cloud.conf:98`

```
location ~ \.php$ {
    try_files $uri =404;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_pass unix:/run/php/php8.2-fpm.sock;
}
```

参考 Nginx 配置通过通用 PHP location 执行 build.php，且未定义任何针对 /build.php 的拒绝规则（仅对 install 做了特殊处理，见第 61-72 行）。针对 build.php 的拒绝规则仅存在于可选的 deploy/nginx-security.conf:59-62 中，需要运维人员手动粘贴。build.php 是顶层脚本 = 框架入口点，无需任何仓库内调用方即可访问。

### 步骤 6: 与同一代码库中其他位置的安全重定向辅助函数对比

**证据**: `public/customer.php:26`

```
function customerRedirect(string $slug, string $notice = ''): void
{
    $target = '/s/' . rawurlencode($slug);
    ...
    header('Location: ' . $target);
}
```

customer.php 使用服务器生成的前缀加上 rawurlencode 构造其 Location，而不是使用原始请求 URI。该代码库显然知晓这一安全模式，这也印证了 build.php 使用未校验的 REQUEST_URI 是一条有缺陷的路径。

### 步骤 7: 测试以 '//' 开头的目标能否到达 build.php

**证据**: `deploy/nginx/aimu-customer-cloud.conf:94`

```
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

脚本必须解析为 /build.php 才能执行。普通的 '//evil.example/x' 目标会被规范化成 /evil.example/x，并被路由到 index.php 而非 build.php，因此报告中给出的确切载荷本身无法路由到达。然而，诸如 '//evil.example/..%2fbuild.php' 这样的目标（在服务器解码 %2f 并移除点段之后）会为路由目的解析为 /build.php，因此 build.php 得以执行，而 PHP 保留的原始 $_SERVER['REQUEST_URI'] 仍以 '//evil.example' 开头。随后输出的 'Location: //evil.example/..%2fbuild.php' 就是一个协议相对 URL，其 authority 为 evil.example。因此，可利用性取决于前端服务器（正如发现结论所述），而底层的数据流缺陷并未改变。

### 分析过程

- Q1: 用户可控输入是否决定重定向目标？-> 是。$_SERVER['REQUEST_URI']（原始客户端请求目标）在 public/build.php:66 与 :82 处被直接拼接进 Location 头，中间没有任何赋值或净化处理（步骤 1-2）。
- Q2: 该 URL 是否经过同源校验或域名允许列表校验？-> 否。该路径上不存在任何 parse_url/主机相等性检查或允许列表校验；DomainGuard（app/Security/DomainGuard.php:20）仅校验 Host 头，而非重定向目标（步骤 3）。
- Q3: 该重定向是否被限制为拒绝 '//'、'\\'、'\/'、'://' 的相对路径？-> 否。该值被原样传递；build.php 中任何位置都不存在单前导斜杠或协议检查（步骤 1-3）。
- Q4: 该代码是否为测试/演示/生成代码，或确实不可达？-> 否。build.php 是由参考 Nginx 配置（deploy/nginx/aimu-customer-cloud.conf:98）执行的生产级顶层脚本，且登出分支无需认证、无 CSRF 令牌（步骤 4-5）。
- 结论: 四项关卡的全部结果均偏向漏洞一侧 -> 真实漏洞（TP）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/build.php:66 与 public/build.php:82 输出 'Location: ' . $_SERVER['REQUEST_URI']，未做任何解析、主机校验或相对路径限制。
- public/build.php:80-84 处的登出汇聚点在无认证情况下运行，且该文件不包含 CSRF 令牌，因此可被跨站 POST 触发。
- app/Security/DomainGuard.php:20-36 仅校验 $_SERVER['HTTP_HOST']；它从未对重定向目标施加限制。
- deploy/nginx/aimu-customer-cloud.conf:98-105 会执行 build.php，只有可选的 deploy/nginx-security.conf:59-62 会拒绝它，因此在默认部署下该汇聚点可达。

## 4. 验证思路与复现步骤

- **前置条件**: build.php 在平台主机上可达（对参考 Nginx 配置而言成立，它通过 `location ~ \.php$` 执行该脚本，且未定义 build.php 拒绝规则）。请求 Host 必须等于所配置的平台域名，DomainGuard 才能通过；因此跨站表单的 action 需要指向真实的平台主机。无需管理员会话 —— 登出分支无需认证且无 CSRF 防护。以 '//' 开头目标的可利用性还取决于前端服务器在路由时是否解码斜杠/点段，同时将原始 REQUEST_URI 转发给 PHP（如报告所述，这取决于服务器）。

**复现步骤：**

1. 确认构建页面处于在线状态：GET https://<platform-host>/build.php 返回登录表单（若已认证则返回控制台）。
2. 托管一个攻击者页面，自动向服务器提交 POST 表单，选择一个以 '//' 开头、但仍能解析为 build.php 以完成路由的请求目标，例如 action="https://<platform-host>//evil.example/..%2fbuild.php"，并带有一个隐藏字段 action=logout（若使用登录分支，则使用 action=login 加上有效凭据）。
3. 提交表单并检查该 POST 的响应。
4. 观察 302 响应头中的 Location，并在浏览器中跟随它。

**测试样例：**

```
curl -i -sS -X POST 'https://<platform-host>//evil.example/..%2fbuild.php' --data 'action=logout'   (raw-HTTP equivalent that demonstrates the raw request target reaching the sink; the equivalent cross-site browser form uses action="https://<platform-host>//evil.example/..%2fbuild.php")
```

- **预期现象**: 响应携带 `Location: //evil.example/..%2fbuild.php` —— 一个 authority 不是平台主机的 scheme-relative URL —— 并且浏览器会跳转到 evil.example。安全行为应将 Location 限制为同源的绝对路径，例如 `/build.php`。

## 5. 修复建议

不要从请求中推导重定向目标。将两条 `header('Location: ' . $_SERVER['REQUEST_URI']);` 语句（public/build.php:66 与 :82）替换为固定的已知同源路径，例如 `header('Location: /build.php');`。如果确实无法避免回显任何来自请求的值，则在输出前拒绝任何非严格本地路径的目标：要求该值匹配 ^/[^/\\]（单个前导斜杠、无反斜杠），拒绝以 '//'、'/\'、'\\' 或 '///' 开头的字符串，拒绝任何包含 '://' 或在第一个 '/' 之前包含 ':' 的值，并优先将解析后的路径（parse_url(..., PHP_URL_PATH)）与允许页面列表进行比对。此外，应部署文档中给出的 `location ~ ^/(install|build)\.php$ { deny all; return 404; }` 块（deploy/nginx-security.conf:59-62），以便在生产环境中不暴露构建页面，并为 build.php 的表单添加 CSRF 令牌。
