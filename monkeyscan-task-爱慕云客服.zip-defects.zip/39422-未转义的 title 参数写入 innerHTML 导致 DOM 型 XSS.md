## 1. 总结

- **漏洞类型**: XSS (CWE-79)
- **标记位置**: public/widget/widget-render.php:222
- **漏洞描述**: `title` 查询参数直接从 `$_GET` 读取（widget-render.php:510），经普通 `json_encode()` 序列化（会转义引号/反斜杠，但保留 `<` 和 `>` 不变），赋值给 JavaScript 变量 `TITLE`（第 116 行），再拼接进 `btn.innerHTML`（第 222 行）。由于 `json_encode` 仅保护 JS 字符串上下文，不提供 HTML 上下文编码，构造的 title（如 `<img src=x onerror=alert(1)>`）会被浏览器解析为 HTML，其内联处理器随即执行。响应虽为 `application/javascript` 且带有 `nosniff`，但无法缓解此问题：该值由客户端 JS 写入 DOM，这正是响应内容类型明确无法影响的 DOM-XSS 情形。

## 2. 分析逻辑

### 步骤 1: 读取被标记的文件并定位危险汇聚点（sink）

**证据**: `public/widget/widget-render.php:218-222`

```
function createWidgets() {
    btn = document.createElement('button');
    btn.id = 'aimu-btn';
    btn.setAttribute('aria-label', TITLE);
    btn.innerHTML = '<span class="bdg" id="aimu-bdg"></span><span class="lbl">' + TITLE + '</span>';
```

`btn.innerHTML` 是真正的 HTML 解析危险汇聚点（sink），其中拼接了未转义的变量 `TITLE`，该变量位于两个 span 标签之间。下一步：追溯 TITLE 的来源。

### 步骤 2: 回溯 TITLE 到其赋值处

**证据**: `public/widget/widget-render.php:116`

```
var TITLE        = cfg.title  || '在线咨询';
```

TITLE 即为 `cfg.title`，来自同一生成脚本底部传给 IIFE 的对象字面量。

### 步骤 3: 回溯 cfg.title 到 HTTP 请求参数

**证据**: `public/widget/widget-render.php:503-510`

```
})({
    siteId:   <?= json_encode($sitePublicId) ?>,
    ...
    title:    <?= json_encode($_GET['title']   ?? '在线咨询') ?>,
```

cfg.title 是 `json_encode($_GET['title'])`。其来源是未经验证的 HTTP GET 参数，直接受攻击者控制。此文件中任何位置均未应用 htmlspecialchars/HTML 转义。

### 步骤 4: 评估 json_encode 是否构成防御

**证据**: `public/widget/widget-render.php:510`

```
title:    <?= json_encode($_GET['title']   ?? '在线咨询') ?>,
```

json_encode 以默认标志调用（没有 JSON_HEX_TAG/JSON_HEX_AMP）。它会转义 `"` 和 `\`，因而无法突破外层的 JS 字符串字面量，但不会转义 `<` 或 `>`。它是 JS 字符串上下文编码器，而非 HTML 上下文编码器，而该值的最终目的地是 innerHTML。对整个项目执行 grep 可见，htmlspecialchars 在其他许多文件中均有使用，却从未用于该值。

### 步骤 5: 检查响应头是否存在缓解措施

**证据**: `public/widget/widget-render.php:17-21`

```
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
```

该响应是一个 JS 文件，带有 nosniff，且没有 CSP 头。这仅影响反射型 XSS 的嗅探；当客户端 JS（第 222 行的 innerHTML）将该值写入 DOM 时，它不提供任何保护，而这正是典型的 DOM-XSS 情形。

### 步骤 6: 确认可达性与 token 门禁

**证据**: `public/widget/widget-render.php:24-35; public/widget/widget-token.php:60-67`

```
$rawToken = trim((string) ($_GET['token'] ?? ''));
...
$claims = WidgetGuard::verifyRenderToken($rawToken);
if ($claims === null) { echo '/* aimu widget: invalid or expired token */'; exit; }
```

需要有效的 render token，但它只是短时效（120 秒）的自签名 token，由 widget-token.php 签发给任何 Origin/Referer 与站点白名单域名匹配者（WidgetGuard::checkDomain）。widget-render.php 从不重新检查 token 的 origin 声明，且 token 不绑定到 `title`。因此，该 token 只控制可用性，并不控制受污染的值；它可通过从任何已运行该 widget 的页面复制 script src，或使用允许列表中的 Referer 调用 widget-token.php 来获取。widget 文件本身是 public/ 下的框架/HTTP 入口点，因此可达。

### 分析过程

- Q1: 用户可控数据是否到达 HTML/JS 输出危险汇聚点（sink）？-> 是：$_GET['title'] (widget-render.php:510) -> cfg.title -> TITLE (第 116 行) -> btn.innerHTML (第 222 行)。
- Q2: 模板引擎是否自动转义且未被绕过？-> 不适用/否：没有模板引擎；该值通过原始字符串拼接手工拼入 innerHTML（第 222 行）。
- Q3: 是否存在适用于 HTML 上下文的显式输出编码？-> 否：仅应用了 json_encode（JS 字符串上下文）（第 510 行）；它不改变 `<` 和 `>`，对 innerHTML 而言并不足够。该路径上没有 htmlspecialchars/DOMPurify。
- Q4: 响应 Content-Type 是否为带 nosniff 的非 HTML，且之后未被写入 DOM？-> 类型是带 nosniff 的 application/javascript，但该值之后确实由客户端 JS（innerHTML，第 222 行）写入 DOM，这属于 DOM XSS，且明确不受响应内容类型影响。因此该条件不能排除该发现。
- Q5: 代码是否为测试/演示/生成代码，或确实不可达？-> 否：它是作为 public/widget/ 下的 HTTP 入口点提供的生产代码，只需要一个短时效且可获取的 token。
- 结论 -> 真实漏洞（TP）。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- public/widget/widget-render.php:222 将 TITLE 直接拼接进 btn.innerHTML，未进行 HTML 编码。
- public/widget/widget-render.php:510 从 $_GET['title'] 获取 title，且仅应用 json_encode，而它不转义 '<' 或 '>'（没有 JSON_HEX_TAG 标志）。
- public/widget/widget-render.php:116 将 cfg.title 原样赋给 TITLE，该值随后被放入 HTML 危险汇聚点（sink）。
- public/widget/widget-render.php:17-21 以 application/javascript 提供该脚本，带有 nosniff 且无 CSP，这不能消除 DOM-XSS 危险汇聚点（sink）。

## 4. 验证思路与复现步骤

- **前置条件**: widget-render.php 可达（public/ 下的 HTTP 入口点）。必须提供针对已知 site_public_id 的有效 120 秒 render token；可通过使用与站点白名单域名匹配的 Origin/Referer 调用 widget-token.php 获取，或从已运行该 widget 的页面读取 widget script src 获取。无需身份验证，且 title 参数不进行任何验证。

**复现步骤：**

1. 获取 render token：使用属于站点允许列表的 Origin/Referer 发起 GET /widget/widget-token.php?site_id=<site_public_id>，并从 JSON 响应中读取 result.token。
2. 构造 payload URL：/widget/widget-render.php?token=<token>&title=<URL 编码后的 '<img src=x onerror=alert(document.domain)>'>。
3. 在任意 HTML 页面中将该 URL 作为 <script src="..."> 加载（该 widget 正是设计为通过此机制嵌入，见 embed.js:143-150）。
4. 观察注入的元素被解析，且其内联处理器触发。

**测试样例：**

```
GET /widget/widget-render.php?token=<valid_token>&title=%3Cimg%20src%3Dx%20onerror%3Dalert(document.domain)%3E (loaded via <script src> from an HTML page)
```

- **预期现象**: JavaScript 在嵌入页面的源（origin）中执行（alert 触发），因为响应体包含 `title: "<img src=x onerror=alert(document.domain)>"`，且 createWidgets() 将其赋给 btn.innerHTML；在 DOM 检查中，按钮（#aimu-btn）包含注入的 <img> 元素，而不是字面量 title 文本。

## 5. 修复建议

不要将 title 放入 innerHTML。应使用 createElement 构建徽章/标签 span，并设置 label.textContent = TITLE（如第 420 行已针对未读徽章正确实现的那样）。或者，在赋值前立即对 TITLE 进行 HTML 上下文转义，或通过 document.createTextNode 渲染。加固措施：将请求派生的值嵌入脚本上下文时，还应向 json_encode 传入 JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT（第 510 行），并在将 color/pos/ox/oy 参数拼接到注入的 CSS 之前先验证它们（第 183-192 行）。最后，让 widget-render.php 将 $claims['origin'] 与请求 Origin 进行比较，这样从某个上下文获取的 token 就无法以任意 title 重放。
