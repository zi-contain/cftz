## 1. 总结

- **漏洞类型**：hardcoded_credentials (CWE-798)
- **标记位置**：app/Security/LicenseGate.php:15
- **漏洞描述**：App\Security\LicenseGate 将许可协议使用的 AES-256 密钥（APP_KEY，64 个十六进制字符 = 32 字节）和 HMAC 密钥（SECRET_KEY）硬编码为类常量，并复用为 LICENSE_APP_KEY / LICENSE_SECRET_KEY 的默认值。同一个 32 字节 APP_KEY 还额外硬编码在受 Git 跟踪的 config.php 中，而该文件正是实际生效的执行路径所读取的文件（auth.php:162），因此无论环境变量如何设置，该密钥都会在每个请求中生效。这些值是真实的高熵密钥材料（同目录的 .env.example 对 APP_KEY 使用了明显的占位符，却提供了实际的许可密钥），且所有内容均已提交到版本控制。这是提交到源码中的硬编码凭据。

## 2. 分析逻辑

### 步骤 1: 读取被标记的硬编码常量

**证据**: `app/Security/LicenseGate.php:15`

```
private const APP_KEY = 'ed41f6a421eba367397b053ecd0eebe27c70fd9b548920f68fb6094a3e5542f7';
private const SECRET_KEY = '7a487a404692acb43841772464889f6b9c06f3ee948abf797aa24086d3cd60d';
```

这两个类常量保存了高熵密钥材料：APP_KEY 恰好为 64 个十六进制字符（32 字节，有效的 AES-256 密钥），SECRET_KEY 为 63 个十六进制字符。它们不是占位符（不含 changeme/xxx/TODO），且位于生产安全代码中，而非测试/演示文件。下一步：查找它们的使用方式。

### 步骤 2: 追踪这些常量在 LicenseGate 内部如何被使用

**证据**: `app/Security/LicenseGate.php:164`

```
'app_key' => trim((string) Env::get('LICENSE_APP_KEY', self::APP_KEY)),
'secret' => trim((string) Env::get('LICENSE_SECRET_KEY', self::SECRET_KEY)),
```

Env::get（app/Core/Env.php:27-31）在环境变量已设置时返回该变量，否则返回硬编码常量，即硬编码默认值；这是典型的 CWE-798 模式，而非仅从环境加载。项目范围的 grep 显示 config() 本身没有调用者，因此这些类内常量当前是死代码；但相同密钥在其他位置仍然生效（步骤 3），所以该凭据仍暴露在随产品发布的源码中。

### 步骤 3: 沿实际执行路径找到相同的硬编码密钥

**证据**: `auth.php:162`

```
$config = require __DIR__ . '/config.php';
$payload['sign'] = aimu_auth_sign($payload, (string) $config['secret_key']);
$decrypted = aimu_auth_decrypt((string) $outer['enc_data'], (string) $config['app_key']);
```

LicenseGate::authorizeWithCode()（LicenseGate.php:142-148）会 require auth.php 并调用 aimu_auth_check()；该函数在 auth.php:162 处加载 config.php，并在 auth.php:122-123、151、155、191-195、226、232 处使用 $config['app_key'] / $config['secret_key'] 进行 HMAC-SHA256 签名和 AES-256-CBC。config.php:10-11 硬编码了完全相同的 32 字节 APP_KEY 和一个 64 字符的 SECRET_KEY，且完全没有环境变量查找——因此该硬编码密钥在真实路径上无条件生效。

### 步骤 4: 确认这些值是真实密钥，而非占位符

**证据**: `.env.example:46`

```
APP_KEY=base64:PLEASE_GENERATE_A_RANDOM_32_BYTE_KEY
...
LICENSE_APP_KEY=ed41f6a421eba367397b053ecd0eebe27c70fd9b548920f68fb6094a3e5542f7
LICENSE_SECRET_KEY=7a487a404692acb43841772464889f6b9c06f3ee948abf797aa24086d3cd60d
```

在同一文件中，通用 APP_KEY/WIDGET_TOKEN_SECRET 带有明确的 'PLEASE_GENERATE...' 占位符，而 LICENSE_APP_KEY/LICENSE_SECRET_KEY 则带有实际的 32 字节密钥。这表明许可密钥值是随源码发布的真实密钥，而非虚拟/示例值。

### 步骤 5: 检查版本控制跟踪与运行时覆盖

**证据**: `.gitignore:1`

```
verify_requirements/
// `git ls-files` -> .env.example, config.php, auth.php, app/Security/LicenseGate.php
```

唯一被忽略的条目是 verify_requirements/。所有包含密钥的文件均受 git 跟踪（已通过 git ls-files 确认），且检出内容中不存在 .env 文件，因此已提交的默认值就是实际运行时使用的值。不存在任何 secrets manager（密钥管理服务）集成。

### 分析过程

- Q1：被标记的值是真实密钥（而非占位符/测试/示例）吗？-> 是。APP_KEY 是 32 字节的随机十六进制值，在 config.php 中被实际复制使用，并与 .env.example 中旁边的占位符一同展示（步骤 1、3、4）。
- Q2：该密钥是否在运行时从环境变量 / secrets manager 加载？-> 否。它通过带硬编码回退值的 Env::get 加载（步骤 2），而实际路径完全不会查找环境变量，而是直接读取 config.php 的字面量值（步骤 3）。
- Q3：该文件是否真的不在版本控制中？-> 否。git ls-files 确认 LicenseGate.php、config.php、auth.php 和 .env.example 均被跟踪；.gitignore 仅忽略 verify_requirements/（步骤 5）。
- Q4：该值是否已加密或哈希，且密钥保存在仓库之外？-> 否。这些常量是明文，且解密/签名密钥本身就是已提交的值（步骤 1、3）。
- Q5：该代码是否仅为测试/演示/文档上下文？-> 否。LicenseGate 是全局门禁，由 app/Core/bootstrap.php:36 在每个受门禁控制的请求中强制执行（步骤 3）。
- 结论：真实漏洞 —— 一个真实的、高熵的加密密钥被硬编码在已提交的生产源码中，并被实际运行的许可协议所使用。

## 3. 结论

**真实漏洞（TP）**

**关键证据：**

- app/Security/LicenseGate.php:15-16 将 APP_KEY（32 字节 AES 密钥）和 SECRET_KEY 硬编码为类常量。
- app/Security/LicenseGate.php:164-165 将这些常量用作 LICENSE_APP_KEY / LICENSE_SECRET_KEY 的回退默认值。
- config.php:10-11 硬编码了完全相同的 APP_KEY 和一个 64 字符的 SECRET_KEY；实际路径在 auth.php:162 处读取该文件。
- auth.php:122-123、151、155、191-195、226、232 将这些密钥用于 HMAC-SHA256 签名以及协议与许可缓存的 AES-256-CBC 加密/解密。
- .env.example:46-47 提供了真实密钥值，而第 6 行使用占位符，证明许可密钥值是实际生效的密钥。
- .gitignore:1 仅忽略 verify_requirements/，因此所有包含密钥的文件均已提交到版本控制。

## 4. 验证思路与复现步骤

- **前置条件**：攻击者已掌握分发的源码（包括 app/Security/LicenseGate.php 和 config.php）——该源码会随产品的每一次安装一起分发。没有任何 .env 设置 LICENSE_APP_KEY/LICENSE_SECRET_KEY，并且在真实路径上会无条件使用 config.php 中硬编码的密钥。攻击者还需要能够写入 storage/license/auth.cache（本地文件访问或独立的写入原语）；该门禁由 app/Core/bootstrap.php:36 全局强制执行。

**复现步骤：**

1. 读取已提交的密钥材料：从 app/Security/LicenseGate.php:15-16 和/或 config.php:10-11 获取 APP_KEY（32 字节）和 SECRET_KEY。
2. 构造一个缓存载荷 {'status':'ok','host':<target host>,'code_hash':sha256(<authcode>),'expires':<now+300>}，使用随机 IV 以 hash('sha256',$appKey,true) 对其进行 AES-256-CBC 加密，并生成 base64(iv||ciphertext) —— 与 auth.php:151 保持一致。
3. 计算 mac = hmac_sha256_hex($secretKey, $blob) —— 与 auth.php:155 保持一致 —— 并将 {"data":<blob>,"mac":<mac>} 写入 storage/license/auth.cache。
4. 强制使 check.php 请求失败（阻断到 authcf.rgkk.cn 的出站流量），以便 aimu_auth_check() 回退到 aimu_auth_network_fallback（auth.php:215-216），后者会调用 aimu_auth_cache_read()。
5. 请求任意受许可门禁控制的端点（例如 public/api/merchant/index.php），并观察其被正常提供，而不是返回 403 LICENSE_DENIED 响应。

**测试样例：**

```
{"data":"<base64(iv || AES-256-CBC({\"status\":\"ok\",\"host\":\"target.example.com\",\"code_hash\":\"<sha256(authcode)>\",\"expires\":<now+300>}))>","mac":"<hmac_sha256_hex(secretKey, data)>"}  written to storage/license/auth.cache
```

- **预期现象**：在授权服务器不可达的情况下，LicenseGate::isAuthorized() 返回 true，业务 API 正常响应，因为 aimu_auth_cache_read() 接受了攻击者构造的 'ok' 记录，而该记录的 MAC 和密文是使用已提交的密钥生成的。安全行为应是许可失败并返回 403/503。

## 5. 修复建议

从 app/Security/LicenseGate.php:15-16 中移除硬编码的 APP_KEY/SECRET_KEY，并从 config.php:10-11 和 .env.example:46-47 中移除相同的值；仅从环境或密钥管理服务加载它们，并在缺失时故障关闭（fail closed）。轮换这两个值（源码一旦分发，它们现在就已经公开），并由供应商为每个安装签发单独的密钥。为加密（AES）和 HMAC 使用不同的密钥，这样一次泄露不会同时危及机密性和完整性。由于 config.php 才是实际路径真正读取的文件（auth.php:162），仅轮换 LicenseGate 常量是不够的。
